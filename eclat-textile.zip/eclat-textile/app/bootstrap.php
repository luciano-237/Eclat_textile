<?php
/**
 * Amorçage : configuration, session, connexion à la base, outils communs.
 */
declare(strict_types=1);

define('APP_ROOT', dirname(__DIR__));
$GLOBALS['config'] = require APP_ROOT . '/config/config.php';
date_default_timezone_set($GLOBALS['config']['timezone']);

ini_set('session.cookie_httponly', '1');
ini_set('session.use_strict_mode', '1');
session_name('PRESSINGSESS');
session_start();

require __DIR__ . '/db.php';
require __DIR__ . '/helpers.php';
require __DIR__ . '/icons.php';
require __DIR__ . '/auth.php';
require __DIR__ . '/metier.php';
