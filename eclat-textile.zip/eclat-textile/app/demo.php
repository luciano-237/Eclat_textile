<?php
/**
 * Jeu de données de démonstration (agences, tarifs, personnel, clients, commandes).
 * Les commandes passent par les déclencheurs de la base, exactement comme dans l'application.
 * Mot de passe de tous les comptes de démonstration : demo1234
 */

function charger_demo(int $idAdmin): void
{
    q('SET @id_employe_session = ?', [$idAdmin]);
    $pw = password_hash('demo1234', PASSWORD_DEFAULT);
    $role = fn(string $r) => (int) val('SELECT id_role FROM role WHERE libelle_role = ?', [$r]);

    // Agences (RG01 à RG06)
    $agences = [
        ['Bastos', 'Rue 1.750, face ambassade de Chine', 'Yaoundé', '222 20 14 50', 72, 24],
        ['Akwa', 'Boulevard de la Liberté', 'Douala', '233 42 18 70', 48, 12],
    ];
    $idsAgence = [];
    foreach ($agences as $a) {
        q('INSERT INTO agence (nom_agence, adresse_agence, ville_agence, telephone_agence, duree_normal_h, duree_express_h)
           VALUES (?, ?, ?, ?, ?, ?)', $a);
        $idsAgence[] = (int) db()->lastInsertId();
    }

    // Catalogue : une catégorie au poids en plus des catégories de référence
    q("INSERT INTO categorie_article (libelle_categorie, description_categorie) VALUES ('Linge courant', 'Chemises, pantalons, t-shirts : facturés au poids')");
    $cat = fn(string $l) => (int) val('SELECT id_categorie FROM categorie_article WHERE libelle_categorie = ?', [$l]);
    $articles = [
        'Costumes' => ['Costume 2 pièces', 'Veste', 'Manteau'],
        'Robes' => ['Robe', 'Robe de soirée', 'Robe de mariée'],
        'Linge de maison' => ['Drap', 'Couverture', 'Rideau', 'Nappe'],
        'Linge courant' => ['Chemise', 'Pantalon', 'T-shirt', 'Jupe', 'Pagne'],
    ];
    foreach ($articles as $c => $list) {
        foreach ($list as $l) {
            q('INSERT INTO article (libelle_article, id_categorie) VALUES (?, ?)', [$l, $cat($c)]);
        }
    }

    // Tarifs par agence (RG23 à RG25, RG42)
    $tarifs = [['Costumes', 3500, 'Pièce'], ['Robes', 2500, 'Pièce'], ['Linge de maison', 2000, 'Pièce'], ['Linge courant', 600, 'Poids']];
    $supps = ['Repassage' => 300, 'Blanchissage' => 500, 'Détachage' => 700, 'Livraison à domicile' => 1500];
    foreach ($idsAgence as $i => $ida) {
        foreach ($tarifs as [$c, $prix, $unite]) {
            q('INSERT INTO tarif_categorie (id_agence, id_categorie, prix_categorie, unite_facturation) VALUES (?, ?, ?, ?)',
                [$ida, $cat($c), $prix + $i * 250, $unite]);
        }
        foreach ($supps as $s => $prix) {
            q('INSERT INTO tarif_supplement (id_agence, id_supplement, prix_supplement)
               SELECT ?, id_supplement, ? FROM supplement WHERE libelle_supplement = ?', [$ida, $prix + $i * 100, $s]);
        }
    }

    // Personnel
    $staff = [
        // nom, prénom, e-mail, rôle, index agence
        ['Ngo Bassa', 'Carine', 'gerant.bastos@demo.pressing', 'Gérant', 0],
        ['Essomba', 'Paul', 'livreur1.bastos@demo.pressing', 'Livreur', 0],
        ['Mbarga', 'Hervé', 'livreur2.bastos@demo.pressing', 'Livreur', 0],
        ['Ekwalla', 'Sandrine', 'gerant.akwa@demo.pressing', 'Gérant', 1],
        ['Douala Manga', 'Joël', 'livreur1.akwa@demo.pressing', 'Livreur', 1],
    ];
    $ids = [];
    foreach ($staff as $k => [$nom, $prenom, $mail, $r, $ag]) {
        q('INSERT INTO employe (nom_employe, prenom_employe, telephone_employe, email_employe, mot_de_passe, id_role, id_agence, date_embauche)
           VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_DATE - INTERVAL ? DAY)',
            [$nom, $prenom, '6' . (77000000 + $k * 1234567), $mail, $pw, $role($r), $idsAgence[$ag], 30 * ($k + 3)]);
        $ids[$mail] = (int) db()->lastInsertId();
    }
    // Compte de démonstration administrateur
    q('INSERT INTO employe (nom_employe, prenom_employe, telephone_employe, email_employe, mot_de_passe, id_role, id_agence)
       VALUES (?, ?, ?, ?, ?, ?, NULL)', ['Admin', 'Démo', '600000000', 'admin@demo.pressing', $pw, $role('Administrateur')]);

    // Clients
    $clients = [
        ['Atangana', 'Brice', '677112233', 'Quartier Bastos, villa 12', 0],
        ['Fotso', 'Mireille', '699445566', 'Mvan, derrière la station', 0],
        ['Onana', 'Yves', '655778899', null, 0],
        ['Nkeng', 'Laure', '691223344', 'Odza, carrefour Bel-Air', 0],
        ['Tchoua', 'Arnaud', '670998877', 'Bonapriso, rue Njo-Njo', 1],
        ['Eyenga', 'Grâce', '694556677', null, 1],
    ];
    $idc = [];
    foreach ($clients as [$nom, $prenom, $tel, $adr, $ag]) {
        q('INSERT INTO client (nom_client, prenom_client, telephone_client, adresse_client, id_agence, date_inscription)
           VALUES (?, ?, ?, ?, ?, CURRENT_DATE - INTERVAL 40 DAY)', [$nom, $prenom, $tel, $adr, $idsAgence[$ag]]);
        $idc[] = (int) db()->lastInsertId();
    }

    $gB = $ids['gerant.bastos@demo.pressing'];
    $gA = $ids['gerant.akwa@demo.pressing'];
    // Commandes : parcours complets via les déclencheurs
    demo_commande($idsAgence[0], $idc[0], $gB, 'Normal', 'Retrait', [['Costume 2 pièces', 1.8, 'Bon état'], ['Chemise', 0.3, 'Col légèrement jauni'], ['Pantalon', 0.6, 'Bon état']], ['Repassage' => 0], 6, 'Retirée');
    demo_commande($idsAgence[0], $idc[1], $gB, 'Express', 'Retrait', [['Robe de soirée', 0.9, 'Paillettes fragiles'], ['Drap', 1.2, 'Bon état']], [], 5, 'Terminée');
    demo_commande($idsAgence[0], $idc[3], $gB, 'Normal', 'Livraison', [['Couverture', 2.6, 'Bon état'], ['Rideau', 1.4, 'Poussiéreux']], ['Détachage' => 1], 4, 'Terminée');
    demo_commande($idsAgence[0], $idc[2], $gB, 'Normal', 'Retrait', [['Chemise', 0.3, 'Bon état'], ['Chemise', 0.3, 'Tache d\'encre'], ['T-shirt', 0.2, 'Bon état'], ['Pantalon', 0.7, 'Bon état'], ['Jupe', 0.4, 'Bon état'], ['Pagne', 0.8, 'Bon état'], ['Pantalon', 0.7, 'Ourlet décousu']], [], 3, 'En traitement');
    demo_commande($idsAgence[0], $idc[0], $gB, 'Express', 'Retrait', [['Veste', 1.1, 'Bon état']], ['Repassage' => 0], 1, 'Payée');
    demo_commande($idsAgence[0], $idc[1], $gB, 'Normal', 'Retrait', [['Robe', 0.7, 'Bon état'], ['Nappe', 0.9, 'Taches de vin']], [], 0, 'Enregistrée');
    demo_commande($idsAgence[1], $idc[4], $gA, 'Normal', 'Livraison', [['Costume 2 pièces', 1.9, 'Bon état'], ['Chemise', 0.3, 'Bon état']], [], 2, 'Terminée');
    demo_commande($idsAgence[1], $idc[5], $gA, 'Express', 'Retrait', [['Robe de mariée', 3.2, 'Traîne tachée de terre']], ['Détachage' => 0], 1, 'En traitement');
}

/**
 * Crée une commande de démonstration et la fait avancer jusqu'à $etatFinal.
 * $supps : libellé => index du vêtement concerné (portée « Vêtement »), ignoré pour la portée « Commande ».
 */
function demo_commande(int $agence, int $client, int $gerant, string $service, string $mode, array $items, array $supps, int $joursAvant, string $etatFinal): void
{
    $quand = date('Y-m-d H:i:s', strtotime("-$joursAvant days -" . random_int(1, 5) . ' hours'));
    q('INSERT INTO commande (numero_commande, date_commande, type_service, mode_recuperation, id_agence, id_client, id_employe,
                             duree_appliquee_h, taux_majoration_applique, tarif_kg_applique, seuil_poids_applique,
                             prix_hors_cat_applique, delai_grace_applique, frais_retard_applique)
       VALUES (?, ?, ?, ?, ?, ?, ?, 1, 0, 1, 1, 1, 0, 0)', ['', $quand, $service, $mode, $agence, $client, $gerant]);
    $id = (int) db()->lastInsertId();

    $idsVet = [];
    foreach ($items as [$article, $poids, $etat]) {
        q('INSERT INTO vetement (code_etiquette, poids_kg, etat_initial, id_commande, id_article)
           SELECT \'\', ?, ?, ?, id_article FROM article WHERE libelle_article = ?', [$poids, $etat, $id, $article]);
        $idsVet[] = (int) db()->lastInsertId();
    }
    foreach ($supps as $s => $idx) {
        $sup = row('SELECT id_supplement, portee_supplement FROM supplement WHERE libelle_supplement = ?', [$s]);
        q('INSERT INTO supplement_applique (prix_supp_applique, id_commande, id_supplement, id_vetement) VALUES (0, ?, ?, ?)',
            [$id, $sup['id_supplement'], $sup['portee_supplement'] === 'Vêtement' ? $idsVet[$idx] : null]);
    }
    if ($etatFinal === 'Enregistrée') {
        return;
    }
    $total = (float) val('SELECT fn_montant_total(?)', [$id]);
    $datePaie = date('Y-m-d H:i:s', strtotime($quand . ' +10 minutes'));
    if ($service === 'Express' || $total < 5000) {
        q("INSERT INTO paiement (montant_paiement, date_paiement, mode_paiement, id_commande, id_employe) VALUES (?, ?, 'Espèces', ?, ?)",
            [$total, $datePaie, $id, $gerant]);
    } else {
        $acompte = round($total / 2);
        q("INSERT INTO paiement (montant_paiement, date_paiement, mode_paiement, reference_paiement, id_commande, id_employe)
           VALUES (?, ?, 'MTN Mobile Money', ?, ?, ?)", [$acompte, $datePaie, 'MP' . date('ymd') . random_int(100000, 999999), $id, $gerant]);
        q("INSERT INTO paiement (montant_paiement, date_paiement, mode_paiement, id_commande, id_employe) VALUES (?, ?, 'Espèces', ?, ?)",
            [$total - $acompte, $datePaie, $id, $gerant]);
    }
    if ($etatFinal === 'Payée') {
        return;
    }
    q("UPDATE commande SET statut_commande = 'En traitement' WHERE id_commande = ?", [$id]);
    if ($etatFinal === 'En traitement') {
        q("UPDATE vetement SET statut_vetement = 'Prêt' WHERE id_commande = ? LIMIT 1", [$id]);
        return;
    }
    q("UPDATE vetement SET statut_vetement = 'Prêt' WHERE id_commande = ? AND statut_vetement = 'En traitement'", [$id]);
    q("UPDATE commande SET statut_commande = 'Terminée' WHERE id_commande = ?", [$id]);
    if ($etatFinal === 'Retirée') {
        $c = row('SELECT id_client FROM commande WHERE id_commande = ?', [$id]);
        $nom = val("SELECT CONCAT(COALESCE(prenom_client, ''), ' ', nom_client) FROM client WHERE id_client = ?", [$c['id_client']]);
        q("INSERT INTO retrait (nom_retirant, est_client, mode_verification, id_commande, id_employe) VALUES (?, TRUE, 'Code numérique', ?, ?)",
            [trim($nom), $id, $gerant]);
        $idr = (int) db()->lastInsertId();
        foreach ($idsVet as $v) {
            q('UPDATE vetement SET id_retrait = ? WHERE id_vetement = ?', [$idr, $v]);
        }
    }
}
