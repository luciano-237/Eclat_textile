<?php /** Gabarit des pages hors connexion (connexion, installation). */ ?><!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title) ?> · <?= e(cfg('app_name')) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/app.css?v=1">
<link rel="icon" href="assets/img/logo.svg" type="image/svg+xml">
<script>try{var t=localStorage.getItem('theme');if(t)document.documentElement.dataset.theme=t;}catch(e){}</script>
</head>
<body class="bare">
<div class="auth">
    <section class="auth-hero" aria-hidden="true">
        <div class="auth-hero-inner">
            <div class="brand brand-light">
                <span class="brand-mark"><?= brand_logo(28) ?></span>
                <span class="brand-text"><strong><?= brand_name() ?></strong><small><?= e(cfg('app_tagline')) ?></small></span>
            </div>
            <div class="auth-hero-copy">
                <h2>Du comptoir à la porte du client, chaque vêtement suivi.</h2>
                <p>Dépôts pesés et étiquetés, paiements Mobile Money, codes de retrait sécurisés, livraisons et fidélité — pour toutes vos agences.</p>
            </div>
            <ul class="auth-features">
                <li><?= icon('scale') ?> Tarification à la pièce ou au poids</li>
                <li><?= icon('qr') ?> Retrait par QR code ou code à 6 chiffres</li>
                <li><?= icon('truck') ?> Affectation automatique des livreurs</li>
                <li><?= icon('gift') ?> Fidélité configurée par agence</li>
            </ul>
            <div class="bubbles"><span></span><span></span><span></span><span></span><span></span></div>
        </div>
    </section>
    <section class="auth-panel">
        <div class="toasts">
            <?php foreach (take_flashes() as $f):
                $tone = ['success' => 'good', 'error' => 'critical', 'warning' => 'warning', 'info' => 'info'][$f['type']] ?? 'info'; ?>
                <div class="toast toast-<?= $tone ?>" role="status"><?= icon($tone === 'good' ? 'check-circle' : 'alert', 18) ?><div><?= e($f['msg']) ?></div>
                    <button class="toast-close" aria-label="Fermer"><?= icon('x', 14) ?></button></div>
            <?php endforeach; ?>
        </div>
        <?= $content ?>
    </section>
</div>
<script src="assets/js/app.js?v=1"></script>
</body>
</html>
