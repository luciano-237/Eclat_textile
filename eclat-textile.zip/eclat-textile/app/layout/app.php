<?php
/** Gabarit principal : barre latérale, barre supérieure, messages, contenu. */
$u = user();
$counters = nav_counters();

$nav = [];
if (is_admin()) {
    $nav = [
        '' => [['tableau-de-bord', 'Tableau de bord', 'dashboard']],
        'Réseau' => [
            ['agences', 'Agences', 'store', ['agence']],
            ['tarifs', 'Tarifs', 'tag'],
            ['employes', 'Employés', 'users', ['employe'], 'inscriptions'],
            ['catalogue', 'Catalogue', 'layers'],
        ],
        'Suivi' => [
            ['commandes', 'Commandes', 'receipt', ['commande', 'ticket']],
            ['clients', 'Clients', 'user', ['client']],
            ['livraisons', 'Livraisons', 'truck'],
            ['incidents', 'Incidents', 'alert', ['incident'], 'incidents'],
            ['notifications', 'Notifications', 'bell'],
            ['journal', 'Journal', 'history'],
        ],
    ];
} elseif (is_gerant()) {
    $nav = [
        '' => [['tableau-de-bord', 'Tableau de bord', 'dashboard']],
        'Comptoir' => [
            ['commandes', 'Commandes', 'receipt', ['commande', 'ticket', 'retrait', 'commande-nouvelle']],
            ['clients', 'Clients', 'user', ['client', 'client-form']],
        ],
        'Remise' => [
            ['livraisons', 'Livraisons', 'truck', [], 'livraisons'],
            ['retards', 'Retards & rappels', 'clock', [], 'retards'],
        ],
        'Suivi' => [
            ['incidents', 'Incidents', 'alert', ['incident', 'incident-nouveau'], 'incidents'],
            ['notifications', 'Notifications', 'bell'],
            ['journal', 'Journal', 'history'],
        ],
    ];
} elseif (is_livreur()) {
    $nav = [
        '' => [
            ['tournee', 'Ma tournée', 'truck', ['livraison'], 'tournee'],
            ['tableau-de-bord', 'Mon activité', 'dashboard'],
        ],
    ];
}
?><!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title) ?> · <?= e(cfg('app_name')) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/app.css?v=1">
<link rel="icon" href="assets/img/logo.svg" type="image/svg+xml">
<script>try{var t=localStorage.getItem('theme');if(t)document.documentElement.dataset.theme=t;}catch(e){}</script>
</head>
<body>
<div class="shell">
    <aside class="sidebar" id="sidebar">
        <a class="brand" href="<?= e(url(is_livreur() ? 'tournee' : 'tableau-de-bord')) ?>">
            <span class="brand-mark"><?= brand_logo(28) ?></span>
            <span class="brand-text"><strong><?= brand_name() ?></strong><small><?= e(cfg('app_tagline')) ?></small></span>
        </a>

        <?php if (is_gerant()): ?>
            <a class="btn btn-primary btn-block sidebar-cta" href="<?= e(url('commande-nouvelle')) ?>"><?= icon('plus') ?> Nouveau dépôt</a>
        <?php endif; ?>

        <nav class="nav">
            <?php foreach ($nav as $section => $items): ?>
                <?php if ($section !== ''): ?><div class="nav-section"><?= e($section) ?></div><?php endif; ?>
                <?php foreach ($items as $it):
                    $isActive = $active === $it[0] || in_array($active, $it[3] ?? [], true);
                    $count = isset($it[4]) ? ($counters[$it[4]] ?? 0) : 0; ?>
                    <a class="nav-link<?= $isActive ? ' active' : '' ?>" href="<?= e(url($it[0])) ?>">
                        <?= icon($it[2]) ?><span><?= e($it[1]) ?></span>
                        <?php if ($count > 0): ?><span class="nav-count"><?= $count ?></span><?php endif; ?>
                    </a>
                <?php endforeach; ?>
            <?php endforeach; ?>
        </nav>

        <div class="sidebar-footer">
            <a class="user-chip" href="<?= e(url('mon-compte')) ?>">
                <span class="avatar"><?= e(initials($u['nom'], $u['prenom'])) ?></span>
                <span class="user-chip-text">
                    <strong><?= e(full_name($u['nom'], $u['prenom'])) ?></strong>
                    <small><?= e($u['role']) ?><?= $u['agence'] ? ' · ' . e($u['agence']) : '' ?></small>
                </span>
            </a>
            <a class="icon-btn" href="<?= e(url('deconnexion')) ?>" title="Se déconnecter"><?= icon('logout') ?></a>
        </div>
    </aside>
    <div class="sidebar-backdrop" data-toggle-sidebar></div>

    <div class="main">
        <header class="topbar">
            <button class="icon-btn mobile-only" data-toggle-sidebar aria-label="Menu"><?= icon('menu') ?></button>
            <?php if (!is_livreur()): ?>
            <form class="topbar-search" action="index.php" method="get" role="search">
                <input type="hidden" name="p" value="commandes">
                <?= icon('search', 16) ?>
                <input type="search" name="q" placeholder="Rechercher une commande, un client, un téléphone…" value="<?= e($active === 'commandes' ? get('q') : '') ?>">
                <kbd>/</kbd>
            </form>
            <?php else: ?><div class="grow"></div><?php endif; ?>
            <div class="topbar-right">
                <span class="topbar-date"><?= icon('calendar', 16) ?> <?= e(strftime_fr()) ?></span>
                <button class="icon-btn" id="themeToggle" title="Changer de thème" aria-label="Changer de thème">
                    <span class="theme-light"><?= icon('moon') ?></span><span class="theme-dark"><?= icon('sun') ?></span>
                </button>
            </div>
        </header>

        <main class="content">
            <div class="toasts" id="toasts">
                <?php foreach (take_flashes() as $f):
                    $tone = ['success' => 'good', 'error' => 'critical', 'warning' => 'warning', 'info' => 'info'][$f['type']] ?? 'info';
                    $ic = ['good' => 'check-circle', 'critical' => 'alert', 'warning' => 'alert', 'info' => 'bell'][$tone]; ?>
                    <div class="toast toast-<?= $tone ?>" role="status">
                        <?= icon($ic, 18) ?><div><?= e($f['msg']) ?></div>
                        <button class="toast-close" aria-label="Fermer"><?= icon('x', 14) ?></button>
                    </div>
                <?php endforeach; ?>
            </div>
            <?= $content ?>
        </main>
    </div>
</div>
<script src="assets/js/app.js?v=1"></script>
</body>
</html>
