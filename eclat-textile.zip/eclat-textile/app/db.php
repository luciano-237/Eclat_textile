<?php
/**
 * Accès à la base « pressing » via PDO.
 * Toutes les requêtes sont préparées. Les règles de gestion sont appliquées
 * par les déclencheurs de la base : leurs erreurs (SQLSTATE 45000) sont
 * remontées telles quelles à l'utilisateur.
 */

function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $c = $GLOBALS['config']['db'];
        $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', $c['host'], $c['port'], $c['name']);
        $pdo = new PDO($dsn, $c['user'], $c['password'], [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
        $pdo->exec("SET time_zone = '" . (new DateTime())->format('P') . "'");
        // RG90 : les actions journalisées par les déclencheurs sont attribuées à l'employé connecté
        if (!empty($_SESSION['user']['id_employe'])) {
            $st = $pdo->prepare('SET @id_employe_session = ?');
            $st->execute([(int) $_SESSION['user']['id_employe']]);
        }
    }
    return $pdo;
}

function q(string $sql, array $params = []): PDOStatement
{
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st;
}

function rows(string $sql, array $params = []): array
{
    return q($sql, $params)->fetchAll();
}

function row(string $sql, array $params = []): ?array
{
    $r = q($sql, $params)->fetch();
    return $r === false ? null : $r;
}

function val(string $sql, array $params = [])
{
    $v = q($sql, $params)->fetchColumn();
    return $v === false ? null : $v;
}

/** Exécute $fn dans une transaction ; annule tout en cas d'erreur. */
function transaction(callable $fn)
{
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $r = $fn($pdo);
        $pdo->commit();
        return $r;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
}

/** Traduit une exception PDO en message lisible pour l'utilisateur. */
function db_error(Throwable $e): string
{
    if ($e instanceof PDOException && isset($e->errorInfo[1])) {
        $code = (int) $e->errorInfo[1];
        $msg  = (string) ($e->errorInfo[2] ?? $e->getMessage());
        if ($e->errorInfo[0] === '45000') {
            return $msg;                                   // message de règle de gestion (déclencheur)
        }
        if ($code === 1062) {
            if (preg_match("/for key '([^']+)'/", $msg, $m)) {
                $map = [
                    'uq_client_telephone'  => 'Ce numéro de téléphone est déjà attribué à un client.',
                    'uq_employe_email'     => 'Cette adresse e-mail est déjà utilisée par un employé.',
                    'uq_agence_nom'        => 'Une agence porte déjà ce nom.',
                    'uq_paiement_reference'=> 'Cette référence de transaction a déjà été enregistrée.',
                    'uq_article_libelle'   => 'Cet article existe déjà.',
                    'uq_categorie_libelle' => 'Cette catégorie existe déjà.',
                    'uq_supplement_libelle'=> 'Ce supplément existe déjà.',
                    'uq_vetement_etiquette'=> 'Ce code d\'étiquette est déjà utilisé.',
                ];
                $key = preg_replace('/^.*\./', '', $m[1]);
                if (isset($map[$key])) {
                    return $map[$key];
                }
            }
            return 'Cette valeur existe déjà (doublon).';
        }
        if ($code === 3819) {
            if (preg_match("/constraint '([^']+)'/", $msg, $m)) {
                return 'Donnée invalide : la contrainte « ' . $m[1] . ' » n\'est pas respectée.';
            }
            return 'Donnée invalide : une contrainte de la base n\'est pas respectée.';
        }
        if ($code === 1451 || $code === 1452) {
            return 'Opération impossible : des données liées existent.';
        }
        return 'Erreur de base de données : ' . $msg;
    }
    return $e->getMessage();
}
