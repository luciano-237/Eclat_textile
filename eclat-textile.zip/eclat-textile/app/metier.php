<?php
/**
 * Accès métier partagés entre les pages.
 */

const STATUTS_COMMANDE = ['Enregistrée', 'Payée', 'En traitement', 'Terminée', 'Partiellement retirée', 'Retirée',
    'En attente de livreur', 'En livraison', 'Livrée', 'Annulée'];
const MODES_PAIEMENT = ['Espèces', 'MTN Mobile Money', 'Orange Money', 'Autre'];
const TYPES_INCIDENT = ['Perte', 'Détérioration', 'Erreur de traitement', 'Réclamation', 'Échec de livraison'];
const TYPES_PIECE = ['CNI', 'Passeport', 'Permis de conduire', 'Autre'];

/** Demandes d'inscription non traitées : compte suspendu, jamais connecté, ni validé ni refusé. */
const EMPLOYE_EN_ATTENTE_SQL = "SELECT e.* FROM employe e
     WHERE e.statut_compte = 'Suspendu'
       AND NOT EXISTS (SELECT 1 FROM journal_action j WHERE j.id_employe = e.id_employe AND j.type_action = 'Connexion')
       AND EXISTS (SELECT 1 FROM journal_action j WHERE j.id_entite = e.id_employe AND j.entite_concernee = 'employe' AND j.detail_action LIKE 'Demande d''inscription%')
       AND NOT EXISTS (SELECT 1 FROM journal_action j WHERE j.id_entite = e.id_employe AND j.entite_concernee = 'employe' AND j.detail_action LIKE 'Inscription refusée%')";

function agences(bool $activesSeulement = false): array
{
    return rows('SELECT * FROM agence' . ($activesSeulement ? " WHERE statut_agence = 'Active'" : '') . ' ORDER BY nom_agence');
}

/**
 * Charge une commande avec ses montants calculés, en vérifiant que l'utilisateur
 * connecté a le droit de la consulter (gérant : son agence ; livreur : ses livraisons).
 */
function load_commande(int $id): ?array
{
    $c = row('SELECT c.*, m.montant_vetements, m.montant_majoration, m.montant_supplements, m.montant_total,
                     m.montant_paye, m.reste_a_payer, m.date_retrait_prevue,
                     cl.nom_client, cl.prenom_client, cl.telephone_client, cl.adresse_client, cl.email_client,
                     a.nom_agence, a.adresse_agence, a.ville_agence, a.telephone_agence,
                     e.nom_employe, e.prenom_employe
                FROM commande c
                JOIN v_montants_commande m ON m.id_commande = c.id_commande
                JOIN client cl ON cl.id_client = c.id_client
                JOIN agence a  ON a.id_agence = c.id_agence
                JOIN employe e ON e.id_employe = c.id_employe
               WHERE c.id_commande = ?', [$id]);
    if (!$c) {
        return null;
    }
    if (is_gerant() && (int) $c['id_agence'] !== my_agence()) {
        return null;
    }
    if (is_livreur() && !val('SELECT 1 FROM livraison WHERE id_commande = ? AND id_employe = ?', [$id, my_id()])) {
        return null;
    }
    return $c;
}

/** Nombre de jours de retard courant d'une commande (RG74) : 0 si pas de retard. */
function jours_retard(int $idCommande): int
{
    return (int) val("SELECT GREATEST(0, DATEDIFF(NOW(),
                        DATE(date_paiement_integral + INTERVAL duree_appliquee_h HOUR) + INTERVAL delai_grace_applique DAY))
                        FROM commande WHERE id_commande = ? AND date_paiement_integral IS NOT NULL", [$idCommande]);
}

/**
 * Vérifie un code présenté par le client (valeur du QR code ou code à 6 chiffres).
 * Retourne le mode de vérification reconnu, ou null si le code est invalide.
 */
function verifier_code(int $idCommande, string $saisie): ?string
{
    $saisie = trim($saisie);
    if ($saisie === '') {
        return null;
    }
    $code = row("SELECT valeur_qr, code_numerique FROM code_validation WHERE id_commande = ? AND statut_code = 'Actif'", [$idCommande]);
    if (!$code) {
        return null;
    }
    if (hash_equals($code['valeur_qr'], $saisie)) {
        return 'QR code';
    }
    if (hash_equals($code['code_numerique'], $saisie)) {
        return 'Code numérique';
    }
    return null;
}

/** Contenu du QR code imprimé sur le ticket. */
function qr_payload(array $code): string
{
    return $code['valeur_qr'];
}

/** Compteurs affichés dans la barre latérale (pastilles). */
function nav_counters(): array
{
    try {
        if (is_gerant()) {
            $a = my_agence();
            return [
                'livraisons' => (int) val("SELECT COUNT(*) FROM livraison l JOIN commande c ON c.id_commande = l.id_commande
                                            WHERE c.id_agence = ? AND l.statut_livraison IN ('En attente de livreur','Échouée')", [$a]),
                'incidents'  => (int) val("SELECT COUNT(*) FROM incident i JOIN commande c ON c.id_commande = i.id_commande
                                            WHERE c.id_agence = ? AND i.statut_incident <> 'Clôturé'", [$a]),
                'retards'    => (int) val('SELECT COUNT(*) FROM v_frais_retard WHERE id_agence = ?', [$a]),
            ];
        }
        if (is_livreur()) {
            return ['tournee' => (int) val("SELECT COUNT(*) FROM livraison WHERE id_employe = ? AND statut_livraison IN ('Assignée','En cours')", [my_id()])];
        }
        if (is_admin()) {
            return [
                'incidents'    => (int) val("SELECT COUNT(*) FROM incident WHERE statut_incident <> 'Clôturé'"),
                'inscriptions' => (int) val('SELECT COUNT(*) FROM (' . EMPLOYE_EN_ATTENTE_SQL . ') t'),
            ];
        }
    } catch (Throwable $e) {
    }
    return [];
}
