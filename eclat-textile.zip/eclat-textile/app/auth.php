<?php
/**
 * Authentification et droits (RG02, RG11, RG13 — matrice des droits, chap. 10).
 */

const ROLE_ADMIN   = 'Administrateur';
const ROLE_GERANT  = 'Gérant';
const ROLE_LIVREUR = 'Livreur';

function user(): ?array
{
    return $_SESSION['user'] ?? null;
}

function role(): ?string
{
    return $_SESSION['user']['role'] ?? null;
}

function is_admin(): bool   { return role() === ROLE_ADMIN; }
function is_gerant(): bool  { return role() === ROLE_GERANT; }
function is_livreur(): bool { return role() === ROLE_LIVREUR; }

function my_id(): int
{
    return (int) ($_SESSION['user']['id_employe'] ?? 0);
}

/** Agence de l'employé connecté (NULL pour l'administrateur). */
function my_agence(): ?int
{
    $a = $_SESSION['user']['id_agence'] ?? null;
    return $a === null ? null : (int) $a;
}

function require_login(): void
{
    if (!user()) {
        redirect('connexion');
    }
}

function require_role(string ...$roles): void
{
    require_login();
    if (!in_array(role(), $roles, true)) {
        http_response_code(403);
        flash('error', 'Accès refusé : cette page n\'est pas accessible avec votre rôle.');
        redirect('tableau-de-bord');
    }
}

function attempt_login(string $email, string $password): ?string
{
    $u = row('SELECT e.*, r.libelle_role, a.nom_agence, a.statut_agence
                FROM employe e JOIN role r ON r.id_role = e.id_role
                LEFT JOIN agence a ON a.id_agence = e.id_agence
               WHERE e.email_employe = ?', [$email]);
    if (!$u || !password_verify($password, $u['mot_de_passe'])) {
        return 'Adresse e-mail ou mot de passe incorrect.';
    }
    if ($u['statut_compte'] !== 'Actif') {                                 // RG13
        $jamaisConnecte = !val("SELECT 1 FROM journal_action WHERE id_employe = ? AND type_action = 'Connexion' LIMIT 1", [$u['id_employe']]);
        return $jamaisConnecte
            ? 'Votre inscription est en attente de validation par l\'administrateur.'
            : 'Votre compte est suspendu. Contactez l\'administrateur.';
    }
    if ($u['id_agence'] !== null && $u['statut_agence'] !== 'Active') {
        return 'Votre agence est désactivée.';
    }
    if (password_needs_rehash($u['mot_de_passe'], PASSWORD_DEFAULT)) {
        q('UPDATE employe SET mot_de_passe = ? WHERE id_employe = ?', [password_hash($password, PASSWORD_DEFAULT), $u['id_employe']]);
    }
    session_regenerate_id(true);
    $_SESSION['user'] = [
        'id_employe' => (int) $u['id_employe'],
        'nom'        => $u['nom_employe'],
        'prenom'     => $u['prenom_employe'],
        'email'      => $u['email_employe'],
        'role'       => $u['libelle_role'],
        'id_agence'  => $u['id_agence'] === null ? null : (int) $u['id_agence'],
        'agence'     => $u['nom_agence'],
    ];
    q("INSERT INTO journal_action (type_action, entite_concernee, id_entite, detail_action, id_employe)
       VALUES ('Connexion', 'employe', ?, 'Connexion à l''application', ?)", [$u['id_employe'], $u['id_employe']]);
    return null;
}

function logout(): void
{
    $_SESSION = [];
    session_destroy();
}
