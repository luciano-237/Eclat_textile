<?php
/**
 * Fonctions utilitaires : échappement, URL, messages, formats, formulaires.
 */

function cfg(string $key)
{
    return $GLOBALS['config'][$key] ?? null;
}

function e($v): string
{
    return htmlspecialchars((string) ($v ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function url(string $page, array $params = []): string
{
    $q = array_merge(['p' => $page], $params);
    return 'index.php?' . http_build_query($q);
}

function redirect(string $page, array $params = []): never
{
    header('Location: ' . url($page, $params));
    exit;
}

function back(string $fallbackPage = 'tableau-de-bord'): never
{
    $ref = $_SERVER['HTTP_REFERER'] ?? '';
    if ($ref !== '' && parse_url($ref, PHP_URL_HOST) === ($_SERVER['HTTP_HOST'] ? explode(':', $_SERVER['HTTP_HOST'])[0] : null)) {
        header('Location: ' . $ref);
        exit;
    }
    redirect($fallbackPage);
}

/* ---------------------------------------------------------------- Messages flash */
function flash(string $type, string $msg): void
{
    $_SESSION['flash'][] = ['type' => $type, 'msg' => $msg];
}

function take_flashes(): array
{
    $f = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $f;
}

/* ---------------------------------------------------------------- Formulaires */
function is_post(): bool
{
    return ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">';
}

function csrf_check(): void
{
    if (!hash_equals(csrf_token(), (string) ($_POST['_csrf'] ?? ''))) {
        http_response_code(419);
        flash('error', 'La session du formulaire a expiré. Veuillez réessayer.');
        back();
    }
}

function post(string $k, $default = null)
{
    $v = $_POST[$k] ?? $default;
    return is_string($v) ? trim($v) : $v;
}

function get(string $k, $default = null)
{
    $v = $_GET[$k] ?? $default;
    return is_string($v) ? trim($v) : $v;
}

/** Chaîne vide → NULL (pour les colonnes facultatives). */
function nullable($v)
{
    return ($v === null || $v === '') ? null : $v;
}

function old(string $k, $default = '')
{
    return $_POST[$k] ?? $default;
}

function selected($a, $b): string
{
    return (string) $a === (string) $b ? ' selected' : '';
}

function checked($cond): string
{
    return $cond ? ' checked' : '';
}

/* ---------------------------------------------------------------- Formats */
function money($n, bool $devise = true): string
{
    $s = number_format((float) $n, 0, ',', "\u{00A0}");
    return $devise ? $s . "\u{00A0}" . cfg('devise') : $s;
}

function num($n, int $dec = 0): string
{
    return number_format((float) $n, $dec, ',', "\u{00A0}");
}

function dt(?string $s, bool $time = true): string
{
    if (!$s) {
        return '—';
    }
    $t = strtotime($s);
    return $time ? date('d/m/Y H:i', $t) : date('d/m/Y', $t);
}

function strftime_fr(?int $ts = null): string
{
    $ts = $ts ?? time();
    $jours = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'];
    $mois = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
    return $jours[(int) date('w', $ts)] . ' ' . date('j', $ts) . ' ' . $mois[(int) date('n', $ts) - 1] . ' ' . date('Y', $ts);
}

/** En-tête de page : titre, sous-titre, lien retour, boutons d'action. */
function page_header(string $title, string $subtitle = '', string $actions = '', ?string $backUrl = null): string
{
    $h = '<div class="page-header"><div class="page-header-text">';
    if ($backUrl) {
        $h .= '<a class="back-link" href="' . e($backUrl) . '">' . icon('back', 16) . ' Retour</a>';
    }
    $h .= '<h1>' . e($title) . '</h1>';
    if ($subtitle !== '') {
        $h .= '<p class="page-subtitle">' . $subtitle . '</p>';
    }
    $h .= '</div>';
    if ($actions !== '') {
        $h .= '<div class="page-actions">' . $actions . '</div>';
    }
    return $h . '</div>';
}

function rel_time(?string $s): string
{
    if (!$s) {
        return '—';
    }
    $diff = time() - strtotime($s);
    $future = $diff < 0;
    $d = abs($diff);
    if ($d < 60)        $txt = 'quelques secondes';
    elseif ($d < 3600)  $txt = floor($d / 60) . ' min';
    elseif ($d < 86400) $txt = floor($d / 3600) . ' h';
    elseif ($d < 86400 * 30) $txt = floor($d / 86400) . ' j';
    else return dt($s, false);
    return $future ? 'dans ' . $txt : 'il y a ' . $txt;
}

function initials(?string $nom, ?string $prenom = null): string
{
    $a = mb_substr(trim((string) $prenom), 0, 1);
    $b = mb_substr(trim((string) $nom), 0, 1);
    return mb_strtoupper(($a ?: '') . ($b ?: '')) ?: '?';
}

function full_name(?string $nom, ?string $prenom): string
{
    return trim(($prenom ? $prenom . ' ' : '') . (string) $nom);
}

/* ---------------------------------------------------------------- Badges de statut */
function status_tone(string $s): string
{
    static $map = [
        // commande
        'Enregistrée' => 'neutral', 'Payée' => 'info', 'En traitement' => 'violet', 'Terminée' => 'teal',
        'Partiellement retirée' => 'warning', 'Retirée' => 'good', 'En attente de livreur' => 'warning',
        'En livraison' => 'info', 'Livrée' => 'good', 'Annulée' => 'critical',
        // vêtement
        'Accepté' => 'neutral', 'Refusé' => 'critical', 'Prêt' => 'teal', 'Retiré' => 'good', 'Livré' => 'good',
        // livraison
        'Assignée' => 'info', 'En cours' => 'violet', 'Échouée' => 'critical',
        // incident
        'En attente' => 'warning', 'Clôturé' => 'good',
        // notification
        'Envoyée' => 'good',
        // comptes / agences
        'Active' => 'good', 'Inactive' => 'neutral', 'Actif' => 'good', 'Suspendu' => 'critical',
        'Libre' => 'good', 'Occupé' => 'warning', 'Hors service' => 'neutral',
        // codes
        'Utilisé' => 'neutral', 'Désactivé' => 'critical',
    ];
    return $map[$s] ?? 'neutral';
}

function badge(?string $s, ?string $tone = null): string
{
    if ($s === null || $s === '') {
        return '<span class="badge badge-neutral">—</span>';
    }
    $tone = $tone ?? status_tone($s);
    return '<span class="badge badge-' . $tone . '"><span class="badge-dot"></span>' . e($s) . '</span>';
}

/* ---------------------------------------------------------------- Pagination */
function paginate(int $total, int $perPage = 20): array
{
    $page = max(1, (int) get('page', 1));
    $pages = max(1, (int) ceil($total / $perPage));
    $page = min($page, $pages);
    return ['page' => $page, 'pages' => $pages, 'offset' => ($page - 1) * $perPage, 'limit' => $perPage, 'total' => $total];
}

function pagination_links(array $pg): string
{
    if ($pg['pages'] <= 1) {
        return '';
    }
    $params = $_GET;
    $p = $params['p'] ?? 'tableau-de-bord';
    unset($params['p']);
    $html = '<nav class="pagination"><span class="muted">Page ' . $pg['page'] . ' sur ' . $pg['pages'] . ' · ' . $pg['total'] . ' éléments</span><div class="pagination-links">';
    if ($pg['page'] > 1) {
        $html .= '<a class="btn btn-ghost btn-sm" href="' . e(url($p, array_merge($params, ['page' => $pg['page'] - 1]))) . '">Précédent</a>';
    }
    if ($pg['page'] < $pg['pages']) {
        $html .= '<a class="btn btn-ghost btn-sm" href="' . e(url($p, array_merge($params, ['page' => $pg['page'] + 1]))) . '">Suivant</a>';
    }
    return $html . '</div></nav>';
}

/**
 * Histogramme SVG (une seule série) avec info-bulles au survol.
 * $data : liste de ['label' => 'lun. 12', 'tip' => '12/11', 'value' => 12500]
 */
function bar_chart(array $data, string $unit = ''): string
{
    $w = 720; $h = 220; $padL = 52; $padB = 26; $padT = 8;
    $max = max(1, max(array_column($data, 'value') ?: [0]));
    // graduation « ronde »
    $pow = 10 ** max(0, (int) floor(log10($max)));
    $step = $pow;
    foreach ([1, 2, 2.5, 5, 10] as $m) { if ($max / ($pow * $m) <= 4) { $step = $pow * $m; break; } }
    $top = $step * (int) ceil($max / $step);
    $n = max(1, count($data));
    $plotW = $w - $padL; $plotH = $h - $padB - $padT;
    $slot = $plotW / $n; $bw = min(34, $slot * .58);

    $svg = '<svg viewBox="0 0 ' . $w . ' ' . $h . '" role="img" aria-label="Histogramme">';
    for ($v = 0; $v <= $top + 0.001; $v += $step) {
        $y = $padT + $plotH - ($v / $top) * $plotH;
        $svg .= '<line class="grid-line" x1="' . $padL . '" x2="' . $w . '" y1="' . round($y, 1) . '" y2="' . round($y, 1) . '"/>';
        $lbl = $v >= 1000 ? num($v / 1000, $v % 1000 ? 1 : 0) . 'k' : num($v);
        $svg .= '<text class="axis-label" x="' . ($padL - 10) . '" y="' . round($y + 4, 1) . '" text-anchor="end">' . e($lbl) . '</text>';
    }
    foreach (array_values($data) as $i => $d) {
        $x = $padL + $slot * $i + ($slot - $bw) / 2;
        $bh = $d['value'] > 0 ? max(3, ($d['value'] / $top) * $plotH) : 0;
        $y = $padT + $plotH - $bh;
        $r = min(4, $bw / 2, $bh);
        $svg .= '<g class="bar-group" tabindex="0" data-value="' . e(money($d['value'])) . '" data-label="' . e($d['tip'] ?? $d['label']) . '" data-top="' . round(($y / $h) * 100, 2) . '">';
        $svg .= '<rect class="bar-hit" x="' . round($padL + $slot * $i, 1) . '" y="' . $padT . '" width="' . round($slot, 1) . '" height="' . $plotH . '"/>';
        if ($bh > 0) {
            // barre arrondie en haut, ancrée sur la ligne de base
            $svg .= '<path class="bar" d="M' . round($x, 1) . ',' . round($y + $bh, 1) . ' V' . round($y + $r, 1)
                . ' Q' . round($x, 1) . ',' . round($y, 1) . ' ' . round($x + $r, 1) . ',' . round($y, 1)
                . ' H' . round($x + $bw - $r, 1) . ' Q' . round($x + $bw, 1) . ',' . round($y, 1) . ' ' . round($x + $bw, 1) . ',' . round($y + $r, 1)
                . ' V' . round($y + $bh, 1) . ' Z"/>';
        }
        $svg .= '<text class="axis-label" x="' . round($x + $bw / 2, 1) . '" y="' . ($h - 6) . '" text-anchor="middle">' . e($d['label']) . '</text></g>';
    }
    $svg .= '</svg>';
    return '<div class="chart">' . $svg . '<div class="chart-tip"></div></div>';
}

/** Encaissements des $jours derniers jours (toutes agences ou une seule). */
function encaissements_par_jour(int $jours, ?int $agence = null): array
{
    $params = [$jours - 1];
    $sql = 'SELECT DATE(p.date_paiement) d, SUM(p.montant_paiement) s FROM paiement p JOIN commande c ON c.id_commande = p.id_commande
             WHERE p.date_paiement >= CURRENT_DATE - INTERVAL ? DAY';
    if ($agence !== null) { $sql .= ' AND c.id_agence = ?'; $params[] = $agence; }
    $sql .= ' GROUP BY DATE(p.date_paiement)';
    $sums = [];
    foreach (rows($sql, $params) as $r) { $sums[$r['d']] = (float) $r['s']; }
    $jn = ['dim.', 'lun.', 'mar.', 'mer.', 'jeu.', 'ven.', 'sam.'];
    $out = [];
    for ($i = $jours - 1; $i >= 0; $i--) {
        $ts = strtotime("-$i days");
        $d = date('Y-m-d', $ts);
        $out[] = ['label' => $jn[(int) date('w', $ts)] . ' ' . date('j', $ts), 'tip' => strftime_fr($ts), 'value' => $sums[$d] ?? 0];
    }
    return $out;
}

/** Tuile d'indicateur. */
function kpi(string $label, string $value, string $icon, string $tone = 'teal', string $foot = ''): string
{
    return '<div class="card kpi"><div class="kpi-top"><span class="kpi-label">' . e($label) . '</span><span class="kpi-icon tone-' . $tone . '">'
        . icon($icon, 19) . '</span></div><div class="kpi-value">' . $value . '</div>'
        . ($foot !== '' ? '<div class="kpi-foot">' . $foot . '</div>' : '') . '</div>';
}

/** Montant formaté pour une tuile (devise en petit). */
function kpi_money($n): string
{
    return num($n) . '<small>' . e(cfg('devise')) . '</small>';
}

/** Bloc « aucun résultat » illustré. */
function empty_state(string $title, string $text = '', string $icon = 'inbox', string $action = ''): string
{
    return '<div class="empty"><div class="empty-icon">' . icon($icon, 28) . '</div><h3>' . e($title) . '</h3>'
        . ($text ? '<p>' . e($text) . '</p>' : '') . $action . '</div>';
}
