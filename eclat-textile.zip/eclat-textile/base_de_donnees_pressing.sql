-- =============================================================================
--  BASE DE DONNÉES « pressing » — Script de création complet — VERSION 4
--  Projet : Application de gestion de pressing multi-agences
--  KEYCE Informatique et IA — Méthode MERISE — MCD / MLD version 4
--  Source : « Règles de gestion et dictionnaire des données — version 2 »
--           et « Description du fonctionnement du système de A à Z »
--  SGBD : MySQL 8.4 LTS
--
--  Contenu :
--    1. Création de la base
--    2. Tables (22) : clés primaires, 33 clés étrangères, contraintes CHECK
--    3. Index de recherche
--    4. Fonctions de calcul (montants, frais de retard, fidélité)
--    5. Déclencheurs : règles de gestion appliquées automatiquement
--    6. Procédures : affectation des livraisons en attente, régénération du code
--    7. Vues : requêtes prêtes à l'emploi (montants, retards, tableau de bord…)
--    8. Données de référence (rôles, suppléments, catégories)
--
--  ATTENTION : ce script SUPPRIME la base « pressing » si elle existe déjà.
--  Exécution :  mysql -u root -p < base_de_donnees_pressing.sql
--
--  Variable de session utilisée par le journal (RG90) : l'application exécute
--      SET @id_employe_session = <id de l'employé connecté>;
--  après la connexion, pour que les actions sensibles soient attribuées.
-- =============================================================================

SET NAMES utf8mb4;

DROP DATABASE IF EXISTS pressing;
CREATE DATABASE pressing CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE pressing;


-- =============================================================================
-- 2. TABLES
--    Aucune suppression en cascade : l'historique est toujours conservé.
-- =============================================================================

-- ----------------------------------------------------------------- ROLE (RG08)
CREATE TABLE role (
    id_role      TINYINT UNSIGNED NOT NULL AUTO_INCREMENT,
    libelle_role VARCHAR(20)      NOT NULL,
    CONSTRAINT pk_role PRIMARY KEY (id_role),
    CONSTRAINT uq_role_libelle UNIQUE (libelle_role),
    CONSTRAINT ck_role_libelle CHECK (libelle_role IN ('Administrateur', 'Gérant', 'Livreur'))
) ENGINE = InnoDB COMMENT = 'Rôles : administrateur, gérant, livreur (RG08)';

-- ----------------------------------------------------------------- AGENCE (RG01 à RG06, RG39)
-- La configuration de base de l'agence sert à tous les calculs ; elle est
-- copiée dans chaque commande à son enregistrement (RG04, RG38).
CREATE TABLE agence (
    id_agence                 INT UNSIGNED     NOT NULL AUTO_INCREMENT,
    nom_agence                VARCHAR(60)      NOT NULL,
    adresse_agence            VARCHAR(150)     NOT NULL,
    ville_agence              VARCHAR(50)      NOT NULL,
    telephone_agence          VARCHAR(20)      NOT NULL,
    statut_agence             VARCHAR(10)      NOT NULL DEFAULT 'Active',
    date_creation_agence      DATE             NOT NULL DEFAULT (CURRENT_DATE),
    duree_normal_h            SMALLINT UNSIGNED NOT NULL COMMENT 'Durée du service normal, en heures',
    duree_express_h           SMALLINT UNSIGNED NOT NULL COMMENT 'Durée du service express, en heures',
    taux_majoration_express   DECIMAL(5,2)     NOT NULL DEFAULT 30,
    seuil_poids_kg            DECIMAL(6,2)     NOT NULL DEFAULT 3,
    tarif_kg                  DECIMAL(10,2)    NOT NULL DEFAULT 500,
    prix_piece_hors_categorie DECIMAL(10,2)    NOT NULL DEFAULT 500,
    delai_grace_jours         SMALLINT UNSIGNED NOT NULL DEFAULT 14,
    frais_retard_jour         DECIMAL(10,2)    NOT NULL DEFAULT 100,
    seuil_fidelite            SMALLINT UNSIGNED NOT NULL DEFAULT 10,
    taux_fidelite             DECIMAL(5,2)     NOT NULL DEFAULT 3,
    CONSTRAINT pk_agence PRIMARY KEY (id_agence),
    CONSTRAINT uq_agence_nom UNIQUE (nom_agence),
    CONSTRAINT ck_agence_statut CHECK (statut_agence IN ('Active', 'Inactive')),
    CONSTRAINT ck_agence_durees CHECK (duree_normal_h > 0 AND duree_express_h > 0 AND duree_express_h < duree_normal_h),
    CONSTRAINT ck_agence_taux CHECK (taux_majoration_express >= 0 AND taux_fidelite BETWEEN 0 AND 100),
    CONSTRAINT ck_agence_tarifs CHECK (seuil_poids_kg > 0 AND tarif_kg > 0 AND prix_piece_hors_categorie > 0
                                       AND frais_retard_jour >= 0 AND seuil_fidelite > 0)
) ENGINE = InnoDB COMMENT = 'Agences du réseau et leur configuration (RG01 à RG06)';

-- ----------------------------------------------------------------- EMPLOYE (RG07 à RG15)
-- id_agence NULL : administrateur (rattaché à aucune agence, RG09).
-- disponibilite_livreur : renseignée pour les livreurs uniquement (RG14).
CREATE TABLE employe (
    id_employe            INT UNSIGNED     NOT NULL AUTO_INCREMENT,
    nom_employe           VARCHAR(50)      NOT NULL,
    prenom_employe        VARCHAR(50)      NULL,
    telephone_employe     VARCHAR(20)      NOT NULL,
    email_employe         VARCHAR(120)     NOT NULL COMMENT 'Identifiant de connexion',
    mot_de_passe          VARCHAR(255)     NOT NULL COMMENT 'Empreinte sécurisée, jamais en clair',
    statut_compte         VARCHAR(10)      NOT NULL DEFAULT 'Actif',
    date_embauche         DATE             NULL,
    disponibilite_livreur VARCHAR(12)      NULL,
    id_role               TINYINT UNSIGNED NOT NULL,
    id_agence             INT UNSIGNED     NULL,
    CONSTRAINT pk_employe PRIMARY KEY (id_employe),
    CONSTRAINT uq_employe_email UNIQUE (email_employe),
    CONSTRAINT ck_employe_statut CHECK (statut_compte IN ('Actif', 'Suspendu')),
    CONSTRAINT ck_employe_dispo CHECK (disponibilite_livreur IS NULL
                                       OR disponibilite_livreur IN ('Libre', 'Occupé', 'Hors service')),
    CONSTRAINT fk_employe_role FOREIGN KEY (id_role) REFERENCES role (id_role)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT fk_employe_agence FOREIGN KEY (id_agence) REFERENCES agence (id_agence)
        ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB COMMENT = 'Employés (AVOIR, TRAVAILLER)';

-- ----------------------------------------------------------------- CLIENT (RG16, RG17)
CREATE TABLE client (
    id_client        INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nom_client       VARCHAR(50)  NOT NULL,
    prenom_client    VARCHAR(50)  NULL,
    telephone_client VARCHAR(20)  NOT NULL COMMENT 'Unique : identifie le client, reçoit SMS et WhatsApp',
    email_client     VARCHAR(120) NULL,
    adresse_client   VARCHAR(255) NULL COMMENT 'Obligatoire si le client demande une livraison',
    date_inscription DATE         NOT NULL DEFAULT (CURRENT_DATE),
    id_agence        INT UNSIGNED NOT NULL COMMENT 'Agence de fidélité',
    CONSTRAINT pk_client PRIMARY KEY (id_client),
    CONSTRAINT uq_client_telephone UNIQUE (telephone_client),
    CONSTRAINT fk_client_agence FOREIGN KEY (id_agence) REFERENCES agence (id_agence)
        ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB COMMENT = 'Clients (RATTACHER : agence de fidélité)';

-- ----------------------------------------------------------------- CATEGORIE_ARTICLE, ARTICLE (RG22)
CREATE TABLE categorie_article (
    id_categorie          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    libelle_categorie     VARCHAR(60)  NOT NULL,
    description_categorie VARCHAR(255) NULL,
    CONSTRAINT pk_categorie_article PRIMARY KEY (id_categorie),
    CONSTRAINT uq_categorie_libelle UNIQUE (libelle_categorie)
) ENGINE = InnoDB COMMENT = 'Catégories d''articles (costumes, robes, linge de maison…)';

CREATE TABLE article (
    id_article      INT UNSIGNED NOT NULL AUTO_INCREMENT,
    libelle_article VARCHAR(60)  NOT NULL COMMENT 'Nature du vêtement : chemise, veste, drap…',
    id_categorie    INT UNSIGNED NOT NULL,
    CONSTRAINT pk_article PRIMARY KEY (id_article),
    CONSTRAINT uq_article_libelle UNIQUE (libelle_article),
    CONSTRAINT fk_article_categorie FOREIGN KEY (id_categorie) REFERENCES categorie_article (id_categorie)
        ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB COMMENT = 'Natures de vêtements (REGROUPER)';

-- ----------------------------------------------------------------- TARIF_CATEGORIE (RG23 à RG25)
-- Table issue de l'association n,n AGENCE – CATEGORIE_ARTICLE (règle R5).
CREATE TABLE tarif_categorie (
    id_agence         INT UNSIGNED  NOT NULL,
    id_categorie      INT UNSIGNED  NOT NULL,
    prix_categorie    DECIMAL(10,2) NOT NULL COMMENT 'Prix à la pièce, calculé pour l''état le plus sale (RG24)',
    unite_facturation VARCHAR(6)    NOT NULL,
    actif_tarif       BOOLEAN       NOT NULL DEFAULT TRUE,
    CONSTRAINT pk_tarif_categorie PRIMARY KEY (id_agence, id_categorie),
    CONSTRAINT ck_tarif_categorie_prix CHECK (prix_categorie > 0),
    CONSTRAINT ck_tarif_categorie_unite CHECK (unite_facturation IN ('Pièce', 'Poids')),
    CONSTRAINT fk_tarif_categorie_agence FOREIGN KEY (id_agence) REFERENCES agence (id_agence)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT fk_tarif_categorie_categorie FOREIGN KEY (id_categorie) REFERENCES categorie_article (id_categorie)
        ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB COMMENT = 'Tarif et unité de facturation de chaque catégorie, par agence';

-- ----------------------------------------------------------------- SUPPLEMENT, TARIF_SUPPLEMENT (RG41, RG42)
CREATE TABLE supplement (
    id_supplement          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    libelle_supplement     VARCHAR(60)  NOT NULL,
    description_supplement VARCHAR(255) NULL,
    portee_supplement      VARCHAR(10)  NOT NULL,
    CONSTRAINT pk_supplement PRIMARY KEY (id_supplement),
    CONSTRAINT uq_supplement_libelle UNIQUE (libelle_supplement),
    CONSTRAINT ck_supplement_portee CHECK (portee_supplement IN ('Vêtement', 'Commande'))
) ENGINE = InnoDB COMMENT = 'Suppléments : repassage, détachage, livraison à domicile…';

CREATE TABLE tarif_supplement (
    id_agence        INT UNSIGNED  NOT NULL,
    id_supplement    INT UNSIGNED  NOT NULL,
    prix_supplement  DECIMAL(10,2) NOT NULL,
    actif_supplement BOOLEAN       NOT NULL DEFAULT TRUE,
    CONSTRAINT pk_tarif_supplement PRIMARY KEY (id_agence, id_supplement),
    CONSTRAINT ck_tarif_supplement_prix CHECK (prix_supplement >= 0),
    CONSTRAINT fk_tarif_supplement_agence FOREIGN KEY (id_agence) REFERENCES agence (id_agence)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT fk_tarif_supplement_supplement FOREIGN KEY (id_supplement) REFERENCES supplement (id_supplement)
        ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB COMMENT = 'Prix de chaque supplément, par agence';

-- ----------------------------------------------------------------- COMMANDE (RG32 à RG38)
-- Les colonnes *_applique sont copiées depuis l'agence à l'enregistrement (RG38) :
-- une modification de la configuration ne change jamais une commande existante.
-- Les montants ne sont pas stockés : ils sont recalculés par les fonctions (RG92).
CREATE TABLE commande (
    id_commande              INT UNSIGNED      NOT NULL AUTO_INCREMENT,
    numero_commande          VARCHAR(30)       NOT NULL COMMENT 'Numéro lisible imprimé sur le ticket',
    date_commande            DATETIME          NOT NULL DEFAULT CURRENT_TIMESTAMP,
    statut_commande          VARCHAR(25)       NOT NULL DEFAULT 'Enregistrée',
    type_service             VARCHAR(10)       NOT NULL DEFAULT 'Normal',
    mode_recuperation        VARCHAR(10)       NOT NULL DEFAULT 'Retrait',
    duree_appliquee_h        SMALLINT UNSIGNED NOT NULL,
    taux_majoration_applique DECIMAL(5,2)      NOT NULL,
    tarif_kg_applique        DECIMAL(10,2)     NOT NULL,
    seuil_poids_applique     DECIMAL(6,2)      NOT NULL,
    prix_hors_cat_applique   DECIMAL(10,2)     NOT NULL,
    delai_grace_applique     SMALLINT UNSIGNED NOT NULL,
    frais_retard_applique    DECIMAL(10,2)     NOT NULL,
    taux_remise              DECIMAL(5,2)      NOT NULL DEFAULT 0 COMMENT 'Réduction de fidélité appliquée (RG20)',
    date_paiement_integral   DATETIME          NULL,
    date_retrait_effective   DATETIME          NULL COMMENT 'Récupération complète ou livraison',
    id_agence                INT UNSIGNED      NOT NULL,
    id_client                INT UNSIGNED      NOT NULL,
    id_employe               INT UNSIGNED      NOT NULL COMMENT 'Gérant qui a enregistré la commande',
    CONSTRAINT pk_commande PRIMARY KEY (id_commande),
    CONSTRAINT uq_commande_numero UNIQUE (numero_commande),
    CONSTRAINT ck_commande_statut CHECK (statut_commande IN ('Enregistrée', 'Payée', 'En traitement', 'Terminée',
        'Partiellement retirée', 'Retirée', 'En attente de livreur', 'En livraison', 'Livrée', 'Annulée')),
    CONSTRAINT ck_commande_service CHECK (type_service IN ('Normal', 'Express')),
    CONSTRAINT ck_commande_mode CHECK (mode_recuperation IN ('Retrait', 'Livraison')),
    CONSTRAINT ck_commande_majoration CHECK (taux_majoration_applique >= 0
                                             AND (type_service = 'Express' OR taux_majoration_applique = 0)),
    CONSTRAINT ck_commande_valeurs CHECK (duree_appliquee_h > 0 AND tarif_kg_applique > 0 AND seuil_poids_applique > 0
                                          AND prix_hors_cat_applique > 0 AND frais_retard_applique >= 0),
    CONSTRAINT ck_commande_remise CHECK (taux_remise BETWEEN 0 AND 100),
    CONSTRAINT ck_commande_dates CHECK ((date_paiement_integral IS NULL OR date_paiement_integral >= date_commande)
                                        AND (date_retrait_effective IS NULL OR date_retrait_effective >= date_commande)),
    CONSTRAINT fk_commande_agence FOREIGN KEY (id_agence) REFERENCES agence (id_agence)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT fk_commande_client FOREIGN KEY (id_client) REFERENCES client (id_client)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT fk_commande_employe FOREIGN KEY (id_employe) REFERENCES employe (id_employe)
        ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB COMMENT = 'Commandes (DEPOSER, PASSER, ENREGISTRER)';

-- ----------------------------------------------------------------- RETRAIT (RG71 à RG73)
-- Créé avant VETEMENT, qui le référence (retrait partiel : REMETTRE).
CREATE TABLE retrait (
    id_retrait          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    date_retrait        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    nom_retirant        VARCHAR(100) NOT NULL,
    est_client          BOOLEAN      NOT NULL,
    mode_verification   VARCHAR(15)  NOT NULL,
    type_piece_identite VARCHAR(20)  NULL,
    num_piece_identite  VARCHAR(30)  NULL,
    id_commande         INT UNSIGNED NOT NULL,
    id_employe          INT UNSIGNED NOT NULL COMMENT 'Gérant qui a validé le retrait',
    CONSTRAINT pk_retrait PRIMARY KEY (id_retrait),
    CONSTRAINT ck_retrait_mode CHECK (mode_verification IN ('QR code', 'Code numérique', 'Identité')),
    CONSTRAINT ck_retrait_piece CHECK (type_piece_identite IS NULL
                                       OR type_piece_identite IN ('CNI', 'Passeport', 'Permis de conduire', 'Autre')),
    CONSTRAINT ck_retrait_tiers CHECK (est_client = TRUE
                                       OR (type_piece_identite IS NOT NULL AND num_piece_identite IS NOT NULL)),
    CONSTRAINT fk_retrait_commande FOREIGN KEY (id_commande) REFERENCES commande (id_commande)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT fk_retrait_employe FOREIGN KEY (id_employe) REFERENCES employe (id_employe)
        ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB COMMENT = 'Retraits en agence, éventuellement partiels (RETIRER, VALIDER)';

-- ----------------------------------------------------------------- VETEMENT (RG26 à RG31)
-- prix_applique NULL = vêtement du lot au poids (tri automatique, RG27).
CREATE TABLE vetement (
    id_vetement         INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    code_etiquette      VARCHAR(40)   NOT NULL,
    poids_kg            DECIMAL(6,3)  NOT NULL,
    etat_initial        VARCHAR(255)  NOT NULL,
    anomalies           VARCHAR(255)  NULL,
    prix_applique       DECIMAL(10,2) NULL COMMENT 'Prix de la catégorie copié au dépôt ; NULL si lot au poids',
    majoration_speciale DECIMAL(10,2) NOT NULL DEFAULT 0,
    accord_client       BOOLEAN       NOT NULL DEFAULT FALSE,
    date_accord         DATETIME      NULL,
    statut_vetement     VARCHAR(15)   NOT NULL DEFAULT 'Accepté',
    motif_refus         VARCHAR(255)  NULL,
    id_commande         INT UNSIGNED  NOT NULL,
    id_article          INT UNSIGNED  NOT NULL,
    id_retrait          INT UNSIGNED  NULL COMMENT 'Retrait au cours duquel le vêtement a été remis (RG72)',
    CONSTRAINT pk_vetement PRIMARY KEY (id_vetement),
    CONSTRAINT uq_vetement_etiquette UNIQUE (code_etiquette),
    CONSTRAINT ck_vetement_poids CHECK (poids_kg > 0),
    CONSTRAINT ck_vetement_prix CHECK (prix_applique IS NULL OR prix_applique >= 0),
    CONSTRAINT ck_vetement_statut CHECK (statut_vetement IN ('Accepté', 'Refusé', 'En traitement', 'Prêt', 'Retiré', 'Livré')),
    CONSTRAINT ck_vetement_majoration CHECK (majoration_speciale >= 0
        AND (majoration_speciale = 0 OR (accord_client = TRUE AND date_accord IS NOT NULL))),
    CONSTRAINT ck_vetement_refus CHECK (statut_vetement <> 'Refusé'
        OR (motif_refus IS NOT NULL AND prix_applique IS NULL AND majoration_speciale = 0)),
    CONSTRAINT fk_vetement_commande FOREIGN KEY (id_commande) REFERENCES commande (id_commande)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT fk_vetement_article FOREIGN KEY (id_article) REFERENCES article (id_article)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT fk_vetement_retrait FOREIGN KEY (id_retrait) REFERENCES retrait (id_retrait)
        ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB COMMENT = 'Vêtements déposés, pesés et étiquetés (CONTENIR, ETRE_DE_NATURE, REMETTRE)';

-- ----------------------------------------------------------------- SUPPLEMENT_APPLIQUE (RG43, RG44)
-- id_vetement renseigné seulement pour un supplément de portée « Vêtement ».
CREATE TABLE supplement_applique (
    id_supp_applique   INT UNSIGNED      NOT NULL AUTO_INCREMENT,
    prix_supp_applique DECIMAL(10,2)     NOT NULL COMMENT 'Prix copié depuis l''agence (RG38)',
    quantite_supp      SMALLINT UNSIGNED NOT NULL DEFAULT 1,
    id_commande        INT UNSIGNED      NOT NULL,
    id_supplement      INT UNSIGNED      NOT NULL,
    id_vetement        INT UNSIGNED      NULL,
    CONSTRAINT pk_supplement_applique PRIMARY KEY (id_supp_applique),
    CONSTRAINT ck_supp_applique_valeurs CHECK (prix_supp_applique >= 0 AND quantite_supp >= 1),
    CONSTRAINT fk_supp_applique_commande FOREIGN KEY (id_commande) REFERENCES commande (id_commande)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT fk_supp_applique_supplement FOREIGN KEY (id_supplement) REFERENCES supplement (id_supplement)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT fk_supp_applique_vetement FOREIGN KEY (id_vetement) REFERENCES vetement (id_vetement)
        ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB COMMENT = 'Suppléments choisis (AJOUTER, CORRESPONDRE, CONCERNER)';

-- ----------------------------------------------------------------- PAIEMENT (RG50 à RG53)
CREATE TABLE paiement (
    id_paiement        INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    montant_paiement   DECIMAL(10,2) NOT NULL,
    date_paiement      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    mode_paiement      VARCHAR(20)   NOT NULL,
    reference_paiement VARCHAR(60)   NULL,
    objet_paiement     VARCHAR(15)   NOT NULL DEFAULT 'Commande',
    id_commande        INT UNSIGNED  NOT NULL,
    id_employe         INT UNSIGNED  NOT NULL COMMENT 'Gérant qui a encaissé (RG53)',
    CONSTRAINT pk_paiement PRIMARY KEY (id_paiement),
    CONSTRAINT uq_paiement_reference UNIQUE (reference_paiement),
    CONSTRAINT ck_paiement_montant CHECK (montant_paiement > 0),
    CONSTRAINT ck_paiement_mode CHECK (mode_paiement IN ('Espèces', 'MTN Mobile Money', 'Orange Money', 'Autre')),
    CONSTRAINT ck_paiement_reference CHECK (mode_paiement = 'Espèces' OR reference_paiement IS NOT NULL),
    CONSTRAINT ck_paiement_objet CHECK (objet_paiement IN ('Commande', 'Frais de retard')),
    CONSTRAINT fk_paiement_commande FOREIGN KEY (id_commande) REFERENCES commande (id_commande)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT fk_paiement_employe FOREIGN KEY (id_employe) REFERENCES employe (id_employe)
        ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB COMMENT = 'Paiements (REGLER, ENCAISSER)';

-- ----------------------------------------------------------------- FACTURE (RG54 à RG56)
-- Au plus une facture principale et une facture de frais de retard par commande.
CREATE TABLE facture (
    id_facture      INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    numero_facture  VARCHAR(40)   NOT NULL,
    type_facture    VARCHAR(15)   NOT NULL,
    date_facture    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    montant_facture DECIMAL(12,2) NOT NULL COMMENT 'Figé à l''émission, non modifiable',
    id_commande     INT UNSIGNED  NOT NULL,
    CONSTRAINT pk_facture PRIMARY KEY (id_facture),
    CONSTRAINT uq_facture_numero UNIQUE (numero_facture),
    CONSTRAINT uq_facture_commande_type UNIQUE (id_commande, type_facture),
    CONSTRAINT ck_facture_type CHECK (type_facture IN ('Principale', 'Frais de retard')),
    CONSTRAINT ck_facture_montant CHECK (montant_facture > 0),
    CONSTRAINT fk_facture_commande FOREIGN KEY (id_commande) REFERENCES commande (id_commande)
        ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB COMMENT = 'Factures (FACTURER, cardinalité 0,2)';

-- ----------------------------------------------------------------- CODE_VALIDATION (RG57 à RG61)
-- code_actif vaut id_commande pour un code « Actif » et NULL sinon :
-- l'index UNIQUE interdit deux codes actifs pour une même commande.
CREATE TABLE code_validation (
    id_code          INT UNSIGNED NOT NULL AUTO_INCREMENT,
    valeur_qr        VARCHAR(64)  NOT NULL COMMENT 'Valeur encodée dans le QR code',
    code_numerique   CHAR(6)      NOT NULL,
    statut_code      VARCHAR(10)  NOT NULL DEFAULT 'Actif',
    date_generation  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    date_utilisation DATETIME     NULL,
    id_commande      INT UNSIGNED NOT NULL,
    code_actif       INT UNSIGNED GENERATED ALWAYS AS (IF(statut_code = 'Actif', id_commande, NULL)) STORED,
    CONSTRAINT pk_code_validation PRIMARY KEY (id_code),
    CONSTRAINT uq_code_valeur UNIQUE (valeur_qr),
    CONSTRAINT uq_code_un_seul_actif UNIQUE (code_actif),
    CONSTRAINT ck_code_numerique CHECK (code_numerique REGEXP '^[0-9]{6}$'),
    CONSTRAINT ck_code_statut CHECK (statut_code IN ('Actif', 'Utilisé', 'Désactivé')),
    CONSTRAINT ck_code_dates CHECK (date_utilisation IS NULL OR date_utilisation >= date_generation),
    CONSTRAINT fk_code_commande FOREIGN KEY (id_commande) REFERENCES commande (id_commande)
        ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB COMMENT = 'Codes de validation : QR code + code numérique (IDENTIFIER)';

-- ----------------------------------------------------------------- LIVRAISON (RG62 à RG70)
-- id_commande UNIQUE : une commande a au plus une livraison (règle R4).
-- id_employe NULL : livraison en attente de livreur (règle R3).
CREATE TABLE livraison (
    id_livraison             INT UNSIGNED     NOT NULL AUTO_INCREMENT,
    adresse_livraison        VARCHAR(255)     NOT NULL,
    statut_livraison         VARCHAR(25)      NOT NULL DEFAULT 'En attente de livreur',
    date_creation_livraison  DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
    date_assignation         DATETIME         NULL,
    date_recuperation_agence DATETIME         NULL,
    date_livraison           DATETIME         NULL,
    mode_validation          VARCHAR(15)      NULL,
    nb_tentatives            TINYINT UNSIGNED NOT NULL DEFAULT 0,
    motif_echec              VARCHAR(255)     NULL,
    id_commande              INT UNSIGNED     NOT NULL,
    id_employe               INT UNSIGNED     NULL COMMENT 'Livreur affecté',
    CONSTRAINT pk_livraison PRIMARY KEY (id_livraison),
    CONSTRAINT uq_livraison_commande UNIQUE (id_commande),
    CONSTRAINT ck_livraison_statut CHECK (statut_livraison IN
        ('En attente de livreur', 'Assignée', 'En cours', 'Livrée', 'Échouée')),
    CONSTRAINT ck_livraison_validation CHECK (mode_validation IS NULL OR mode_validation IN ('QR code', 'Code numérique')),
    CONSTRAINT ck_livraison_livreur CHECK (statut_livraison NOT IN ('Assignée', 'En cours', 'Livrée') OR id_employe IS NOT NULL),
    CONSTRAINT ck_livraison_livree CHECK (statut_livraison <> 'Livrée'
                                          OR (date_livraison IS NOT NULL AND mode_validation IS NOT NULL)),
    CONSTRAINT ck_livraison_echec CHECK (statut_livraison <> 'Échouée' OR motif_echec IS NOT NULL),
    CONSTRAINT ck_livraison_dates CHECK ((date_assignation IS NULL OR date_assignation >= date_creation_livraison)
        AND (date_recuperation_agence IS NULL OR date_assignation IS NULL OR date_recuperation_agence >= date_assignation)
        AND (date_livraison IS NULL OR date_recuperation_agence IS NULL OR date_livraison >= date_recuperation_agence)),
    CONSTRAINT fk_livraison_commande FOREIGN KEY (id_commande) REFERENCES commande (id_commande)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT fk_livraison_employe FOREIGN KEY (id_employe) REFERENCES employe (id_employe)
        ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB COMMENT = 'Livraisons à domicile (LIVRER, EFFECTUER)';

-- ----------------------------------------------------------------- PREUVE_LIVRAISON (RG68)
CREATE TABLE preuve_livraison (
    id_preuve    INT UNSIGNED NOT NULL AUTO_INCREMENT,
    url_photo    VARCHAR(255) NOT NULL,
    date_prise   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    id_livraison INT UNSIGNED NOT NULL,
    CONSTRAINT pk_preuve_livraison PRIMARY KEY (id_preuve),
    CONSTRAINT fk_preuve_livraison FOREIGN KEY (id_livraison) REFERENCES livraison (id_livraison)
        ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB COMMENT = 'Photos justificatives des livraisons (JUSTIFIER)';

-- ----------------------------------------------------------------- INCIDENT, IMPLIQUER (RG80 à RG83)
CREATE TABLE incident (
    id_incident          INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    date_incident        DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    type_incident        VARCHAR(25)   NOT NULL,
    motif_incident       VARCHAR(255)  NOT NULL,
    description_incident TEXT          NULL,
    statut_incident      VARCHAR(10)   NOT NULL DEFAULT 'En attente',
    observation          TEXT          NULL,
    solution_apportee    VARCHAR(255)  NULL,
    montant_compensation DECIMAL(10,2) NOT NULL DEFAULT 0,
    date_cloture         DATETIME      NULL,
    id_commande          INT UNSIGNED  NOT NULL,
    id_employe           INT UNSIGNED  NOT NULL COMMENT 'Employé qui a déclaré l''incident',
    CONSTRAINT pk_incident PRIMARY KEY (id_incident),
    CONSTRAINT ck_incident_type CHECK (type_incident IN
        ('Perte', 'Détérioration', 'Erreur de traitement', 'Réclamation', 'Échec de livraison')),
    CONSTRAINT ck_incident_statut CHECK (statut_incident IN ('En attente', 'En cours', 'Clôturé')),
    CONSTRAINT ck_incident_montant CHECK (montant_compensation >= 0),
    CONSTRAINT ck_incident_cloture CHECK (statut_incident <> 'Clôturé'
                                          OR (solution_apportee IS NOT NULL AND date_cloture IS NOT NULL)),
    CONSTRAINT ck_incident_dates CHECK (date_cloture IS NULL OR date_cloture >= date_incident),
    CONSTRAINT fk_incident_commande FOREIGN KEY (id_commande) REFERENCES commande (id_commande)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT fk_incident_employe FOREIGN KEY (id_employe) REFERENCES employe (id_employe)
        ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB COMMENT = 'Incidents et réclamations (SIGNALER, DECLARER)';

CREATE TABLE impliquer (
    id_incident INT UNSIGNED NOT NULL,
    id_vetement INT UNSIGNED NOT NULL,
    CONSTRAINT pk_impliquer PRIMARY KEY (id_incident, id_vetement),
    CONSTRAINT fk_impliquer_incident FOREIGN KEY (id_incident) REFERENCES incident (id_incident)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT fk_impliquer_vetement FOREIGN KEY (id_vetement) REFERENCES vetement (id_vetement)
        ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB COMMENT = 'Vêtements concernés par un incident (association n,n)';

-- ----------------------------------------------------------------- NOTIFICATION (RG84 à RG88)
CREATE TABLE notification (
    id_notification   INT UNSIGNED NOT NULL AUTO_INCREMENT,
    type_notification VARCHAR(20)  NOT NULL,
    canal             VARCHAR(10)  NOT NULL DEFAULT 'WhatsApp',
    contenu           TEXT         NOT NULL,
    date_notification DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    statut_envoi      VARCHAR(10)  NOT NULL DEFAULT 'En attente',
    resultat          VARCHAR(255) NULL,
    id_client         INT UNSIGNED NOT NULL,
    id_commande       INT UNSIGNED NULL,
    CONSTRAINT pk_notification PRIMARY KEY (id_notification),
    CONSTRAINT ck_notification_type CHECK (type_notification IN ('Dépôt', 'Paiement', 'Code de validation',
        'Disponibilité', 'Rappel de retrait', 'Affectation livreur', 'Livraison')),
    CONSTRAINT ck_notification_canal CHECK (canal IN ('SMS', 'WhatsApp')),
    CONSTRAINT ck_notification_statut CHECK (statut_envoi IN ('En attente', 'Envoyée', 'Échouée')),
    CONSTRAINT fk_notification_client FOREIGN KEY (id_client) REFERENCES client (id_client)
        ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT fk_notification_commande FOREIGN KEY (id_commande) REFERENCES commande (id_commande)
        ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB COMMENT = 'Notifications SMS / WhatsApp (RECEVOIR, PORTER_SUR)';

-- ----------------------------------------------------------------- JOURNAL_ACTION (RG89 à RG91)
CREATE TABLE journal_action (
    id_action        BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    date_action      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    type_action      VARCHAR(15)     NOT NULL,
    entite_concernee VARCHAR(40)     NOT NULL,
    id_entite        BIGINT UNSIGNED NOT NULL,
    detail_action    TEXT            NOT NULL,
    id_employe       INT UNSIGNED    NOT NULL,
    CONSTRAINT pk_journal_action PRIMARY KEY (id_action),
    CONSTRAINT ck_journal_type CHECK (type_action IN
        ('Création', 'Modification', 'Suppression', 'Annulation', 'Connexion', 'Autre')),
    CONSTRAINT fk_journal_employe FOREIGN KEY (id_employe) REFERENCES employe (id_employe)
        ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB COMMENT = 'Journal des actions, ni modifiable ni supprimable (TRACER)';


-- =============================================================================
-- 3. INDEX DE RECHERCHE (les clés étrangères sont déjà indexées par MySQL)
-- =============================================================================
CREATE INDEX idx_client_nom        ON client (nom_client, prenom_client);
CREATE INDEX idx_commande_statut   ON commande (id_agence, statut_commande);
CREATE INDEX idx_commande_date     ON commande (date_commande);
CREATE INDEX idx_livraison_attente ON livraison (statut_livraison, date_creation_livraison);
CREATE INDEX idx_employe_livreur   ON employe (id_agence, disponibilite_livreur);
CREATE INDEX idx_paiement_date     ON paiement (date_paiement);
CREATE INDEX idx_journal_date      ON journal_action (date_action);


-- =============================================================================
-- 4. FONCTIONS DE CALCUL
--    Les données calculées du dictionnaire (montants, poids du lot, frais de
--    retard, compteur de fidélité) ne sont pas stockées (RG92) : elles sont
--    recalculées à partir des données élémentaires et des valeurs copiées.
-- =============================================================================
DELIMITER //

-- RG27 à RG29, RG47 : montant des vêtements = pièces + lot au poids + majorations spéciales acceptées
CREATE FUNCTION fn_montant_vetements(p_commande INT UNSIGNED)
RETURNS DECIMAL(12,2)
READS SQL DATA
BEGIN
    DECLARE v_seuil, v_tarif_kg, v_prix_hc DECIMAL(10,2);
    DECLARE v_pieces, v_poids, v_maj DECIMAL(12,3) DEFAULT 0;
    DECLARE v_nb INT DEFAULT 0;
    SELECT seuil_poids_applique, tarif_kg_applique, prix_hors_cat_applique
      INTO v_seuil, v_tarif_kg, v_prix_hc FROM commande WHERE id_commande = p_commande;
    SELECT COALESCE(SUM(prix_applique), 0) INTO v_pieces
      FROM vetement WHERE id_commande = p_commande AND statut_vetement <> 'Refusé' AND prix_applique IS NOT NULL;
    SELECT COALESCE(SUM(poids_kg), 0), COUNT(*) INTO v_poids, v_nb
      FROM vetement WHERE id_commande = p_commande AND statut_vetement <> 'Refusé' AND prix_applique IS NULL;
    SELECT COALESCE(SUM(majoration_speciale), 0) INTO v_maj
      FROM vetement WHERE id_commande = p_commande AND statut_vetement <> 'Refusé' AND accord_client = TRUE;
    RETURN v_pieces + v_maj
         + CASE WHEN v_nb = 0 THEN 0
                WHEN v_poids >= v_seuil THEN ROUND(v_poids * v_tarif_kg, 0)   -- RG28 : lot au poids
                ELSE v_nb * v_prix_hc END;                                    -- RG29 : à la pièce hors catégorie
END //

-- RG44 : montant des suppléments = Σ prix × quantité
CREATE FUNCTION fn_montant_supplements(p_commande INT UNSIGNED)
RETURNS DECIMAL(12,2)
READS SQL DATA
BEGIN
    DECLARE v_total DECIMAL(12,2) DEFAULT 0;
    SELECT COALESCE(SUM(prix_supp_applique * quantite_supp), 0) INTO v_total
      FROM supplement_applique WHERE id_commande = p_commande;
    RETURN v_total;
END //

-- RG40, RG46, RG48 : total = vêtements + majoration express (hors suppléments) + suppléments − réduction de fidélité
CREATE FUNCTION fn_montant_total(p_commande INT UNSIGNED)
RETURNS DECIMAL(12,2)
READS SQL DATA
BEGIN
    DECLARE v_vet, v_sous_total DECIMAL(12,2);
    DECLARE v_taux_maj, v_taux_remise DECIMAL(5,2);
    SELECT taux_majoration_applique, taux_remise INTO v_taux_maj, v_taux_remise
      FROM commande WHERE id_commande = p_commande;
    SET v_vet = fn_montant_vetements(p_commande);
    SET v_sous_total = v_vet + ROUND(v_vet * v_taux_maj / 100, 0) + fn_montant_supplements(p_commande);
    RETURN v_sous_total - ROUND(v_sous_total * v_taux_remise / 100, 0);
END //

-- Total payé, par objet (« Commande » ou « Frais de retard »)
CREATE FUNCTION fn_total_paye(p_commande INT UNSIGNED, p_objet VARCHAR(15))
RETURNS DECIMAL(12,2)
READS SQL DATA
BEGIN
    DECLARE v_total DECIMAL(12,2) DEFAULT 0;
    SELECT COALESCE(SUM(montant_paiement), 0) INTO v_total
      FROM paiement WHERE id_commande = p_commande AND objet_paiement = p_objet;
    RETURN v_total;
END //

-- RG37 : date de retrait prévue = date du paiement intégral + durée appliquée (NULL tant que non payée)
CREATE FUNCTION fn_date_retrait_prevue(p_commande INT UNSIGNED)
RETURNS DATETIME
READS SQL DATA
BEGIN
    DECLARE v_date DATETIME;
    SELECT date_paiement_integral + INTERVAL duree_appliquee_h HOUR INTO v_date
      FROM commande WHERE id_commande = p_commande;
    RETURN v_date;
END //

-- RG74 à RG78 : frais de retard = Σ (jours de retard de chaque vêtement) × frais journaliers.
-- Un vêtement déjà remis compte jusqu'à la date de son retrait ; un vêtement restant compte jusqu'à aujourd'hui.
-- p_seulement_remis = TRUE : seuls les vêtements déjà remis sont comptés.
CREATE FUNCTION fn_frais_retard(p_commande INT UNSIGNED, p_seulement_remis BOOLEAN)
RETURNS DECIMAL(12,2)
READS SQL DATA
BEGIN
    DECLARE v_mode VARCHAR(10);
    DECLARE v_frais DECIMAL(10,2);
    DECLARE v_limite DATE;
    DECLARE v_jours INT DEFAULT 0;
    SELECT mode_recuperation, frais_retard_applique,
           DATE(date_paiement_integral + INTERVAL duree_appliquee_h HOUR) + INTERVAL delai_grace_applique DAY
      INTO v_mode, v_frais, v_limite FROM commande WHERE id_commande = p_commande;
    IF v_mode <> 'Retrait' OR v_limite IS NULL THEN
        RETURN 0;                                           -- RG78 : pas de frais pour une livraison
    END IF;
    SELECT COALESCE(SUM(GREATEST(0, DATEDIFF(COALESCE(r.date_retrait, NOW()), v_limite))), 0) INTO v_jours
      FROM vetement v LEFT JOIN retrait r ON r.id_retrait = v.id_retrait
     WHERE v.id_commande = p_commande AND v.statut_vetement NOT IN ('Refusé', 'Livré')
       AND (p_seulement_remis = FALSE OR v.id_retrait IS NOT NULL);
    RETURN v_jours * v_frais;
END //

-- RG19 à RG21 : commandes éligibles depuis la dernière réduction de fidélité utilisée
CREATE FUNCTION fn_nb_commandes_eligibles(p_client INT UNSIGNED)
RETURNS INT
READS SQL DATA
BEGIN
    DECLARE v_agence INT UNSIGNED;
    DECLARE v_depuis DATETIME;
    DECLARE v_nb INT DEFAULT 0;
    SELECT id_agence INTO v_agence FROM client WHERE id_client = p_client;
    SELECT MAX(date_commande) INTO v_depuis FROM commande
     WHERE id_client = p_client AND id_agence = v_agence AND taux_remise > 0 AND statut_commande <> 'Annulée';
    SELECT COUNT(*) INTO v_nb FROM commande
     WHERE id_client = p_client AND id_agence = v_agence
       AND statut_commande IN ('Retirée', 'Livrée') AND date_paiement_integral IS NOT NULL
       AND date_commande > COALESCE(v_depuis, '1000-01-01');
    RETURN v_nb;
END //

DELIMITER ;


-- =============================================================================
-- 5. DÉCLENCHEURS
--    En cas de violation, SIGNAL renvoie l'erreur 45000 avec un message
--    citant la règle de gestion, que l'application affiche telle quelle.
-- =============================================================================
DELIMITER //

-- ---------------------------------------------------------------- EMPLOYE : RG09, RG14
CREATE TRIGGER trg_employe_bi BEFORE INSERT ON employe FOR EACH ROW
BEGIN
    DECLARE v_role VARCHAR(20);
    SET v_role = (SELECT libelle_role FROM role WHERE id_role = NEW.id_role);
    IF v_role = 'Administrateur' AND NEW.id_agence IS NOT NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG09 : l''administrateur n''est rattaché à aucune agence.';
    END IF;
    IF v_role <> 'Administrateur' AND NEW.id_agence IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG09 : un gérant ou un livreur est rattaché à une agence.';
    END IF;
    IF v_role = 'Livreur' THEN
        SET NEW.disponibilite_livreur = COALESCE(NEW.disponibilite_livreur, 'Libre');
    ELSE
        SET NEW.disponibilite_livreur = NULL;               -- RG14 : livreurs uniquement
    END IF;
END //

CREATE TRIGGER trg_employe_bu BEFORE UPDATE ON employe FOR EACH ROW
BEGIN
    DECLARE v_role VARCHAR(20);
    SET v_role = (SELECT libelle_role FROM role WHERE id_role = NEW.id_role);
    IF (v_role = 'Administrateur') <> (NEW.id_agence IS NULL) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG09 : seul l''administrateur n''a pas d''agence.';
    END IF;
    IF v_role <> 'Livreur' THEN
        SET NEW.disponibilite_livreur = NULL;
    ELSEIF NEW.disponibilite_livreur IS NULL THEN
        SET NEW.disponibilite_livreur = 'Libre';
    END IF;
END //

-- ---------------------------------------------------------------- CLIENT : RG06
CREATE TRIGGER trg_client_bi BEFORE INSERT ON client FOR EACH ROW
BEGIN
    IF (SELECT statut_agence FROM agence WHERE id_agence = NEW.id_agence) <> 'Active' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG06 : une agence inactive ne peut plus enregistrer de client.';
    END IF;
END //

-- ---------------------------------------------------------------- COMMANDE : enregistrement
-- RG06, RG11, RG32 : agence active, gérant actif de cette agence.
-- RG38 : copie de la configuration de l'agence. RG20 : réduction de fidélité.
CREATE TRIGGER trg_commande_bi BEFORE INSERT ON commande FOR EACH ROW
BEGIN
    DECLARE v_statut_agence VARCHAR(10);
    DECLARE v_d_norm, v_d_exp, v_grace, v_seuil_fid SMALLINT UNSIGNED;
    DECLARE v_maj, v_taux_fid DECIMAL(5,2);
    DECLARE v_seuil DECIMAL(6,2);
    DECLARE v_kg, v_hc, v_frais DECIMAL(10,2);
    DECLARE v_agence_client INT UNSIGNED;
    DECLARE v_prefixe VARCHAR(20);

    SELECT statut_agence, duree_normal_h, duree_express_h, taux_majoration_express, seuil_poids_kg, tarif_kg,
           prix_piece_hors_categorie, delai_grace_jours, frais_retard_jour, seuil_fidelite, taux_fidelite
      INTO v_statut_agence, v_d_norm, v_d_exp, v_maj, v_seuil, v_kg, v_hc, v_grace, v_frais, v_seuil_fid, v_taux_fid
      FROM agence WHERE id_agence = NEW.id_agence;
    IF v_statut_agence <> 'Active' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG06 : une agence inactive ne peut plus enregistrer de commande.';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM employe e JOIN role r ON r.id_role = e.id_role
                    WHERE e.id_employe = NEW.id_employe AND r.libelle_role = 'Gérant'
                      AND e.id_agence = NEW.id_agence AND e.statut_compte = 'Actif') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG32 : la commande est enregistrée par un gérant actif de l''agence.';
    END IF;
    IF NEW.mode_recuperation = 'Livraison'
       AND (SELECT adresse_client FROM client WHERE id_client = NEW.id_client) IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Livraison impossible : l''adresse du client n''est pas renseignée.';
    END IF;

    SET NEW.statut_commande = 'Enregistrée';
    SET NEW.duree_appliquee_h        = IF(NEW.type_service = 'Express', v_d_exp, v_d_norm);
    SET NEW.taux_majoration_applique = IF(NEW.type_service = 'Express', v_maj, 0);
    SET NEW.tarif_kg_applique = v_kg, NEW.seuil_poids_applique = v_seuil, NEW.prix_hors_cat_applique = v_hc,
        NEW.delai_grace_applique = v_grace, NEW.frais_retard_applique = v_frais;
    SET NEW.date_paiement_integral = NULL, NEW.date_retrait_effective = NULL;

    -- RG19 à RG21 : réduction si le seuil est atteint dans l'agence de fidélité du client
    SET v_agence_client = (SELECT id_agence FROM client WHERE id_client = NEW.id_client);
    IF v_agence_client = NEW.id_agence AND fn_nb_commandes_eligibles(NEW.id_client) >= v_seuil_fid THEN
        SET NEW.taux_remise = v_taux_fid;
    ELSE
        SET NEW.taux_remise = 0;
    END IF;

    -- Numéro lisible : A<agence>-<AAMMJJ>-<rang du jour> (plus grand rang du jour + 1 : jamais de doublon)
    IF NEW.numero_commande IS NULL OR NEW.numero_commande = '' THEN
        SET v_prefixe = CONCAT('A', LPAD(NEW.id_agence, 2, '0'), '-', DATE_FORMAT(NOW(), '%y%m%d'), '-');
        SET NEW.numero_commande = CONCAT(v_prefixe, LPAD(
            (SELECT COALESCE(MAX(CAST(SUBSTRING_INDEX(numero_commande, '-', -1) AS UNSIGNED)), 0) + 1
               FROM commande WHERE numero_commande LIKE CONCAT(v_prefixe, '%')), 3, '0'));
    END IF;
END //

-- RG45 : supplément de livraison ajouté automatiquement ; notification de dépôt (RG85)
CREATE TRIGGER trg_commande_ai AFTER INSERT ON commande FOR EACH ROW
BEGIN
    DECLARE v_supp INT UNSIGNED;
    IF NEW.mode_recuperation = 'Livraison' THEN
        SET v_supp = (SELECT id_supplement FROM supplement WHERE libelle_supplement = 'Livraison à domicile');
        INSERT INTO supplement_applique (prix_supp_applique, id_commande, id_supplement) VALUES (0, NEW.id_commande, v_supp);
    END IF;
    INSERT INTO notification (type_notification, contenu, id_client, id_commande)
    VALUES ('Dépôt', CONCAT('Votre dépôt n° ', NEW.numero_commande, ' est enregistré.'), NEW.id_client, NEW.id_commande);
END //

-- ---------------------------------------------------------------- COMMANDE : changements de statut (RG34)
CREATE TRIGGER trg_commande_bu BEFORE UPDATE ON commande FOR EACH ROW
BEGIN
    DECLARE v_livreur INT UNSIGNED;
    DECLARE v_adresse VARCHAR(255);
    DECLARE v_duree SMALLINT UNSIGNED;
    DECLARE v_taux DECIMAL(5,2);

    -- Les choix et valeurs copiées sont figés dès que la commande n'est plus « Enregistrée »
    IF OLD.statut_commande <> 'Enregistrée'
       AND (NEW.type_service <> OLD.type_service OR NEW.mode_recuperation <> OLD.mode_recuperation
            OR NEW.taux_remise <> OLD.taux_remise OR NEW.id_client <> OLD.id_client OR NEW.id_agence <> OLD.id_agence
            OR NEW.duree_appliquee_h <> OLD.duree_appliquee_h OR NEW.tarif_kg_applique <> OLD.tarif_kg_applique
            OR NEW.taux_majoration_applique <> OLD.taux_majoration_applique) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG38 : une commande payée ne peut plus être modifiée.';
    END IF;
    IF OLD.statut_commande = 'Enregistrée' AND NEW.type_service <> OLD.type_service THEN
        SELECT IF(NEW.type_service = 'Express', duree_express_h, duree_normal_h),
               IF(NEW.type_service = 'Express', taux_majoration_express, 0)
          INTO v_duree, v_taux FROM agence WHERE id_agence = NEW.id_agence;
        SET NEW.duree_appliquee_h = v_duree, NEW.taux_majoration_applique = v_taux;
    END IF;

    IF NEW.statut_commande <> OLD.statut_commande THEN
        IF (OLD.statut_commande, NEW.statut_commande) NOT IN (
               ('Enregistrée', 'Payée'), ('Enregistrée', 'Annulée'), ('Payée', 'Annulée'), ('Payée', 'En traitement'),
               ('En traitement', 'Terminée'), ('Terminée', 'Partiellement retirée'), ('Terminée', 'Retirée'),
               ('Partiellement retirée', 'Retirée'), ('Terminée', 'En livraison'),
               ('Terminée', 'En attente de livreur'), ('En attente de livreur', 'En livraison'),
               ('En livraison', 'Livrée'), ('En livraison', 'En attente de livreur')) THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG34 : ce changement de statut de commande n''est pas autorisé.';
        END IF;

        -- RG50 : passage à « Payée » seulement quand la totalité est réglée
        IF NEW.statut_commande = 'Payée' THEN
            IF fn_total_paye(NEW.id_commande, 'Commande') < fn_montant_total(NEW.id_commande) THEN
                SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG50 : la commande n''est pas entièrement payée.';
            END IF;
            SET NEW.date_paiement_integral = COALESCE(NEW.date_paiement_integral, NOW());
        END IF;

        -- Début du traitement : les vêtements acceptés passent « En traitement »
        IF NEW.statut_commande = 'En traitement' THEN
            UPDATE vetement SET statut_vetement = 'En traitement'
             WHERE id_commande = NEW.id_commande AND statut_vetement = 'Accepté';
        END IF;

        -- Commande terminée : tous les vêtements acceptés doivent être prêts
        IF NEW.statut_commande = 'Terminée' THEN
            IF EXISTS (SELECT 1 FROM vetement WHERE id_commande = NEW.id_commande
                                               AND statut_vetement IN ('Accepté', 'En traitement')) THEN
                SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Tous les vêtements acceptés doivent être prêts.';
            END IF;
            IF NEW.mode_recuperation = 'Livraison' THEN
                -- RG62, RG63 : création de la livraison et recherche d'un livreur libre de l'agence
                SET v_adresse = (SELECT adresse_client FROM client WHERE id_client = NEW.id_client);
                SET v_livreur = (SELECT e.id_employe FROM employe e JOIN role r ON r.id_role = e.id_role
                                  WHERE r.libelle_role = 'Livreur' AND e.id_agence = NEW.id_agence
                                    AND e.statut_compte = 'Actif' AND e.disponibilite_livreur = 'Libre'
                                  ORDER BY e.id_employe LIMIT 1);
                IF v_livreur IS NULL THEN
                    INSERT INTO livraison (adresse_livraison, id_commande) VALUES (v_adresse, NEW.id_commande);
                    SET NEW.statut_commande = 'En attente de livreur';
                ELSE
                    INSERT INTO livraison (adresse_livraison, statut_livraison, date_assignation, id_commande, id_employe)
                    VALUES (v_adresse, 'Assignée', NOW(), NEW.id_commande, v_livreur);
                    UPDATE employe SET disponibilite_livreur = 'Occupé' WHERE id_employe = v_livreur;
                    INSERT INTO notification (type_notification, contenu, id_client, id_commande)
                    VALUES ('Affectation livreur', CONCAT('Un livreur a été affecté à votre commande n° ',
                            NEW.numero_commande, '.'), NEW.id_client, NEW.id_commande);
                END IF;
            ELSE
                INSERT INTO notification (type_notification, contenu, id_client, id_commande)
                VALUES ('Disponibilité', CONCAT('Vos vêtements (commande n° ', NEW.numero_commande,
                        ') sont prêts à être retirés.'), NEW.id_client, NEW.id_commande);
            END IF;
        END IF;

        -- RG90 : annulation journalisée
        IF NEW.statut_commande = 'Annulée' THEN
            INSERT INTO journal_action (type_action, entite_concernee, id_entite, detail_action, id_employe)
            VALUES ('Annulation', 'commande', NEW.id_commande, CONCAT('Annulation de la commande ', NEW.numero_commande),
                    COALESCE(@id_employe_session, NEW.id_employe));
        END IF;
    END IF;
END //

-- ---------------------------------------------------------------- VETEMENT : dépôt (RG26, RG27, RG30, RG38)
CREATE TRIGGER trg_vetement_bi BEFORE INSERT ON vetement FOR EACH ROW
BEGIN
    DECLARE v_statut VARCHAR(25);
    DECLARE v_agence INT UNSIGNED;
    DECLARE v_numero VARCHAR(30);
    DECLARE v_prix DECIMAL(10,2);
    DECLARE v_unite VARCHAR(6);
    SELECT statut_commande, id_agence, numero_commande INTO v_statut, v_agence, v_numero
      FROM commande WHERE id_commande = NEW.id_commande;
    IF v_statut <> 'Enregistrée' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Un vêtement ne peut être ajouté qu''à une commande « Enregistrée ».';
    END IF;
    SELECT t.prix_categorie, t.unite_facturation INTO v_prix, v_unite
      FROM article a JOIN tarif_categorie t ON t.id_categorie = a.id_categorie AND t.id_agence = v_agence
     WHERE a.id_article = NEW.id_article AND t.actif_tarif = TRUE;
    IF v_unite IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'La catégorie de cet article n''est pas proposée dans l''agence.';
    END IF;
    IF NEW.statut_vetement = 'Refusé' THEN                -- RG30 : non facturé, hors lot
        SET NEW.prix_applique = NULL, NEW.majoration_speciale = 0;
    ELSE
        SET NEW.statut_vetement = 'Accepté';
        SET NEW.prix_applique = IF(v_unite = 'Pièce', v_prix, NULL);   -- RG27 : tri automatique
    END IF;
    SET NEW.id_retrait = NULL;
    IF NEW.code_etiquette IS NULL OR NEW.code_etiquette = '' THEN
        SET NEW.code_etiquette = CONCAT(v_numero, '-',
            LPAD((SELECT COUNT(*) + 1 FROM vetement WHERE id_commande = NEW.id_commande), 2, '0'));
    END IF;
END //

-- ---------------------------------------------------------------- VETEMENT : modification et retrait (RG72, RG77)
CREATE TRIGGER trg_vetement_bu BEFORE UPDATE ON vetement FOR EACH ROW
BEGIN
    DECLARE v_statut VARCHAR(25);
    DECLARE v_frais_dus, v_frais_payes DECIMAL(12,2);
    DECLARE v_limite DATE;
    DECLARE v_frais_jour DECIMAL(10,2);
    SELECT statut_commande INTO v_statut FROM commande WHERE id_commande = OLD.id_commande;

    -- Données du dépôt figées après le paiement (RG38)
    IF v_statut <> 'Enregistrée'
       AND (NEW.poids_kg <> OLD.poids_kg OR NOT (NEW.prix_applique <=> OLD.prix_applique)
            OR NEW.majoration_speciale <> OLD.majoration_speciale OR NEW.id_article <> OLD.id_article
            OR NEW.id_commande <> OLD.id_commande OR (NEW.statut_vetement = 'Refusé' AND OLD.statut_vetement <> 'Refusé')) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG38 : un vêtement ne se modifie plus après le paiement.';
    END IF;
    IF NEW.statut_vetement = 'Refusé' AND OLD.statut_vetement <> 'Refusé' THEN
        SET NEW.prix_applique = NULL, NEW.majoration_speciale = 0;
    END IF;

    -- Remise du vêtement lors d'un retrait
    IF NEW.id_retrait IS NOT NULL AND OLD.id_retrait IS NULL THEN
        IF OLD.statut_vetement <> 'Prêt' THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG72 : seul un vêtement prêt et non encore remis peut être retiré.';
        END IF;
        IF (SELECT id_commande FROM retrait WHERE id_retrait = NEW.id_retrait) <> OLD.id_commande THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Ce retrait concerne une autre commande.';
        END IF;
        -- RG77 : les frais de retard des vêtements remis doivent être réglés avant la remise
        SELECT DATE(date_paiement_integral + INTERVAL duree_appliquee_h HOUR) + INTERVAL delai_grace_applique DAY,
               frais_retard_applique INTO v_limite, v_frais_jour FROM commande WHERE id_commande = OLD.id_commande;
        SET v_frais_dus = fn_frais_retard(OLD.id_commande, TRUE) + GREATEST(0, DATEDIFF(NOW(), v_limite)) * v_frais_jour;
        SET v_frais_payes = fn_total_paye(OLD.id_commande, 'Frais de retard');
        IF v_frais_payes < v_frais_dus THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG77 : les frais de retard doivent être réglés avant la remise.';
        END IF;
        SET NEW.statut_vetement = 'Retiré';
    ELSEIF NEW.id_retrait IS NULL AND OLD.id_retrait IS NOT NULL OR NEW.id_retrait <> OLD.id_retrait THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG72 : un vêtement ne peut être retiré qu''une seule fois.';
    END IF;
END //

-- Après la remise d'un vêtement : commande « Partiellement retirée » ou « Retirée » (RG60, RG79)
CREATE TRIGGER trg_vetement_au AFTER UPDATE ON vetement FOR EACH ROW
BEGIN
    DECLARE v_numero VARCHAR(30);
    DECLARE v_frais DECIMAL(12,2);
    IF NEW.id_retrait IS NOT NULL AND OLD.id_retrait IS NULL THEN
        IF NOT EXISTS (SELECT 1 FROM vetement WHERE id_commande = NEW.id_commande
                                               AND statut_vetement NOT IN ('Refusé', 'Retiré')) THEN
            UPDATE commande SET statut_commande = 'Retirée', date_retrait_effective = NOW()
             WHERE id_commande = NEW.id_commande;
            UPDATE code_validation SET statut_code = 'Utilisé', date_utilisation = NOW()
             WHERE id_commande = NEW.id_commande AND statut_code = 'Actif';
            -- RG55 : facture complémentaire si des frais de retard ont été réglés
            SET v_frais = fn_total_paye(NEW.id_commande, 'Frais de retard');
            IF v_frais > 0 THEN
                SET v_numero = (SELECT numero_commande FROM commande WHERE id_commande = NEW.id_commande);
                INSERT INTO facture (numero_facture, type_facture, montant_facture, id_commande)
                VALUES (CONCAT('FR-', v_numero), 'Frais de retard', v_frais, NEW.id_commande);
            END IF;
        ELSE
            UPDATE commande SET statut_commande = 'Partiellement retirée'
             WHERE id_commande = NEW.id_commande AND statut_commande = 'Terminée';
        END IF;
    END IF;
END //

-- ---------------------------------------------------------------- SUPPLEMENT_APPLIQUE : RG42 à RG44
CREATE TRIGGER trg_supp_applique_bi BEFORE INSERT ON supplement_applique FOR EACH ROW
BEGIN
    DECLARE v_statut VARCHAR(25);
    DECLARE v_agence INT UNSIGNED;
    DECLARE v_portee VARCHAR(10);
    DECLARE v_prix DECIMAL(10,2);
    SELECT statut_commande, id_agence INTO v_statut, v_agence FROM commande WHERE id_commande = NEW.id_commande;
    IF v_statut <> 'Enregistrée' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Un supplément ne s''ajoute qu''à une commande « Enregistrée ».';
    END IF;
    SET v_portee = (SELECT portee_supplement FROM supplement WHERE id_supplement = NEW.id_supplement);
    SET v_prix = (SELECT prix_supplement FROM tarif_supplement
                   WHERE id_agence = v_agence AND id_supplement = NEW.id_supplement AND actif_supplement = TRUE);
    IF v_prix IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG42 : ce supplément n''est pas proposé dans l''agence.';
    END IF;
    SET NEW.prix_supp_applique = v_prix;                  -- RG38 : prix copié
    IF v_portee = 'Commande' THEN
        IF NEW.id_vetement IS NOT NULL THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG44 : un supplément de portée « Commande » ne vise pas un vêtement.';
        END IF;
        IF EXISTS (SELECT 1 FROM supplement_applique
                    WHERE id_commande = NEW.id_commande AND id_supplement = NEW.id_supplement) THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG44 : un supplément de portée « Commande » s''applique une seule fois.';
        END IF;
        SET NEW.quantite_supp = 1;
    ELSE
        IF NEW.id_vetement IS NULL
           OR (SELECT id_commande FROM vetement WHERE id_vetement = NEW.id_vetement) <> NEW.id_commande THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG44 : un supplément de portée « Vêtement » vise un vêtement de la commande.';
        END IF;
    END IF;
END //

-- ---------------------------------------------------------------- PAIEMENT : RG50 à RG53
CREATE TRIGGER trg_paiement_bi BEFORE INSERT ON paiement FOR EACH ROW
BEGIN
    DECLARE v_statut VARCHAR(25);
    DECLARE v_agence INT UNSIGNED;
    DECLARE v_mode VARCHAR(10);
    SELECT statut_commande, id_agence, mode_recuperation INTO v_statut, v_agence, v_mode
      FROM commande WHERE id_commande = NEW.id_commande;
    IF v_statut = 'Annulée' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Paiement impossible : la commande est annulée.';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM employe e JOIN role r ON r.id_role = e.id_role
                    WHERE e.id_employe = NEW.id_employe AND r.libelle_role = 'Gérant'
                      AND e.id_agence = v_agence AND e.statut_compte = 'Actif') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG53 : un paiement est enregistré par un gérant de l''agence (le livreur n''encaisse pas).';
    END IF;
    IF NEW.objet_paiement = 'Commande' THEN
        IF v_statut <> 'Enregistrée' THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG50 : la commande est déjà entièrement payée.';
        END IF;
        IF fn_total_paye(NEW.id_commande, 'Commande') + NEW.montant_paiement > fn_montant_total(NEW.id_commande) THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG51 : la somme des paiements dépasserait le montant dû.';
        END IF;
    ELSE
        IF v_mode <> 'Retrait' THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG78 : pas de frais de retard pour une commande livrée.';
        END IF;
        IF fn_total_paye(NEW.id_commande, 'Frais de retard') + NEW.montant_paiement > fn_frais_retard(NEW.id_commande, FALSE) THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG51 : le montant dépasse les frais de retard dus.';
        END IF;
    END IF;
END //

-- Paiement intégral : statut « Payée », facture principale, code de validation, notifications (RG54, RG57, RG90)
CREATE TRIGGER trg_paiement_ai AFTER INSERT ON paiement FOR EACH ROW
BEGIN
    DECLARE v_total DECIMAL(12,2);
    DECLARE v_numero VARCHAR(30);
    DECLARE v_client INT UNSIGNED;
    DECLARE v_code CHAR(6);
    INSERT INTO journal_action (type_action, entite_concernee, id_entite, detail_action, id_employe)
    VALUES ('Création', 'paiement', NEW.id_paiement,
            CONCAT(NEW.objet_paiement, ' : ', NEW.montant_paiement, ' FCFA (', NEW.mode_paiement, ')'), NEW.id_employe);
    IF NEW.objet_paiement = 'Commande' THEN
        SET v_total = fn_montant_total(NEW.id_commande);
        IF fn_total_paye(NEW.id_commande, 'Commande') >= v_total THEN
            SELECT numero_commande, id_client INTO v_numero, v_client FROM commande WHERE id_commande = NEW.id_commande;
            UPDATE commande SET statut_commande = 'Payée', date_paiement_integral = NOW() WHERE id_commande = NEW.id_commande;
            INSERT INTO facture (numero_facture, type_facture, montant_facture, id_commande)
            VALUES (CONCAT('FP-', v_numero), 'Principale', v_total, NEW.id_commande);
            SET v_code = LPAD(FLOOR(RAND() * 1000000), 6, '0');
            INSERT INTO code_validation (valeur_qr, code_numerique, id_commande)
            VALUES (SHA2(CONCAT(UUID(), RAND()), 256), v_code, NEW.id_commande);
            INSERT INTO notification (type_notification, contenu, id_client, id_commande)
            VALUES ('Code de validation', CONCAT('Paiement reçu pour la commande n° ', v_numero,
                    '. Votre code de validation : ', v_code, ' (QR code joint).'), v_client, NEW.id_commande);
        END IF;
    END IF;
END //

-- RG56 et intégrité : paiements et factures ne se modifient ni ne se suppriment
CREATE TRIGGER trg_paiement_bu BEFORE UPDATE ON paiement FOR EACH ROW
BEGIN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Un paiement enregistré ne se modifie pas.';
END //
CREATE TRIGGER trg_paiement_bd BEFORE DELETE ON paiement FOR EACH ROW
BEGIN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Un paiement enregistré ne se supprime pas.';
END //
CREATE TRIGGER trg_facture_bu BEFORE UPDATE ON facture FOR EACH ROW
BEGIN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG56 : une facture émise ne peut pas être modifiée.';
END //
CREATE TRIGGER trg_facture_bd BEFORE DELETE ON facture FOR EACH ROW
BEGIN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG56 : une facture émise ne peut pas être supprimée.';
END //

-- ---------------------------------------------------------------- RETRAIT : RG71, RG73
CREATE TRIGGER trg_retrait_bi BEFORE INSERT ON retrait FOR EACH ROW
BEGIN
    DECLARE v_statut VARCHAR(25);
    DECLARE v_agence INT UNSIGNED;
    DECLARE v_mode VARCHAR(10);
    SELECT statut_commande, id_agence, mode_recuperation INTO v_statut, v_agence, v_mode
      FROM commande WHERE id_commande = NEW.id_commande;
    IF v_mode <> 'Retrait' OR v_statut NOT IN ('Terminée', 'Partiellement retirée') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Retrait impossible : la commande n''est pas prête au retrait en agence.';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM employe e JOIN role r ON r.id_role = e.id_role
                    WHERE e.id_employe = NEW.id_employe AND r.libelle_role = 'Gérant' AND e.id_agence = v_agence) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG71 : le retrait est enregistré par un gérant de l''agence.';
    END IF;
END //

-- ---------------------------------------------------------------- LIVRAISON : RG63 à RG70
CREATE TRIGGER trg_livraison_bu BEFORE UPDATE ON livraison FOR EACH ROW
BEGIN
    DECLARE v_agence INT UNSIGNED;
    IF NEW.statut_livraison <> OLD.statut_livraison THEN
        IF (OLD.statut_livraison, NEW.statut_livraison) NOT IN (
               ('En attente de livreur', 'Assignée'), ('Assignée', 'En cours'), ('En cours', 'Livrée'),
               ('Assignée', 'Échouée'), ('En cours', 'Échouée'), ('Échouée', 'En attente de livreur')) THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Ce changement de statut de livraison n''est pas autorisé.';
        END IF;
        IF NEW.statut_livraison = 'Assignée' THEN          -- RG63, RG65
            SET v_agence = (SELECT id_agence FROM commande WHERE id_commande = NEW.id_commande);
            IF NOT EXISTS (SELECT 1 FROM employe e JOIN role r ON r.id_role = e.id_role
                            WHERE e.id_employe = NEW.id_employe AND r.libelle_role = 'Livreur'
                              AND e.id_agence = v_agence AND e.statut_compte = 'Actif'
                              AND e.disponibilite_livreur = 'Libre') THEN
                SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG65 : la livraison va à un livreur libre de l''agence de la commande.';
            END IF;
            SET NEW.date_assignation = NOW();
        END IF;
        IF NEW.statut_livraison = 'En cours' THEN          -- RG66
            SET NEW.date_recuperation_agence = NOW();
        END IF;
        IF NEW.statut_livraison = 'Livrée' THEN            -- RG67, RG68
            IF NOT EXISTS (SELECT 1 FROM preuve_livraison WHERE id_livraison = NEW.id_livraison) THEN
                SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG68 : une livraison ne se clôture pas sans photo justificative.';
            END IF;
            SET NEW.date_livraison = COALESCE(NEW.date_livraison, NOW());
        END IF;
        IF NEW.statut_livraison = 'Échouée' THEN           -- RG69
            SET NEW.nb_tentatives = OLD.nb_tentatives + 1;
        END IF;
        IF NEW.statut_livraison = 'En attente de livreur' THEN   -- reprogrammation
            SET NEW.id_employe = NULL, NEW.date_assignation = NULL, NEW.date_recuperation_agence = NULL;
        END IF;
    END IF;
END //

CREATE TRIGGER trg_livraison_au AFTER UPDATE ON livraison FOR EACH ROW
BEGIN
    DECLARE v_client INT UNSIGNED;
    DECLARE v_numero VARCHAR(30);
    IF NEW.statut_livraison <> OLD.statut_livraison THEN
        SELECT id_client, numero_commande INTO v_client, v_numero FROM commande WHERE id_commande = NEW.id_commande;
        IF NEW.statut_livraison = 'Assignée' THEN
            UPDATE employe SET disponibilite_livreur = 'Occupé' WHERE id_employe = NEW.id_employe;
            INSERT INTO notification (type_notification, contenu, id_client, id_commande)
            VALUES ('Affectation livreur', CONCAT('Un livreur a été affecté à votre commande n° ', v_numero, '.'),
                    v_client, NEW.id_commande);
        ELSEIF NEW.statut_livraison = 'En cours' THEN
            UPDATE commande SET statut_commande = 'En livraison' WHERE id_commande = NEW.id_commande;
        ELSEIF NEW.statut_livraison = 'Livrée' THEN
            UPDATE commande SET statut_commande = 'Livrée', date_retrait_effective = NEW.date_livraison
             WHERE id_commande = NEW.id_commande;
            UPDATE vetement SET statut_vetement = 'Livré' WHERE id_commande = NEW.id_commande AND statut_vetement = 'Prêt';
            UPDATE code_validation SET statut_code = 'Utilisé', date_utilisation = NEW.date_livraison
             WHERE id_commande = NEW.id_commande AND statut_code = 'Actif';
            UPDATE employe SET disponibilite_livreur = 'Libre' WHERE id_employe = NEW.id_employe;     -- RG70
            INSERT INTO notification (type_notification, contenu, id_client, id_commande)
            VALUES ('Livraison', CONCAT('Votre commande n° ', v_numero, ' a été livrée.'), v_client, NEW.id_commande);
        ELSEIF NEW.statut_livraison = 'Échouée' THEN
            UPDATE employe SET disponibilite_livreur = 'Libre' WHERE id_employe = NEW.id_employe;     -- RG70
            UPDATE commande SET statut_commande = 'En attente de livreur'
             WHERE id_commande = NEW.id_commande AND statut_commande IN ('Terminée', 'En livraison');
        END IF;
    END IF;
END //

-- ---------------------------------------------------------------- INCIDENT, IMPLIQUER, NOTIFICATION
CREATE TRIGGER trg_incident_bu BEFORE UPDATE ON incident FOR EACH ROW
BEGIN
    IF NEW.statut_incident = 'Clôturé' AND OLD.statut_incident <> 'Clôturé' THEN
        SET NEW.date_cloture = COALESCE(NEW.date_cloture, NOW());
        INSERT INTO journal_action (type_action, entite_concernee, id_entite, detail_action, id_employe)
        VALUES ('Modification', 'incident', NEW.id_incident, CONCAT('Clôture : ', NEW.solution_apportee),
                COALESCE(@id_employe_session, NEW.id_employe));               -- RG90
    END IF;
END //

CREATE TRIGGER trg_impliquer_bi BEFORE INSERT ON impliquer FOR EACH ROW
BEGIN
    IF (SELECT id_commande FROM incident WHERE id_incident = NEW.id_incident)
       <> (SELECT id_commande FROM vetement WHERE id_vetement = NEW.id_vetement) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG81 : le vêtement doit appartenir à la commande de l''incident.';
    END IF;
END //

CREATE TRIGGER trg_notification_bi BEFORE INSERT ON notification FOR EACH ROW
BEGIN
    IF NEW.id_commande IS NOT NULL
       AND (SELECT id_client FROM commande WHERE id_commande = NEW.id_commande) <> NEW.id_client THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG84 : la notification porte sur une commande du client.';
    END IF;
END //

-- ---------------------------------------------------------------- JOURNAL : RG91
CREATE TRIGGER trg_journal_bu BEFORE UPDATE ON journal_action FOR EACH ROW
BEGIN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG91 : le journal ne peut pas être modifié.';
END //
CREATE TRIGGER trg_journal_bd BEFORE DELETE ON journal_action FOR EACH ROW
BEGIN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG91 : le journal ne peut pas être supprimé.';
END //

-- ---------------------------------------------------------------- RG90 : modifications de configuration journalisées
CREATE TRIGGER trg_agence_au AFTER UPDATE ON agence FOR EACH ROW
BEGIN
    IF @id_employe_session IS NOT NULL THEN
        INSERT INTO journal_action (type_action, entite_concernee, id_entite, detail_action, id_employe)
        VALUES ('Modification', 'agence', NEW.id_agence, CONCAT('Configuration de l''agence ', NEW.nom_agence,
                ' modifiée (statut ', NEW.statut_agence, ')'), @id_employe_session);
    END IF;
END //

CREATE TRIGGER trg_tarif_categorie_au AFTER UPDATE ON tarif_categorie FOR EACH ROW
BEGIN
    IF @id_employe_session IS NOT NULL THEN
        INSERT INTO journal_action (type_action, entite_concernee, id_entite, detail_action, id_employe)
        VALUES ('Modification', 'tarif_categorie', NEW.id_categorie,
                CONCAT('Agence ', NEW.id_agence, ' : ', OLD.prix_categorie, ' -> ', NEW.prix_categorie, ' FCFA (',
                       NEW.unite_facturation, ')'), @id_employe_session);
    END IF;
END //

CREATE TRIGGER trg_tarif_supplement_au AFTER UPDATE ON tarif_supplement FOR EACH ROW
BEGIN
    IF @id_employe_session IS NOT NULL THEN
        INSERT INTO journal_action (type_action, entite_concernee, id_entite, detail_action, id_employe)
        VALUES ('Modification', 'tarif_supplement', NEW.id_supplement,
                CONCAT('Agence ', NEW.id_agence, ' : ', OLD.prix_supplement, ' -> ', NEW.prix_supplement, ' FCFA'),
                @id_employe_session);
    END IF;
END //

DELIMITER ;


-- =============================================================================
-- 6. PROCÉDURES
-- =============================================================================
DELIMITER //

-- RG64 : dès qu'un livreur redevient libre, la livraison en attente la plus ancienne
-- de son agence lui est affectée (premier arrivé, premier servi).
-- À appeler par l'application après chaque livraison clôturée ou échouée :
--     CALL sp_affecter_livraisons_attente(<id_agence>);
CREATE PROCEDURE sp_affecter_livraisons_attente(IN p_id_agence INT UNSIGNED)
BEGIN
    DECLARE v_livraison, v_livreur INT UNSIGNED;
    boucle: LOOP
        SET v_livraison = (SELECT l.id_livraison FROM livraison l JOIN commande c ON c.id_commande = l.id_commande
                            WHERE c.id_agence = p_id_agence AND l.statut_livraison = 'En attente de livreur'
                            ORDER BY l.date_creation_livraison, l.id_livraison LIMIT 1);
        SET v_livreur = (SELECT e.id_employe FROM employe e JOIN role r ON r.id_role = e.id_role
                          WHERE r.libelle_role = 'Livreur' AND e.id_agence = p_id_agence
                            AND e.statut_compte = 'Actif' AND e.disponibilite_livreur = 'Libre'
                          ORDER BY e.id_employe LIMIT 1);
        IF v_livraison IS NULL OR v_livreur IS NULL THEN
            LEAVE boucle;
        END IF;
        UPDATE livraison SET statut_livraison = 'Assignée', id_employe = v_livreur WHERE id_livraison = v_livraison;
    END LOOP;
END //

-- RG61 : en cas de perte, le gérant génère un nouveau code ; l'ancien est désactivé (journalisé, RG90)
CREATE PROCEDURE sp_regenerer_code(IN p_id_commande INT UNSIGNED, IN p_id_employe INT UNSIGNED)
BEGIN
    DECLARE v_code CHAR(6);
    DECLARE v_client INT UNSIGNED;
    DECLARE v_numero VARCHAR(30);
    IF NOT EXISTS (SELECT 1 FROM code_validation WHERE id_commande = p_id_commande AND statut_code = 'Actif') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG61 : cette commande n''a pas de code actif à remplacer.';
    END IF;
    UPDATE code_validation SET statut_code = 'Désactivé' WHERE id_commande = p_id_commande AND statut_code = 'Actif';
    SET v_code = LPAD(FLOOR(RAND() * 1000000), 6, '0');
    INSERT INTO code_validation (valeur_qr, code_numerique, id_commande)
    VALUES (SHA2(CONCAT(UUID(), RAND()), 256), v_code, p_id_commande);
    SELECT id_client, numero_commande INTO v_client, v_numero FROM commande WHERE id_commande = p_id_commande;
    INSERT INTO notification (type_notification, contenu, id_client, id_commande)
    VALUES ('Code de validation', CONCAT('Nouveau code pour la commande n° ', v_numero, ' : ', v_code, '.'),
            v_client, p_id_commande);
    INSERT INTO journal_action (type_action, entite_concernee, id_entite, detail_action, id_employe)
    VALUES ('Modification', 'code_validation', p_id_commande, 'Régénération du code de validation', p_id_employe);
END //

DELIMITER ;


-- =============================================================================
-- 7. VUES
-- =============================================================================

-- Détail du montant de chaque commande (RG47, RG48, RG51)
CREATE VIEW v_montants_commande AS
SELECT c.id_commande, c.numero_commande, c.id_agence, c.statut_commande, c.type_service, c.mode_recuperation,
       cl.id_client, CONCAT(cl.nom_client, ' ', COALESCE(cl.prenom_client, '')) AS client,
       fn_montant_vetements(c.id_commande)                                      AS montant_vetements,
       ROUND(fn_montant_vetements(c.id_commande) * c.taux_majoration_applique / 100, 0) AS montant_majoration,
       fn_montant_supplements(c.id_commande)                                    AS montant_supplements,
       c.taux_remise,
       fn_montant_total(c.id_commande)                                          AS montant_total,
       fn_total_paye(c.id_commande, 'Commande')                                 AS montant_paye,
       fn_montant_total(c.id_commande) - fn_total_paye(c.id_commande, 'Commande') AS reste_a_payer,
       fn_date_retrait_prevue(c.id_commande)                                    AS date_retrait_prevue
  FROM commande c JOIN client cl ON cl.id_client = c.id_client;

-- Poids du lot et mode de facturation du lot (RG27 à RG29)
CREATE VIEW v_lot_poids AS
SELECT c.id_commande, c.numero_commande,
       COALESCE(SUM(v.poids_kg), 0) AS poids_lot_kg, COUNT(v.id_vetement) AS nb_vetements_lot,
       CASE WHEN COUNT(v.id_vetement) = 0 THEN NULL
            WHEN SUM(v.poids_kg) >= c.seuil_poids_applique THEN 'Poids' ELSE 'Pièce' END AS mode_facturation_lot
  FROM commande c
  LEFT JOIN vetement v ON v.id_commande = c.id_commande AND v.prix_applique IS NULL AND v.statut_vetement <> 'Refusé'
 GROUP BY c.id_commande, c.numero_commande, c.seuil_poids_applique;

-- Commandes en retard de retrait et frais de retard (RG74 à RG77)
CREATE VIEW v_frais_retard AS
SELECT c.id_commande, c.numero_commande, c.id_agence, cl.telephone_client,
       fn_date_retrait_prevue(c.id_commande) + INTERVAL c.delai_grace_applique DAY AS fin_delai_grace,
       (SELECT COUNT(*) FROM vetement v WHERE v.id_commande = c.id_commande AND v.statut_vetement = 'Prêt') AS vetements_restants,
       fn_frais_retard(c.id_commande, FALSE)                                         AS frais_retard_dus,
       fn_total_paye(c.id_commande, 'Frais de retard')                               AS frais_retard_payes
  FROM commande c JOIN client cl ON cl.id_client = c.id_client
 WHERE c.mode_recuperation = 'Retrait' AND c.statut_commande IN ('Terminée', 'Partiellement retirée')
   AND fn_frais_retard(c.id_commande, FALSE) > 0;

-- RG87 : commandes à rappeler (prêtes, date prévue dépassée, délai de grâce non écoulé)
CREATE VIEW v_rappels_a_envoyer AS
SELECT c.id_commande, c.numero_commande, cl.id_client, cl.telephone_client,
       fn_date_retrait_prevue(c.id_commande) AS date_retrait_prevue,
       fn_date_retrait_prevue(c.id_commande) + INTERVAL c.delai_grace_applique DAY AS fin_delai_grace
  FROM commande c JOIN client cl ON cl.id_client = c.id_client
 WHERE c.mode_recuperation = 'Retrait' AND c.statut_commande IN ('Terminée', 'Partiellement retirée')
   AND NOW() BETWEEN fn_date_retrait_prevue(c.id_commande)
                 AND fn_date_retrait_prevue(c.id_commande) + INTERVAL c.delai_grace_applique DAY;

-- RG63, RG64 : livreurs libres et livraisons en attente (la plus ancienne d'abord)
CREATE VIEW v_livreurs_libres AS
SELECT e.id_employe, e.nom_employe, e.prenom_employe, e.telephone_employe, e.id_agence
  FROM employe e JOIN role r ON r.id_role = e.id_role
 WHERE r.libelle_role = 'Livreur' AND e.statut_compte = 'Actif' AND e.disponibilite_livreur = 'Libre';

CREATE VIEW v_livraisons_en_attente AS
SELECT l.id_livraison, l.date_creation_livraison, l.nb_tentatives, c.id_agence, c.numero_commande,
       cl.nom_client, cl.telephone_client, l.adresse_livraison
  FROM livraison l JOIN commande c ON c.id_commande = l.id_commande JOIN client cl ON cl.id_client = c.id_client
 WHERE l.statut_livraison = 'En attente de livreur'
 ORDER BY c.id_agence, l.date_creation_livraison;

-- RG66 : feuille de route du livreur
CREATE VIEW v_livraisons_livreur AS
SELECT l.id_employe, l.id_livraison, l.statut_livraison, c.numero_commande,
       CONCAT(cl.nom_client, ' ', COALESCE(cl.prenom_client, '')) AS client, cl.telephone_client, l.adresse_livraison
  FROM livraison l JOIN commande c ON c.id_commande = l.id_commande JOIN client cl ON cl.id_client = c.id_client
 WHERE l.statut_livraison IN ('Assignée', 'En cours');

-- RG19 à RG21 : état de la fidélité de chaque client
CREATE VIEW v_fidelite_clients AS
SELECT cl.id_client, cl.nom_client, cl.prenom_client, cl.id_agence,
       fn_nb_commandes_eligibles(cl.id_client)                     AS nb_commandes_eligibles,
       a.seuil_fidelite,
       fn_nb_commandes_eligibles(cl.id_client) >= a.seuil_fidelite AS reduction_disponible
  FROM client cl JOIN agence a ON a.id_agence = cl.id_agence;

-- RG10 : agences actives sans gérant actif (doit rester vide)
CREATE VIEW v_agences_sans_gerant AS
SELECT a.id_agence, a.nom_agence
  FROM agence a
 WHERE a.statut_agence = 'Active'
   AND NOT EXISTS (SELECT 1 FROM employe e JOIN role r ON r.id_role = e.id_role
                    WHERE e.id_agence = a.id_agence AND r.libelle_role = 'Gérant' AND e.statut_compte = 'Actif');

-- RG11, RG12, RG92 : tableau de bord par agence (calculé, jamais stocké)
CREATE VIEW v_tableau_bord_agence AS
SELECT a.id_agence, a.nom_agence,
       (SELECT COALESCE(SUM(p.montant_paiement), 0) FROM paiement p JOIN commande c ON c.id_commande = p.id_commande
         WHERE c.id_agence = a.id_agence) AS chiffre_affaires,
       (SELECT COUNT(*) FROM commande c WHERE c.id_agence = a.id_agence
         AND c.statut_commande NOT IN ('Retirée', 'Livrée', 'Annulée')) AS commandes_en_cours,
       (SELECT COUNT(*) FROM vetement v JOIN commande c ON c.id_commande = v.id_commande
         WHERE c.id_agence = a.id_agence AND v.statut_vetement IN ('Retiré', 'Livré')) AS vetements_traites,
       (SELECT COUNT(*) FROM livraison l JOIN commande c ON c.id_commande = l.id_commande
         WHERE c.id_agence = a.id_agence AND l.statut_livraison = 'Livrée') AS livraisons_effectuees,
       (SELECT COUNT(*) FROM livraison l JOIN commande c ON c.id_commande = l.id_commande
         WHERE c.id_agence = a.id_agence AND l.statut_livraison = 'En attente de livreur') AS livraisons_en_attente,
       (SELECT COUNT(*) FROM incident i JOIN commande c ON c.id_commande = i.id_commande
         WHERE c.id_agence = a.id_agence AND i.statut_incident <> 'Clôturé') AS incidents_ouverts
  FROM agence a;


-- =============================================================================
-- 8. DONNÉES DE RÉFÉRENCE
--    Les agences, tarifs, employés, clients et commandes de test seront dans
--    un script séparé (jeu de données de test).
-- =============================================================================
INSERT INTO role (libelle_role) VALUES ('Administrateur'), ('Gérant'), ('Livreur');

INSERT INTO supplement (libelle_supplement, description_supplement, portee_supplement) VALUES
    ('Repassage',            'Repassage du vêtement',                         'Vêtement'),
    ('Blanchissage',         'Blanchiment du linge blanc',                    'Vêtement'),
    ('Détachage',            'Traitement des taches',                         'Vêtement'),
    ('Livraison à domicile', 'Livraison de la commande à l''adresse du client', 'Commande');

INSERT INTO categorie_article (libelle_categorie, description_categorie) VALUES
    ('Costumes',        'Costumes et vestes'),
    ('Robes',           'Robes, dont robes de soirée'),
    ('Linge de maison', 'Draps, couvertures, rideaux, serviettes');

-- =============================================================================
-- Fin : 22 tables, 33 clés étrangères, 7 fonctions, 27 déclencheurs,
--       2 procédures, 10 vues.
-- =============================================================================
