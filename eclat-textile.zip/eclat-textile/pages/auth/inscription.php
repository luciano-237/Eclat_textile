<?php
/**
 * Demande de création de compte (gérant ou livreur).
 * Le compte est créé « Suspendu » : il ne permet de se connecter qu'après validation
 * par l'administrateur (RG13). Aucun compte administrateur ne peut être créé ici.
 */
if (user()) {
    redirect('tableau-de-bord');
}
$layout = 'bare';
$title = 'Créer un compte';
$agences = agences(true);
$roles = rows("SELECT * FROM role WHERE libelle_role IN ('Gérant', 'Livreur') ORDER BY id_role");
$errors = [];
$envoye = false;

if (is_post()) {
    csrf_check();
    $email = (string) post('email');
    $pw = (string) ($_POST['password'] ?? '');
    $idRole = (int) post('id_role');
    $idAg = (int) post('id_agence');
    if (post('nom') === '') $errors[] = 'Le nom est obligatoire.';
    if (post('telephone') === '') $errors[] = 'Le téléphone est obligatoire.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Adresse e-mail invalide.';
    if (mb_strlen($pw) < 8) $errors[] = 'Le mot de passe doit contenir au moins 8 caractères.';
    if ($pw !== ($_POST['confirmation'] ?? '')) $errors[] = 'La confirmation du mot de passe ne correspond pas.';
    if (!in_array($idRole, array_map('intval', array_column($roles, 'id_role')), true)) $errors[] = 'Choisissez un rôle.';
    if (!in_array($idAg, array_map('intval', array_column($agences, 'id_agence')), true)) $errors[] = 'Choisissez votre agence.';
    if (!$errors) {
        try {
            transaction(function () use ($email, $pw, $idRole, $idAg) {
                q("INSERT INTO employe (nom_employe, prenom_employe, telephone_employe, email_employe, mot_de_passe, statut_compte, id_role, id_agence)
                   VALUES (?, ?, ?, ?, ?, 'Suspendu', ?, ?)",
                    [post('nom'), nullable(post('prenom')), post('telephone'), $email, password_hash($pw, PASSWORD_DEFAULT), $idRole, $idAg]);
                $id = (int) db()->lastInsertId();
                q("INSERT INTO journal_action (type_action, entite_concernee, id_entite, detail_action, id_employe)
                   VALUES ('Création', 'employe', ?, ?, ?)", [$id, 'Demande d\'inscription de ' . $email . ' (en attente de validation)', $id]);
            });
            $envoye = true;
        } catch (Throwable $ex) {
            $errors[] = db_error($ex);
        }
    }
}
?>
<div class="auth-card">
<?php if ($envoye): ?>
    <div class="empty-icon" style="background:var(--good-bg);color:var(--good)"><?= icon('check-circle', 28) ?></div>
    <h1>Demande envoyée</h1>
    <p class="lead">Votre compte a été créé et attend la validation de l'administrateur. Vous pourrez vous connecter dès qu'il l'aura activé.</p>
    <a class="btn btn-primary btn-lg btn-block" href="<?= e(url('connexion')) ?>"><?= icon('back', 16) ?> Retour à la connexion</a>
<?php else: ?>
    <h1>Créer un compte</h1>
    <p class="lead">Rejoignez votre agence. Votre compte sera activé par l'administrateur.</p>

    <?php foreach ($errors as $er): ?>
        <div class="alert alert-critical mb-2"><?= icon('alert') ?><div><?= e($er) ?></div></div>
    <?php endforeach; ?>

    <?php if (!$agences): ?>
        <div class="alert alert-warning"><?= icon('alert') ?><div>Aucune agence n'est encore ouverte. Contactez l'administrateur.</div></div>
    <?php else: ?>
    <form method="post" autocomplete="on">
        <?= csrf_field() ?>
        <p class="section-title">Je suis</p>
        <div class="choices mb-2">
            <?php $ic = ['Gérant' => 'store', 'Livreur' => 'truck']; $desc = ['Gérant' => 'Comptoir de l\'agence', 'Livreur' => 'Livraisons à domicile'];
            foreach ($roles as $i => $r): ?>
                <label class="choice"><input type="radio" name="id_role" value="<?= $r['id_role'] ?>"<?= checked((string) post('id_role', $i === 0 ? $r['id_role'] : '') === (string) $r['id_role']) ?>>
                    <span class="choice-card"><span class="choice-icon"><?= icon($ic[$r['libelle_role']]) ?></span><span><strong><?= e($r['libelle_role']) ?></strong><small><?= e($desc[$r['libelle_role']]) ?></small></span></span></label>
            <?php endforeach; ?>
        </div>
        <div class="form-grid">
            <div class="field span-2"><label class="req" for="id_agence">Agence</label>
                <select class="select" id="id_agence" name="id_agence" required><option value="">Choisir…</option>
                    <?php foreach ($agences as $a): ?><option value="<?= $a['id_agence'] ?>"<?= selected(post('id_agence'), $a['id_agence']) ?>><?= e($a['nom_agence']) ?> — <?= e($a['ville_agence']) ?></option><?php endforeach; ?></select></div>
            <div class="field"><label class="req" for="nom">Nom</label><input class="input" id="nom" name="nom" required maxlength="50" value="<?= e(old('nom')) ?>"></div>
            <div class="field"><label for="prenom">Prénom</label><input class="input" id="prenom" name="prenom" maxlength="50" value="<?= e(old('prenom')) ?>"></div>
            <div class="field span-2"><label class="req" for="email">Adresse e-mail</label>
                <div class="input-group"><?= icon('mail', 16) ?><input class="input" type="email" id="email" name="email" required maxlength="120" value="<?= e(old('email')) ?>"></div></div>
            <div class="field span-2"><label class="req" for="telephone">Téléphone</label>
                <div class="input-group"><?= icon('phone', 16) ?><input class="input" id="telephone" name="telephone" required maxlength="20" value="<?= e(old('telephone')) ?>" placeholder="6XX XX XX XX"></div></div>
            <div class="field"><label class="req" for="password">Mot de passe</label><input class="input" type="password" id="password" name="password" minlength="8" required autocomplete="new-password"></div>
            <div class="field"><label class="req" for="confirmation">Confirmation</label><input class="input" type="password" id="confirmation" name="confirmation" minlength="8" required autocomplete="new-password"></div>
        </div>
        <button class="btn btn-primary btn-lg btn-block mt-3" type="submit">Envoyer ma demande <?= icon('chevron', 16) ?></button>
    </form>
    <?php endif; ?>
    <p class="auth-foot center">Déjà un compte ? <a href="<?= e(url('connexion')) ?>">Se connecter</a></p>
<?php endif; ?>
</div>
