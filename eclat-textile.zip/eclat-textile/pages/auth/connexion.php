<?php
/** Connexion des employés (identifiant : adresse e-mail). */
if (user()) {
    redirect(is_livreur() ? 'tournee' : 'tableau-de-bord');
}
$layout = 'bare';
$title = 'Connexion';
$error = null;

if (is_post()) {
    csrf_check();
    $error = attempt_login((string) post('email'), (string) ($_POST['password'] ?? ''));
    if ($error === null) {
        flash('success', 'Bienvenue, ' . (user()['prenom'] ?: user()['nom']) . ' !');
        redirect(is_livreur() ? 'tournee' : 'tableau-de-bord');
    }
}

// Comptes de démonstration (affichés seulement si le jeu de démo est chargé)
$demo = rows("SELECT e.email_employe, e.nom_employe, e.prenom_employe, r.libelle_role, a.nom_agence
                FROM employe e JOIN role r ON r.id_role = e.id_role LEFT JOIN agence a ON a.id_agence = e.id_agence
               WHERE e.email_employe LIKE '%@demo.pressing' AND e.statut_compte = 'Actif'
               ORDER BY e.id_role, e.id_agence, e.id_employe LIMIT 5");
?>
<div class="auth-card">
    <h1>Connexion</h1>
    <p class="lead">Accédez à votre espace avec votre adresse e-mail professionnelle.</p>

    <?php if ($error): ?>
        <div class="alert alert-critical mb-2"><?= icon('alert') ?><div><?= e($error) ?></div></div>
    <?php endif; ?>

    <form method="post" autocomplete="on">
        <?= csrf_field() ?>
        <div class="field">
            <label for="email">Adresse e-mail</label>
            <div class="input-group"><?= icon('mail', 16) ?>
                <input class="input" type="email" id="email" name="email" required autofocus value="<?= e(post('email', '')) ?>" placeholder="prenom.nom@pressing.cm">
            </div>
        </div>
        <div class="field">
            <label for="password">Mot de passe</label>
            <div class="input-group"><?= icon('lock', 16) ?>
                <input class="input" type="password" id="password" name="password" required placeholder="••••••••">
                <button type="button" class="icon-btn pw-toggle" data-toggle-password="password" aria-label="Afficher le mot de passe"><?= icon('eye', 16) ?></button>
            </div>
        </div>
        <button class="btn btn-primary btn-lg btn-block mt-3" type="submit">Se connecter <?= icon('chevron', 16) ?></button>
    </form>
    <div class="signup-link">
        <span>Nouveau dans l'équipe ?</span>
        <a class="btn btn-secondary btn-block" href="<?= e(url('inscription')) ?>"><?= icon('user', 16) ?> Créer un compte</a>
    </div>

    <?php if ($demo): ?>
        <div class="auth-foot">
            <div class="row between"><strong class="text-2">Comptes de démonstration</strong><span class="chip">mot de passe : demo1234</span></div>
            <div class="demo-accounts">
                <?php foreach ($demo as $d): ?>
                    <button type="button" class="demo-account" data-demo-email="<?= e($d['email_employe']) ?>" data-demo-password="demo1234">
                        <span class="avatar avatar-soft"><?= e(initials($d['nom_employe'], $d['prenom_employe'])) ?></span>
                        <span class="grow"><?= e(full_name($d['nom_employe'], $d['prenom_employe'])) ?>
                            <small><?= e($d['libelle_role']) ?><?= $d['nom_agence'] ? ' · ' . e($d['nom_agence']) : '' ?></small></span>
                        <?= icon('chevron', 16, 'muted') ?>
                    </button>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>
</div>
