<?php
/** Profil de l'employé connecté et changement de mot de passe. */
$title = 'Mon compte';
$me = row('SELECT e.*, r.libelle_role, a.nom_agence FROM employe e JOIN role r ON r.id_role = e.id_role LEFT JOIN agence a ON a.id_agence = e.id_agence WHERE e.id_employe = ?', [my_id()]);

if (is_post()) {
    csrf_check();
    try {
        if (!password_verify((string) ($_POST['actuel'] ?? ''), $me['mot_de_passe'])) throw new RuntimeException('Mot de passe actuel incorrect.');
        $nv = (string) ($_POST['nouveau'] ?? '');
        if (mb_strlen($nv) < 8) throw new RuntimeException('Le nouveau mot de passe doit contenir au moins 8 caractères.');
        if ($nv !== ($_POST['confirmation'] ?? '')) throw new RuntimeException('La confirmation ne correspond pas.');
        q('UPDATE employe SET mot_de_passe = ? WHERE id_employe = ?', [password_hash($nv, PASSWORD_DEFAULT), my_id()]);
        q("INSERT INTO journal_action (type_action, entite_concernee, id_entite, detail_action, id_employe) VALUES ('Modification', 'employe', ?, 'Changement de mot de passe', ?)", [my_id(), my_id()]);
        flash('success', 'Mot de passe modifié.');
    } catch (Throwable $ex) {
        flash('error', db_error($ex));
    }
    redirect('mon-compte');
}
echo page_header('Mon compte');
?>
<div class="grid grid-2" style="max-width:1000px">
    <div class="card"><div class="card-body" style="text-align:center">
        <span class="avatar avatar-lg" style="margin:0 auto 12px"><?= e(initials($me['nom_employe'], $me['prenom_employe'])) ?></span>
        <h2 style="font-size:20px"><?= e(full_name($me['nom_employe'], $me['prenom_employe'])) ?></h2>
        <div class="row-wrap mt-1" style="justify-content:center"><?= badge($me['libelle_role'], 'teal') ?><?php if ($me['disponibilite_livreur']) echo badge($me['disponibilite_livreur']); ?></div>
        <dl class="dl mt-3" style="text-align:left">
            <dt>E-mail</dt><dd><?= e($me['email_employe']) ?></dd>
            <dt>Téléphone</dt><dd><?= e($me['telephone_employe']) ?></dd>
            <dt>Agence</dt><dd><?= e($me['nom_agence'] ?? 'Réseau (toutes les agences)') ?></dd>
            <dt>Date d'embauche</dt><dd><?= e(dt($me['date_embauche'], false)) ?></dd>
        </dl>
    </div></div>
    <form method="post" class="card"><?= csrf_field() ?>
        <div class="card-header"><h2><?= icon('lock') ?> Changer le mot de passe</h2></div>
        <div class="card-body stack">
            <div class="field"><label class="req" for="actuel">Mot de passe actuel</label><input class="input" type="password" id="actuel" name="actuel" required autocomplete="current-password"></div>
            <div class="field"><label class="req" for="nouveau">Nouveau mot de passe</label><input class="input" type="password" id="nouveau" name="nouveau" minlength="8" required autocomplete="new-password"></div>
            <div class="field"><label class="req" for="confirmation">Confirmation</label><input class="input" type="password" id="confirmation" name="confirmation" minlength="8" required autocomplete="new-password"></div>
        </div>
        <div class="card-footer row" style="justify-content:flex-end"><button class="btn btn-primary" type="submit"><?= icon('check') ?> Mettre à jour</button></div>
    </form>
</div>
