<?php
/**
 * Premier lancement : création du compte administrateur (RG09 : rattaché à aucune agence)
 * et, en option, chargement d'un jeu de données de démonstration.
 */
$layout = 'bare';
$title = 'Installation';

if (val("SELECT 1 FROM employe e JOIN role r ON r.id_role = e.id_role WHERE r.libelle_role = 'Administrateur' LIMIT 1")) {
    redirect(user() ? 'tableau-de-bord' : 'connexion');
}

$errors = [];
if (is_post()) {
    csrf_check();
    $nom = post('nom');
    $email = post('email');
    $pw = (string) ($_POST['password'] ?? '');
    if ($nom === '') $errors[] = 'Le nom est obligatoire.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Adresse e-mail invalide.';
    if (mb_strlen($pw) < 8) $errors[] = 'Le mot de passe doit contenir au moins 8 caractères.';
    if (!$errors) {
        try {
            transaction(function () use ($nom, $email, $pw) {
                $idRole = val("SELECT id_role FROM role WHERE libelle_role = 'Administrateur'");
                q('INSERT INTO employe (nom_employe, prenom_employe, telephone_employe, email_employe, mot_de_passe, id_role, id_agence, date_embauche)
                   VALUES (?, ?, ?, ?, ?, ?, NULL, CURRENT_DATE)',
                    [$nom, nullable(post('prenom')), post('telephone') ?: '-', $email, password_hash($pw, PASSWORD_DEFAULT), $idRole]);
                if (post('demo')) {
                    require APP_ROOT . '/app/demo.php';
                    charger_demo((int) db()->lastInsertId());
                }
            });
            flash('success', 'Installation terminée. Connectez-vous avec votre compte administrateur.');
            redirect('connexion');
        } catch (Throwable $ex) {
            $errors[] = db_error($ex);
        }
    }
}
?>
<div class="auth-card">
    <span class="chip"><?= icon('sparkles', 14) ?> Premier lancement</span>
    <h1 class="mt-1">Installons votre réseau</h1>
    <p class="lead">Créez le compte administrateur : il configure les agences, les tarifs et les comptes du personnel.</p>

    <?php foreach ($errors as $er): ?>
        <div class="alert alert-critical mb-2"><?= icon('alert') ?><div><?= e($er) ?></div></div>
    <?php endforeach; ?>

    <form method="post">
        <?= csrf_field() ?>
        <div class="form-grid">
            <div class="field"><label class="req" for="nom">Nom</label><input class="input" id="nom" name="nom" required value="<?= e(old('nom')) ?>"></div>
            <div class="field"><label for="prenom">Prénom</label><input class="input" id="prenom" name="prenom" value="<?= e(old('prenom')) ?>"></div>
            <div class="field span-2"><label class="req" for="email">E-mail de connexion</label><input class="input" type="email" id="email" name="email" required value="<?= e(old('email')) ?>"></div>
            <div class="field"><label for="telephone">Téléphone</label><input class="input" id="telephone" name="telephone" value="<?= e(old('telephone')) ?>" placeholder="6XX XX XX XX"></div>
            <div class="field"><label class="req" for="password">Mot de passe</label><input class="input" type="password" id="password" name="password" minlength="8" required></div>
        </div>
        <label class="choice mt-2" style="display:block">
            <input type="checkbox" name="demo" value="1" checked>
            <span class="choice-card">
                <span class="choice-icon"><?= icon('sparkles') ?></span>
                <span><strong>Charger des données de démonstration</strong>
                <small>2 agences, leurs tarifs, gérants, livreurs, clients et quelques commandes. Comptes de test : mot de passe <code>demo1234</code>.</small></span>
            </span>
        </label>
        <button class="btn btn-primary btn-lg btn-block mt-3" type="submit">Terminer l'installation</button>
    </form>
</div>
