<?php
logout();
session_start();
flash('info', 'Vous êtes déconnecté.');
redirect('connexion');
