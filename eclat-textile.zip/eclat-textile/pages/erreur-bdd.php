<?php
/** Affiché quand la base « pressing » est inaccessible. */
$title = 'Connexion à la base impossible';
$c = cfg('db');
$msg = $dbError instanceof PDOException ? ($dbError->errorInfo[2] ?? $dbError->getMessage()) : $dbError->getMessage();
ob_start(); ?>
<div class="auth-card">
    <div class="empty-icon" style="background:var(--critical-bg);color:var(--critical)"><?= icon('alert', 28) ?></div>
    <h1>Base de données inaccessible</h1>
    <p class="lead">L'application n'arrive pas à se connecter à MySQL. Vérifiez que le serveur est démarré et que le script
        <code>base_de_donnees_pressing.sql</code> a bien été exécuté.</p>
    <div class="alert alert-critical"><?= icon('alert') ?><div><strong>Message du serveur</strong><?= e($msg) ?></div></div>
    <div class="card mt-2"><div class="card-body">
        <dl class="dl">
            <dt>Hôte</dt><dd><?= e($c['host']) ?>:<?= e($c['port']) ?></dd>
            <dt>Base</dt><dd><?= e($c['name']) ?></dd>
            <dt>Utilisateur</dt><dd><?= e($c['user']) ?></dd>
        </dl>
    </div></div>
    <p class="auth-foot">Modifiez ces paramètres dans <code>config/config.php</code>, puis rechargez la page.</p>
</div>
<?php
$content = ob_get_clean();
require APP_ROOT . '/app/layout/bare.php';
