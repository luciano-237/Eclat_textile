<?php
/** Création / modification d'un client (rattaché à l'agence du gérant : RG17). */
$id = (int) get('id');
$retour = get('retour');
$c = $id ? row('SELECT * FROM client WHERE id_client = ?', [$id]) : null;
if ($id && !$c) {
    flash('error', 'Client introuvable.');
    redirect('clients');
}
$title = $c ? 'Modifier le client' : 'Nouveau client';

if (is_post()) {
    csrf_check();
    $tel = preg_replace('/[^0-9+]/', '', (string) post('telephone_client'));
    $data = [post('nom_client'), nullable(post('prenom_client')), $tel, nullable(post('email_client')), nullable(post('adresse_client'))];
    try {
        if ($data[0] === '' || $tel === '') throw new RuntimeException('Le nom et le téléphone sont obligatoires.');
        if ($data[3] !== null && !filter_var($data[3], FILTER_VALIDATE_EMAIL)) throw new RuntimeException('Adresse e-mail invalide.');
        if ($c) {
            q('UPDATE client SET nom_client = ?, prenom_client = ?, telephone_client = ?, email_client = ?, adresse_client = ? WHERE id_client = ?', [...$data, $id]);
            flash('success', 'Fiche client mise à jour.');
        } else {
            q('INSERT INTO client (nom_client, prenom_client, telephone_client, email_client, adresse_client, id_agence) VALUES (?, ?, ?, ?, ?, ?)', [...$data, my_agence()]);
            $id = (int) db()->lastInsertId();
            flash('success', 'Client créé et rattaché à l\'agence ' . user()['agence'] . '.');
        }
        if ($retour === 'commande') redirect('commande-nouvelle', ['client' => $id]);
        redirect('client', ['id' => $id]);
    } catch (Throwable $ex) {
        flash('error', db_error($ex));
    }
}
$v = fn($k) => e($_POST[$k] ?? ($c[$k] ?? ($k === 'telephone_client' ? get('telephone', '') : '')));
$back = $retour === 'commande' ? url('commande-nouvelle', $id ? ['client' => $id] : []) : ($c ? url('client', ['id' => $id]) : url('clients'));
echo page_header($title, $c ? e(full_name($c['nom_client'], $c['prenom_client'])) : 'Le téléphone identifie le client et reçoit les avis WhatsApp et SMS.', '', $back);
?>
<form method="post" class="card" style="max-width:760px">
    <?= csrf_field() ?>
    <div class="card-body">
        <div class="form-grid">
            <div class="field"><label class="req" for="nom_client">Nom</label><input class="input" id="nom_client" name="nom_client" required maxlength="50" value="<?= $v('nom_client') ?>" autofocus></div>
            <div class="field"><label for="prenom_client">Prénom</label><input class="input" id="prenom_client" name="prenom_client" maxlength="50" value="<?= $v('prenom_client') ?>"></div>
            <div class="field"><label class="req" for="telephone_client">Téléphone</label>
                <div class="input-group"><?= icon('phone', 16) ?><input class="input" id="telephone_client" name="telephone_client" required maxlength="20" value="<?= $v('telephone_client') ?>" placeholder="6XX XX XX XX"></div>
                <span class="hint">Unique dans tout le réseau (RG16).</span></div>
            <div class="field"><label for="email_client">E-mail</label>
                <div class="input-group"><?= icon('mail', 16) ?><input class="input" type="email" id="email_client" name="email_client" maxlength="120" value="<?= $v('email_client') ?>"></div></div>
            <div class="field span-2"><label for="adresse_client">Adresse</label>
                <textarea class="textarea" id="adresse_client" name="adresse_client" maxlength="255" placeholder="Quartier, rue, point de repère…"><?= $v('adresse_client') ?></textarea>
                <span class="hint">Obligatoire pour une livraison à domicile.</span></div>
        </div>
    </div>
    <div class="card-footer row between">
        <span class="small muted"><?= $c ? 'Agence de fidélité : ' . e(val('SELECT nom_agence FROM agence WHERE id_agence = ?', [$c['id_agence']])) : 'Agence de fidélité : ' . e(user()['agence']) ?></span>
        <div class="row"><a class="btn btn-ghost" href="<?= e($back) ?>">Annuler</a><button class="btn btn-primary" type="submit"><?= icon('check') ?> Enregistrer</button></div>
    </div>
</form>
