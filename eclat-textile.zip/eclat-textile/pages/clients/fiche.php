<?php
/** Fiche client : coordonnées, fidélité, historique des commandes et notifications. */
$id = (int) get('id');
$c = row('SELECT cl.*, a.nom_agence, a.taux_fidelite, f.nb_commandes_eligibles, f.seuil_fidelite, f.reduction_disponible
            FROM client cl JOIN agence a ON a.id_agence = cl.id_agence JOIN v_fidelite_clients f ON f.id_client = cl.id_client
           WHERE cl.id_client = ?', [$id]);
if (!$c) {
    flash('error', 'Client introuvable.');
    redirect('clients');
}
$title = full_name($c['nom_client'], $c['prenom_client']);
$cmds = rows('SELECT m.*, c.date_commande, a.nom_agence FROM v_montants_commande m JOIN commande c ON c.id_commande = m.id_commande
               JOIN agence a ON a.id_agence = m.id_agence WHERE m.id_client = ? ORDER BY c.date_commande DESC', [$id]);
$notifs = rows('SELECT * FROM notification WHERE id_client = ? ORDER BY date_notification DESC LIMIT 8', [$id]);
$depense = array_sum(array_map(fn($x) => $x['statut_commande'] === 'Annulée' ? 0 : $x['montant_paye'], $cmds));
$pct = min(100, $c['nb_commandes_eligibles'] / max(1, $c['seuil_fidelite']) * 100);

$actions = '';
if (is_gerant()) {
    $actions = '<a class="btn btn-secondary" href="' . e(url('client-form', ['id' => $id])) . '">' . icon('edit') . ' Modifier</a>'
        . '<a class="btn btn-primary" href="' . e(url('commande-nouvelle', ['client' => $id])) . '">' . icon('plus') . ' Nouveau dépôt</a>';
}
echo page_header($title, 'Client depuis le ' . e(dt($c['date_inscription'], false)) . ' · fidèle à l\'agence ' . e($c['nom_agence']), $actions, url('clients'));
?>
<div class="grid grid-main">
    <div class="stack">
        <div class="grid grid-3">
            <?= kpi('Commandes', num(count($cmds)), 'receipt', 'info') ?>
            <?= kpi('Total réglé', kpi_money($depense), 'wallet', 'teal') ?>
            <?= kpi('Fidélité', (int) $c['nb_commandes_eligibles'] . '<small>/ ' . (int) $c['seuil_fidelite'] . '</small>', 'gift', $c['reduction_disponible'] ? 'good' : 'violet',
                $c['reduction_disponible'] ? 'Réduction de ' . num($c['taux_fidelite'], 0) . ' % au prochain dépôt' : 'Commandes éligibles') ?>
        </div>
        <div class="card card-flush">
            <div class="card-header"><h2><?= icon('receipt') ?> Historique des commandes</h2></div>
            <?php if ($cmds): ?>
            <div class="table-wrap"><table class="table">
                <thead><tr><th>Commande</th><th>Date</th><th>Agence</th><th class="num">Montant</th><th>Statut</th></tr></thead>
                <tbody><?php foreach ($cmds as $m): ?>
                    <tr class="clickable" data-href="<?= e(url('commande', ['id' => $m['id_commande']])) ?>">
                        <td><span class="ref"><?= e($m['numero_commande']) ?></span> <?= $m['taux_remise'] > 0 ? '<span class="chip" style="color:var(--good)">' . icon('gift', 12) . ' −' . num($m['taux_remise'], 0) . ' %</span>' : '' ?></td>
                        <td class="text-2"><?= e(dt($m['date_commande'])) ?></td><td class="text-2"><?= e($m['nom_agence']) ?></td>
                        <td class="num strong"><?= money($m['montant_total']) ?></td><td><?= badge($m['statut_commande']) ?></td></tr>
                <?php endforeach; ?></tbody>
            </table></div>
            <?php else: echo empty_state('Aucune commande', 'Ce client n\'a encore rien déposé.', 'receipt'); endif; ?>
        </div>
    </div>
    <div class="stack">
        <div class="card"><div class="card-body" style="text-align:center">
            <span class="avatar avatar-lg" style="margin:0 auto 12px"><?= e(initials($c['nom_client'], $c['prenom_client'])) ?></span>
            <h3 style="font-size:18px"><?= e($title) ?></h3>
            <div class="stack-sm mt-2 text-2" style="text-align:left">
                <div class="row"><?= icon('phone', 15) ?> <?= e($c['telephone_client']) ?></div>
                <div class="row"><?= icon('mail', 15) ?> <?= e($c['email_client'] ?: '—') ?></div>
                <div class="row" style="align-items:flex-start"><?= icon('pin', 15) ?> <?= e($c['adresse_client'] ?: 'Adresse non renseignée') ?></div>
            </div>
            <div class="divider"></div>
            <div class="row between small"><span class="label">Vers la prochaine réduction</span><span class="muted"><?= (int) $c['nb_commandes_eligibles'] ?>/<?= (int) $c['seuil_fidelite'] ?></span></div>
            <div class="progress mt-1"><span style="width:<?= $pct ?>%"></span></div>
        </div></div>
        <div class="card">
            <div class="card-header"><h3><?= icon('bell') ?> Notifications</h3></div>
            <?php if ($notifs): ?>
            <ul class="timeline"><?php foreach ($notifs as $n): ?>
                <li><span class="tl-dot"></span><div class="tl-title"><?= e($n['type_notification']) ?> <span class="muted small">· <?= e($n['canal']) ?></span></div>
                    <div class="tl-sub"><?= e(mb_strimwidth($n['contenu'], 0, 90, '…')) ?></div>
                    <div class="tl-sub"><?= e(rel_time($n['date_notification'])) ?> · <?= e($n['statut_envoi']) ?></div></li>
            <?php endforeach; ?></ul>
            <?php else: echo empty_state('Aucune notification', '', 'bell'); endif; ?>
        </div>
    </div>
</div>
