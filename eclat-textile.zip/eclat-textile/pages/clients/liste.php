<?php
/** Liste des clients et état de leur fidélité (RG16 à RG21). */
$title = 'Clients';
$q = (string) get('q', '');
$agence = is_gerant() ? my_agence() : (int) get('agence', 0);
$where = []; $params = [];
if ($agence) { $where[] = 'cl.id_agence = ?'; $params[] = $agence; }
if ($q !== '') {
    $where[] = "(cl.telephone_client LIKE ? OR CONCAT(cl.nom_client, ' ', COALESCE(cl.prenom_client,'')) LIKE ? OR CONCAT(COALESCE(cl.prenom_client,''), ' ', cl.nom_client) LIKE ?)";
    array_push($params, "%$q%", "%$q%", "%$q%");
}
$w = $where ? ' WHERE ' . implode(' AND ', $where) : '';
$pg = paginate((int) val('SELECT COUNT(*) FROM client cl' . $w, $params), 20);
$list = rows('SELECT cl.*, a.nom_agence, f.nb_commandes_eligibles, f.seuil_fidelite, f.reduction_disponible,
                     (SELECT COUNT(*) FROM commande c WHERE c.id_client = cl.id_client) nb_cmd,
                     (SELECT MAX(date_commande) FROM commande c WHERE c.id_client = cl.id_client) derniere
                FROM client cl JOIN agence a ON a.id_agence = cl.id_agence JOIN v_fidelite_clients f ON f.id_client = cl.id_client'
    . $w . ' ORDER BY cl.nom_client, cl.prenom_client LIMIT ' . $pg['limit'] . ' OFFSET ' . $pg['offset'], $params);

echo page_header('Clients', is_gerant() ? 'Clients fidèles de l\'agence ' . e(user()['agence']) : 'Clients du réseau',
    is_gerant() ? '<a class="btn btn-primary" href="' . e(url('client-form')) . '">' . icon('plus') . ' Nouveau client</a>' : '');
?>
<div class="card card-flush">
    <form class="toolbar" method="get">
        <input type="hidden" name="p" value="clients">
        <div class="input-group"><?= icon('search', 16) ?><input class="input" type="search" name="q" value="<?= e($q) ?>" placeholder="Nom ou téléphone"></div>
        <?php if (is_admin()): ?>
            <select class="select" name="agence" style="width:auto" onchange="this.form.submit()">
                <option value="0">Toutes les agences</option>
                <?php foreach (agences() as $ag): ?><option value="<?= $ag['id_agence'] ?>"<?= selected($agence, $ag['id_agence']) ?>><?= e($ag['nom_agence']) ?></option><?php endforeach; ?>
            </select>
        <?php endif; ?>
        <button class="btn btn-secondary" type="submit">Rechercher</button>
        <span class="muted small" style="margin-left:auto"><?= num($pg['total']) ?> client<?= $pg['total'] > 1 ? 's' : '' ?></span>
    </form>
    <?php if ($list): ?>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Client</th><th>Téléphone</th><?php if (is_admin()): ?><th>Agence de fidélité</th><?php endif; ?><th class="num">Commandes</th><th>Fidélité</th><th>Dernier dépôt</th></tr></thead>
        <tbody><?php foreach ($list as $c):
            $pct = min(100, $c['nb_commandes_eligibles'] / max(1, $c['seuil_fidelite']) * 100); ?>
            <tr class="clickable" data-href="<?= e(url('client', ['id' => $c['id_client']])) ?>">
                <td><div class="cell-person"><span class="avatar"><?= e(initials($c['nom_client'], $c['prenom_client'])) ?></span>
                    <div><div class="cell-main"><?= e(full_name($c['nom_client'], $c['prenom_client'])) ?></div>
                        <div class="cell-sub"><?= e($c['adresse_client'] ?: 'Adresse non renseignée') ?></div></div></div></td>
                <td class="mono"><?= e($c['telephone_client']) ?></td>
                <?php if (is_admin()): ?><td class="text-2"><?= e($c['nom_agence']) ?></td><?php endif; ?>
                <td class="num"><?= (int) $c['nb_cmd'] ?></td>
                <td style="min-width:150px">
                    <?php if ($c['reduction_disponible']): ?><?= badge('Réduction disponible', 'good') ?>
                    <?php else: ?><div class="row" style="gap:8px"><div class="progress grow"><span style="width:<?= $pct ?>%"></span></div>
                        <span class="small muted nowrap"><?= (int) $c['nb_commandes_eligibles'] ?>/<?= (int) $c['seuil_fidelite'] ?></span></div><?php endif; ?>
                </td>
                <td class="text-2"><?= $c['derniere'] ? e(rel_time($c['derniere'])) : '—' ?></td>
            </tr>
        <?php endforeach; ?></tbody>
    </table></div>
    <?= pagination_links($pg) ?>
    <?php else: echo empty_state('Aucun client', $q !== '' ? 'Aucun client ne correspond à cette recherche.' : 'Créez la fiche d\'un client lors de son premier dépôt.', 'users',
        is_gerant() ? '<a class="btn btn-primary" href="' . e(url('client-form', ['telephone' => $q])) . '">' . icon('plus') . ' Nouveau client</a>' : ''); endif; ?>
</div>
