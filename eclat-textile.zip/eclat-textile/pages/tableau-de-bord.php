<?php
/** Tableau de bord selon le rôle (RG11, RG12, RG92 : statistiques calculées, jamais stockées). */
$title = 'Tableau de bord';
$u = user();
$h = (int) date('G');
$salut = $h < 12 ? 'Bonjour' : ($h < 18 ? 'Bon après-midi' : 'Bonsoir');
$prenom = $u['prenom'] ?: $u['nom'];

/* ======================================================================= ADMINISTRATEUR */
if (is_admin()):
    $stats = rows('SELECT * FROM v_tableau_bord_agence ORDER BY nom_agence');
    $tot = ['ca' => 0, 'encours' => 0, 'liv' => 0, 'inc' => 0, 'vet' => 0];
    foreach ($stats as $s) {
        $tot['ca'] += $s['chiffre_affaires']; $tot['encours'] += $s['commandes_en_cours'];
        $tot['liv'] += $s['livraisons_en_attente']; $tot['inc'] += $s['incidents_ouverts']; $tot['vet'] += $s['vetements_traites'];
    }
    $caMois = (float) val("SELECT COALESCE(SUM(montant_paiement),0) FROM paiement WHERE date_paiement >= DATE_FORMAT(CURRENT_DATE, '%Y-%m-01')");
    $sansGerant = rows('SELECT * FROM v_agences_sans_gerant');
    $nbClients = (int) val('SELECT COUNT(*) FROM client');
    $journal = rows('SELECT j.*, e.nom_employe, e.prenom_employe FROM journal_action j JOIN employe e ON e.id_employe = j.id_employe ORDER BY j.id_action DESC LIMIT 7');
    $chart = encaissements_par_jour(14);
?>
    <div class="hero mb-2">
        <div class="hero-row">
            <div>
                <h1><?= e($salut) ?>, <?= e($prenom) ?></h1>
                <p>Vue consolidée du réseau : <?= count($stats) ?> agence<?= count($stats) > 1 ? 's' : '' ?>, <?= num($nbClients) ?> clients fidèles.</p>
            </div>
            <div class="row-wrap">
                <a class="btn btn-secondary" href="<?= e(url('tarifs')) ?>"><?= icon('tag') ?> Tarifs</a>
                <a class="btn btn-primary" href="<?= e(url('agence')) ?>"><?= icon('plus') ?> Nouvelle agence</a>
            </div>
        </div>
    </div>

    <?php foreach ($sansGerant as $a): ?>
        <div class="alert alert-warning mb-2"><?= icon('alert') ?><div><strong>RG10 : agence sans gérant actif</strong>
            L'agence <?= e($a['nom_agence']) ?> n'a aucun gérant actif. <a href="<?= e(url('employe', ['agence' => $a['id_agence']])) ?>">Créer un gérant</a></div></div>
    <?php endforeach; ?>

    <div class="grid grid-4">
        <?= kpi('Chiffre d\'affaires', kpi_money($tot['ca']), 'wallet', 'teal', 'Ce mois-ci : ' . money($caMois)) ?>
        <?= kpi('Commandes en cours', num($tot['encours']), 'receipt', 'info', num($tot['vet']) . ' vêtements déjà remis') ?>
        <?= kpi('Livraisons en attente', num($tot['liv']), 'truck', $tot['liv'] ? 'warning' : 'good', 'En attente d\'un livreur libre') ?>
        <?= kpi('Incidents ouverts', num($tot['inc']), 'alert', $tot['inc'] ? 'critical' : 'good', 'Réclamations, pertes, échecs') ?>
    </div>

    <div class="grid grid-main mt-3">
        <div class="card">
            <div class="card-header"><h2><?= icon('trending') ?> Encaissements des 14 derniers jours</h2><span class="chip">Toutes agences</span></div>
            <?= bar_chart($chart) ?>
        </div>
        <div class="card">
            <div class="card-header"><h2><?= icon('history') ?> Activité récente</h2><a class="btn btn-ghost btn-sm" href="<?= e(url('journal')) ?>">Journal</a></div>
            <?php if ($journal): ?>
            <ul class="timeline">
                <?php foreach ($journal as $j): ?>
                    <li><span class="tl-dot"></span><div class="tl-title"><?= e(mb_strimwidth($j['detail_action'], 0, 70, '…')) ?></div>
                        <div class="tl-sub"><?= e($j['type_action']) ?> · <?= e(full_name($j['nom_employe'], $j['prenom_employe'])) ?> · <?= e(rel_time($j['date_action'])) ?></div></li>
                <?php endforeach; ?>
            </ul>
            <?php else: echo empty_state('Aucune activité', '', 'history'); endif; ?>
        </div>
    </div>

    <div class="card card-flush mt-3">
        <div class="card-header"><h2><?= icon('store') ?> Performance par agence</h2><a class="btn btn-ghost btn-sm" href="<?= e(url('agences')) ?>">Gérer les agences</a></div>
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Agence</th><th class="num">Chiffre d'affaires</th><th class="num">En cours</th><th class="num">Vêtements remis</th>
                <th class="num">Livraisons effectuées</th><th class="num">En attente</th><th class="num">Incidents</th></tr></thead>
            <tbody>
            <?php foreach ($stats as $s): ?>
                <tr class="clickable" data-href="<?= e(url('agence', ['id' => $s['id_agence']])) ?>">
                    <td><div class="cell-person"><span class="agency-logo" style="width:34px;height:34px;font-size:13px;border-radius:10px"><?= e(mb_substr($s['nom_agence'], 0, 2)) ?></span><span class="cell-main"><?= e($s['nom_agence']) ?></span></div></td>
                    <td class="num strong"><?= money($s['chiffre_affaires']) ?></td>
                    <td class="num"><?= num($s['commandes_en_cours']) ?></td>
                    <td class="num"><?= num($s['vetements_traites']) ?></td>
                    <td class="num"><?= num($s['livraisons_effectuees']) ?></td>
                    <td class="num"><?= $s['livraisons_en_attente'] ? badge((string) $s['livraisons_en_attente'], 'warning') : '0' ?></td>
                    <td class="num"><?= $s['incidents_ouverts'] ? badge((string) $s['incidents_ouverts'], 'critical') : '0' ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table></div>
        <?php if (!$stats) echo empty_state('Aucune agence', 'Créez votre première agence pour commencer.', 'store', '<a class="btn btn-primary" href="' . e(url('agence')) . '">' . icon('plus') . ' Nouvelle agence</a>'); ?>
    </div>

<?php
/* ======================================================================= GÉRANT */
elseif (is_gerant()):
    $a = my_agence();
    $stat = row('SELECT * FROM v_tableau_bord_agence WHERE id_agence = ?', [$a]);
    $jour = (float) val('SELECT COALESCE(SUM(p.montant_paiement),0) FROM paiement p JOIN commande c ON c.id_commande = p.id_commande
                          WHERE c.id_agence = ? AND DATE(p.date_paiement) = CURRENT_DATE', [$a]);
    $nbJour = (int) val('SELECT COUNT(*) FROM commande WHERE id_agence = ? AND DATE(date_commande) = CURRENT_DATE', [$a]);
    $prets = (int) val("SELECT COUNT(*) FROM commande WHERE id_agence = ? AND mode_recuperation = 'Retrait' AND statut_commande IN ('Terminée','Partiellement retirée')", [$a]);
    $col = fn(array $statuts) => rows('SELECT m.*, c.date_commande FROM v_montants_commande m JOIN commande c ON c.id_commande = m.id_commande
                 WHERE m.id_agence = ? AND m.statut_commande IN (' . implode(',', array_fill(0, count($statuts), '?')) . ')
                 ORDER BY c.date_commande DESC LIMIT 6', array_merge([$a], $statuts));
    $colonnes = [
        ['À encaisser', 'wallet', 'neutral', $col(['Enregistrée'])],
        ['À traiter', 'droplet', 'violet', $col(['Payée', 'En traitement'])],
        ['Prêtes', 'check-circle', 'teal', $col(['Terminée', 'Partiellement retirée', 'En attente de livreur', 'En livraison'])],
    ];
    $retards = rows('SELECT * FROM v_frais_retard WHERE id_agence = ? ORDER BY fin_delai_grace LIMIT 5', [$a]);
    $chart = encaissements_par_jour(14, $a);
?>
    <div class="hero mb-2">
        <div class="hero-row">
            <div>
                <h1><?= e($salut) ?>, <?= e($prenom) ?></h1>
                <p>Agence <?= e($u['agence']) ?> · <?= $nbJour ?> dépôt<?= $nbJour > 1 ? 's' : '' ?> enregistré<?= $nbJour > 1 ? 's' : '' ?> aujourd'hui.</p>
            </div>
            <div class="row-wrap">
                <a class="btn btn-secondary" href="<?= e(url('clients')) ?>"><?= icon('user') ?> Clients</a>
                <a class="btn btn-primary btn-lg" href="<?= e(url('commande-nouvelle')) ?>"><?= icon('plus') ?> Nouveau dépôt</a>
            </div>
        </div>
    </div>

    <div class="grid grid-4">
        <?= kpi('Encaissé aujourd\'hui', kpi_money($jour), 'wallet', 'teal', 'Total agence : ' . money($stat['chiffre_affaires'] ?? 0)) ?>
        <?= kpi('Commandes en cours', num($stat['commandes_en_cours'] ?? 0), 'receipt', 'info', 'Hors retirées, livrées, annulées') ?>
        <?= kpi('Prêtes au retrait', num($prets), 'check-circle', 'good', 'Clients avisés par WhatsApp') ?>
        <?= kpi('Livraisons en attente', num($stat['livraisons_en_attente'] ?? 0), 'truck', ($stat['livraisons_en_attente'] ?? 0) ? 'warning' : 'neutral', num($stat['livraisons_effectuees'] ?? 0) . ' livraisons effectuées') ?>
    </div>

    <div class="grid grid-3 mt-3">
        <?php foreach ($colonnes as [$titre, $ic, $tone, $list]): ?>
            <div class="card">
                <div class="card-header"><h3><span class="kpi-icon tone-<?= $tone ?>" style="width:30px;height:30px;border-radius:9px"><?= icon($ic, 16) ?></span><?= e($titre) ?></h3><span class="chip"><?= count($list) ?></span></div>
                <?php if ($list): ?>
                <div class="list">
                    <?php foreach ($list as $c): ?>
                        <a class="list-item" href="<?= e(url('commande', ['id' => $c['id_commande']])) ?>">
                            <div class="grow"><div class="cell-main"><?= e($c['client']) ?></div>
                                <div class="cell-sub"><span class="mono"><?= e($c['numero_commande']) ?></span> · <?= e(rel_time($c['date_commande'])) ?></div></div>
                            <div class="right"><div class="strong tnum"><?= money($c['montant_total']) ?></div><?= badge($c['statut_commande']) ?></div>
                        </a>
                    <?php endforeach; ?>
                </div>
                <?php else: echo empty_state('Rien pour le moment', '', $ic); endif; ?>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="grid grid-main mt-3">
        <div class="card">
            <div class="card-header"><h2><?= icon('trending') ?> Encaissements des 14 derniers jours</h2><span class="chip">Agence <?= e($u['agence']) ?></span></div>
            <?= bar_chart($chart) ?>
        </div>
        <div class="card">
            <div class="card-header"><h2><?= icon('clock') ?> Retards de retrait</h2><a class="btn btn-ghost btn-sm" href="<?= e(url('retards')) ?>">Tout voir</a></div>
            <?php if ($retards): ?>
                <div class="list"><?php foreach ($retards as $r): ?>
                    <a class="list-item" href="<?= e(url('commande', ['id' => $r['id_commande']])) ?>">
                        <span class="kpi-icon tone-warning" style="width:34px;height:34px"><?= icon('clock', 16) ?></span>
                        <div class="grow"><div class="cell-main mono"><?= e($r['numero_commande']) ?></div><div class="cell-sub"><?= $r['vetements_restants'] ?> vêtement(s) en attente</div></div>
                        <div class="strong tnum"><?= money($r['frais_retard_dus']) ?></div>
                    </a>
                <?php endforeach; ?></div>
            <?php else: echo empty_state('Aucun retard', 'Tous les vêtements prêts sont dans le délai de grâce.', 'check-circle'); endif; ?>
        </div>
    </div>

<?php
/* ======================================================================= LIVREUR */
else:
    $me = my_id();
    $s = row("SELECT SUM(statut_livraison = 'Livrée') livrees,
                     SUM(statut_livraison = 'Livrée' AND date_livraison >= DATE_FORMAT(CURRENT_DATE, '%Y-%m-01')) mois,
                     SUM(statut_livraison IN ('Assignée','En cours')) en_cours,
                     COALESCE(SUM(nb_tentatives), 0) echecs
                FROM livraison WHERE id_employe = ?", [$me]);
    $dispo = val('SELECT disponibilite_livreur FROM employe WHERE id_employe = ?', [$me]);
    $hist = rows("SELECT l.*, c.numero_commande, CONCAT(cl.nom_client, ' ', COALESCE(cl.prenom_client,'')) client
                    FROM livraison l JOIN commande c ON c.id_commande = l.id_commande JOIN client cl ON cl.id_client = c.id_client
                   WHERE l.id_employe = ? ORDER BY COALESCE(l.date_livraison, l.date_assignation) DESC LIMIT 10", [$me]);
?>
    <?= page_header('Mon activité', 'Disponibilité actuelle : ' . badge($dispo), '<a class="btn btn-primary" href="' . e(url('tournee')) . '">' . icon('truck') . ' Ma tournée</a>') ?>
    <div class="grid grid-4">
        <?= kpi('Livraisons en cours', num($s['en_cours'] ?? 0), 'truck', 'info') ?>
        <?= kpi('Livrées ce mois-ci', num($s['mois'] ?? 0), 'check-circle', 'good') ?>
        <?= kpi('Total livrées', num($s['livrees'] ?? 0), 'package', 'teal') ?>
        <?= kpi('Tentatives échouées', num($s['echecs'] ?? 0), 'alert', ($s['echecs'] ?? 0) ? 'warning' : 'neutral') ?>
    </div>
    <div class="card card-flush mt-3">
        <div class="card-header"><h2><?= icon('history') ?> Mes dernières livraisons</h2></div>
        <?php if ($hist): ?>
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Commande</th><th>Client</th><th class="hide-sm">Adresse</th><th>Statut</th><th>Date</th></tr></thead>
            <tbody><?php foreach ($hist as $l): ?>
                <tr><td><span class="ref"><?= e($l['numero_commande']) ?></span></td><td class="cell-main"><?= e($l['client']) ?></td>
                    <td class="hide-sm text-2"><?= e($l['adresse_livraison']) ?></td><td><?= badge($l['statut_livraison']) ?></td>
                    <td class="text-2 nowrap"><?= e(dt($l['date_livraison'] ?? $l['date_assignation'])) ?></td></tr>
            <?php endforeach; ?></tbody>
        </table></div>
        <?php else: echo empty_state('Aucune livraison pour le moment', 'Les livraisons qui vous sont affectées apparaîtront ici.', 'truck'); endif; ?>
    </div>
<?php endif; ?>
