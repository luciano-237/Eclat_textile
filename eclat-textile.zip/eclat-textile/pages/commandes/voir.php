<?php
/** Fiche commande : composition du dépôt, montants, paiements, cycle de vie, remise. */
$id = (int) get('id');
$c = load_commande($id);
if (!$c) {
    flash('error', 'Commande introuvable.');
    redirect('commandes');
}
$title = 'Commande ' . $c['numero_commande'];
$st = $c['statut_commande'];
$canEdit = is_gerant();
$enregistree = $st === 'Enregistrée';

$vets = rows('SELECT v.*, a.libelle_article, ca.libelle_categorie, r.date_retrait, r.nom_retirant
                FROM vetement v JOIN article a ON a.id_article = v.id_article JOIN categorie_article ca ON ca.id_categorie = a.id_categorie
                LEFT JOIN retrait r ON r.id_retrait = v.id_retrait
               WHERE v.id_commande = ? ORDER BY v.id_vetement', [$id]);
$supps = rows('SELECT sa.*, s.libelle_supplement, s.portee_supplement, v.code_etiquette, a.libelle_article
                 FROM supplement_applique sa JOIN supplement s ON s.id_supplement = sa.id_supplement
                 LEFT JOIN vetement v ON v.id_vetement = sa.id_vetement LEFT JOIN article a ON a.id_article = v.id_article
                WHERE sa.id_commande = ? ORDER BY sa.id_supp_applique', [$id]);
$paiements = rows('SELECT p.*, e.nom_employe, e.prenom_employe FROM paiement p JOIN employe e ON e.id_employe = p.id_employe
                    WHERE p.id_commande = ? ORDER BY p.date_paiement', [$id]);
$factures = rows('SELECT * FROM facture WHERE id_commande = ? ORDER BY date_facture', [$id]);
$code = row("SELECT * FROM code_validation WHERE id_commande = ? AND statut_code = 'Actif'", [$id]);
$livraison = row('SELECT l.*, e.nom_employe, e.prenom_employe, e.telephone_employe FROM livraison l
                   LEFT JOIN employe e ON e.id_employe = l.id_employe WHERE l.id_commande = ?', [$id]);
$preuves = $livraison ? rows('SELECT * FROM preuve_livraison WHERE id_livraison = ?', [$livraison['id_livraison']]) : [];
$retraits = rows('SELECT r.*, (SELECT COUNT(*) FROM vetement v WHERE v.id_retrait = r.id_retrait) nb FROM retrait r WHERE r.id_commande = ? ORDER BY r.date_retrait', [$id]);
$incidents = rows('SELECT * FROM incident WHERE id_commande = ? ORDER BY date_incident DESC', [$id]);
$lot = row('SELECT * FROM v_lot_poids WHERE id_commande = ?', [$id]);
$fraisRetard = in_array($st, ['Terminée', 'Partiellement retirée'], true) ? (float) val('SELECT fn_frais_retard(?, FALSE)', [$id]) : 0;

// Catalogue de l'agence (pour l'ajout de vêtements et de suppléments)
$articles = $enregistree && $canEdit ? rows('SELECT a.id_article, a.libelle_article, ca.libelle_categorie, t.prix_categorie, t.unite_facturation
                   FROM article a JOIN categorie_article ca ON ca.id_categorie = a.id_categorie
                   JOIN tarif_categorie t ON t.id_categorie = ca.id_categorie AND t.id_agence = ? AND t.actif_tarif = TRUE
                  ORDER BY ca.libelle_categorie, a.libelle_article', [$c['id_agence']]) : [];
$catalogueSupp = $enregistree && $canEdit ? rows("SELECT s.*, ts.prix_supplement FROM supplement s
                   JOIN tarif_supplement ts ON ts.id_supplement = s.id_supplement AND ts.id_agence = ? AND ts.actif_supplement = TRUE
                  WHERE s.libelle_supplement <> 'Livraison à domicile' ORDER BY s.portee_supplement DESC, s.libelle_supplement", [$c['id_agence']]) : [];

$nbAcceptes = count(array_filter($vets, fn($v) => $v['statut_vetement'] !== 'Refusé'));
$nbEnTraitement = count(array_filter($vets, fn($v) => $v['statut_vetement'] === 'En traitement'));
$nbPrets = count(array_filter($vets, fn($v) => $v['statut_vetement'] === 'Prêt'));

/* ------------------------------------------------ Actions de l'en-tête */
$form = function (string $action, string $label, string $icon, string $class, array $extra = [], string $confirm = '') use ($id) {
    $h = '<form method="post" action="' . e(url('commande-action')) . '"' . ($confirm ? ' data-confirm="' . e($confirm) . '"' : '') . '>' . csrf_field()
        . '<input type="hidden" name="id_commande" value="' . $id . '"><input type="hidden" name="action" value="' . e($action) . '">';
    foreach ($extra as $k => $v) $h .= '<input type="hidden" name="' . e($k) . '" value="' . e($v) . '">';
    return $h . '<button class="btn ' . $class . '" type="submit">' . icon($icon) . ' ' . e($label) . '</button></form>';
};
$actions = '';
if ($code || $factures) {
    $actions .= '<a class="btn btn-secondary" target="_blank" href="' . e(url('ticket', ['id' => $id])) . '">' . icon('printer') . ' Ticket</a>';
}
if ($canEdit) {
    if (in_array($st, ['Enregistrée', 'Payée'], true)) {
        $actions .= $form('statut', 'Annuler', 'ban', 'btn-ghost', ['statut' => 'Annulée'], 'Annuler définitivement la commande ' . $c['numero_commande'] . ' ?');
    }
    if ($st !== 'Annulée' && $st !== 'Enregistrée') {
        $actions .= '<a class="btn btn-ghost" href="' . e(url('incident-nouveau', ['commande' => $id])) . '">' . icon('alert') . ' Incident</a>';
    }
    if ($enregistree) {
        $actions .= '<button class="btn btn-primary" data-open="dlgPaiement"' . ($nbAcceptes ? '' : ' disabled') . '>' . icon('wallet') . ' Encaisser</button>';
    } elseif ($st === 'Payée') {
        $actions .= $form('statut', 'Démarrer le traitement', 'play', 'btn-primary', ['statut' => 'En traitement']);
    } elseif ($st === 'En traitement') {
        $actions .= $form('statut', 'Terminer la commande', 'check-circle', 'btn-primary', ['statut' => 'Terminée'],
            $nbEnTraitement ? '' : '');
    } elseif (in_array($st, ['Terminée', 'Partiellement retirée'], true) && $c['mode_recuperation'] === 'Retrait') {
        $actions .= '<a class="btn btn-primary" href="' . e(url('retrait', ['id' => $id])) . '">' . icon('package') . ' Remettre au client</a>';
    }
}

/* ------------------------------------------------ Cycle de vie */
$etapes = $c['mode_recuperation'] === 'Retrait'
    ? ['Enregistrée', 'Payée', 'En traitement', 'Terminée', 'Retirée']
    : ['Enregistrée', 'Payée', 'En traitement', 'Terminée', 'En livraison', 'Livrée'];
$position = [
    'Enregistrée' => 0, 'Payée' => 1, 'En traitement' => 2, 'Terminée' => 3,
    'Partiellement retirée' => 3, 'Retirée' => 4, 'En attente de livreur' => 3, 'En livraison' => 4, 'Livrée' => 5,
][$st] ?? -1;
$derniere = count($etapes) - 1;

$sub = '<span class="row-wrap" style="gap:8px">' . badge($st)
    . ($c['type_service'] === 'Express' ? '<span class="chip" style="color:var(--warning)">' . icon('zap', 13) . ' Express</span>' : '<span class="chip">Service normal</span>')
    . '<span class="chip">' . icon($c['mode_recuperation'] === 'Livraison' ? 'truck' : 'store', 13) . ' ' . ($c['mode_recuperation'] === 'Livraison' ? 'Livraison à domicile' : 'Retrait en agence') . '</span>'
    . '<span class="muted small">Déposée le ' . e(dt($c['date_commande'])) . ' · ' . e($c['nom_agence']) . '</span></span>';
echo page_header('Commande ' . $c['numero_commande'], $sub, $actions, url('commandes'));
?>

<div class="card mb-2">
    <div class="stepper">
        <?php foreach ($etapes as $i => $e):
            if ($st === 'Annulée') {
                $cls = '';
            } elseif ($i < $position || ($i === $position && $i === $derniere)) {
                $cls = 'done';
            } else {
                $cls = $i === $position ? 'current' : '';
            }
            $label = $e;
            if ($e === 'Terminée' && $st === 'Partiellement retirée') $label = 'Partiellement retirée';
            if ($e === 'Terminée' && $st === 'En attente de livreur') $label = 'En attente de livreur'; ?>
            <div class="step <?= $cls ?>">
                <span class="step-dot"><?= $cls === 'done' ? icon('check', 15) : ($i + 1) ?></span>
                <span class="step-label"><?= e($label) ?></span>
            </div>
        <?php endforeach; ?>
        <?php if ($st === 'Annulée'): ?>
            <div class="step cancelled current"><span class="step-dot"><?= icon('x', 15) ?></span><span class="step-label">Annulée</span></div>
        <?php endif; ?>
    </div>
</div>

<?php if ($enregistree && $canEdit): ?>
    <div class="alert alert-info mb-2"><?= icon('scale') ?><div><strong>Composition du dépôt</strong>
        Pesez et décrivez chaque vêtement, ajoutez les suppléments, puis encaissez. Le tri pièce / poids est automatique selon la catégorie (RG27).</div></div>
<?php endif; ?>
<?php if ($fraisRetard > 0): ?>
    <div class="alert alert-warning mb-2"><?= icon('clock') ?><div><strong>Retrait en retard</strong>
        Frais de retard dus : <?= money($fraisRetard) ?> (<?= money($c['frais_retard_applique']) ?> par jour et par vêtement au-delà du délai de grâce). Ils seront réglés au retrait.</div></div>
<?php endif; ?>

<div class="grid grid-main-wide">
    <div class="stack">
        <!-- Vêtements -->
        <div class="card">
            <div class="card-header">
                <h2><?= icon('shirt') ?> Vêtements <span class="chip"><?= $nbAcceptes ?> accepté<?= $nbAcceptes > 1 ? 's' : '' ?></span></h2>
                <div class="row-wrap">
                    <?php if ($canEdit && $st === 'En traitement' && $nbEnTraitement): ?>
                        <?= $form('vetement_pret', 'Tout marquer prêt', 'check', 'btn-secondary btn-sm', ['id_vetement' => 'tous']) ?>
                    <?php endif; ?>
                    <?php if ($canEdit && $enregistree): ?>
                        <button class="btn btn-primary btn-sm" data-open="dlgVetement"><?= icon('plus', 15) ?> Ajouter un vêtement</button>
                    <?php endif; ?>
                </div>
            </div>
            <?php if ($st === 'En traitement' && $nbAcceptes): ?>
                <div style="padding:14px 20px 0">
                    <div class="row between small"><span class="text-2">Avancement de l'atelier</span><span class="strong"><?= $nbPrets ?> / <?= $nbAcceptes ?> prêts</span></div>
                    <div class="progress mt-1"><span style="width:<?= $nbAcceptes ? round($nbPrets / $nbAcceptes * 100) : 0 ?>%"></span></div>
                </div>
            <?php endif; ?>
            <?php if ($vets): ?>
            <div class="garments">
                <?php foreach ($vets as $v):
                    $refused = $v['statut_vetement'] === 'Refusé'; ?>
                    <div class="garment<?= $refused ? ' is-refused' : '' ?>">
                        <div class="garment-top">
                            <span class="garment-icon"><?= icon('shirt', 18) ?></span>
                            <div class="grow">
                                <div class="cell-main"><?= e($v['libelle_article']) ?></div>
                                <div class="cell-sub mono"><?= e($v['code_etiquette']) ?></div>
                            </div>
                            <?= badge($v['statut_vetement']) ?>
                        </div>
                        <div class="garment-meta">
                            <span class="chip"><?= icon('scale', 13) ?> <?= num($v['poids_kg'], 2) ?> kg</span>
                            <span class="chip"><?= e($v['libelle_categorie']) ?></span>
                            <?php if (!$refused): ?>
                                <span class="chip"><?= $v['prix_applique'] !== null ? money($v['prix_applique']) : 'Lot au poids' ?></span>
                            <?php endif; ?>
                            <?php if ($v['majoration_speciale'] > 0): ?><span class="chip" style="color:var(--violet)">+<?= money($v['majoration_speciale']) ?> spécial</span><?php endif; ?>
                        </div>
                        <div class="small text-2"><?= e($v['etat_initial']) ?><?= $v['anomalies'] ? ' · <span style="color:var(--warning)">' . e($v['anomalies']) . '</span>' : '' ?></div>
                        <?php if ($refused): ?><div class="small" style="color:var(--critical)">Refus : <?= e($v['motif_refus']) ?></div><?php endif; ?>
                        <?php if ($v['id_retrait']): ?><div class="small muted">Remis le <?= e(dt($v['date_retrait'])) ?> à <?= e($v['nom_retirant']) ?></div><?php endif; ?>
                        <?php if ($canEdit && ($enregistree && !$refused || $v['statut_vetement'] === 'En traitement')): ?>
                        <div class="garment-foot">
                            <?php if ($enregistree): ?>
                                <button class="btn btn-ghost btn-sm" data-open="dlgRefus" data-fill='<?= e(json_encode(['id_vetement' => $v['id_vetement'], 'vet_label' => $v['libelle_article'] . ' · ' . $v['code_etiquette']])) ?>'><?= icon('ban', 14) ?> Refuser</button>
                            <?php else: ?>
                                <span></span><?= $form('vetement_pret', 'Prêt', 'check', 'btn-secondary btn-sm', ['id_vetement' => $v['id_vetement']]) ?>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
            <?php if ($lot && $lot['nb_vetements_lot'] > 0): ?>
                <div class="card-footer small text-2 row" style="gap:8px"><?= icon('scale', 15) ?>
                    Lot au poids : <?= (int) $lot['nb_vetements_lot'] ?> vêtement(s), <strong><?= num($lot['poids_lot_kg'], 2) ?> kg</strong> —
                    <?= $lot['mode_facturation_lot'] === 'Poids'
                        ? 'facturé au poids (' . money($c['tarif_kg_applique']) . '/kg, seuil ' . num($c['seuil_poids_applique'], 1) . ' kg atteint)'
                        : 'sous le seuil de ' . num($c['seuil_poids_applique'], 1) . ' kg : facturé ' . money($c['prix_hors_cat_applique']) . ' la pièce (RG29)' ?>
                </div>
            <?php endif; ?>
            <?php else: ?>
                <?= empty_state('Aucun vêtement', 'Ajoutez les vêtements déposés par le client : chacun est pesé et reçoit une étiquette.', 'shirt',
                    $canEdit && $enregistree ? '<button class="btn btn-primary" data-open="dlgVetement">' . icon('plus') . ' Ajouter un vêtement</button>' : '') ?>
            <?php endif; ?>
        </div>

        <!-- Suppléments -->
        <div class="card">
            <div class="card-header"><h2><?= icon('sparkles') ?> Suppléments</h2>
                <?php if ($canEdit && $enregistree && $catalogueSupp): ?><button class="btn btn-secondary btn-sm" data-open="dlgSupp"><?= icon('plus', 15) ?> Ajouter</button><?php endif; ?></div>
            <?php if ($supps): ?>
                <div class="table-wrap"><table class="table">
                    <thead><tr><th>Supplément</th><th>Concerne</th><th class="num">Prix</th><th class="num">Qté</th><th class="num">Total</th></tr></thead>
                    <tbody><?php foreach ($supps as $s): ?>
                        <tr><td class="cell-main"><?= e($s['libelle_supplement']) ?></td>
                            <td class="text-2"><?= $s['id_vetement'] ? e($s['libelle_article']) . ' <span class="muted mono small">' . e($s['code_etiquette']) . '</span>' : 'Toute la commande' ?></td>
                            <td class="num"><?= money($s['prix_supp_applique']) ?></td><td class="num"><?= (int) $s['quantite_supp'] ?></td>
                            <td class="num strong"><?= money($s['prix_supp_applique'] * $s['quantite_supp']) ?></td></tr>
                    <?php endforeach; ?></tbody>
                </table></div>
            <?php else: ?>
                <div class="card-body muted small">Aucun supplément (repassage, blanchissage, détachage…).</div>
            <?php endif; ?>
        </div>

        <!-- Paiements -->
        <div class="card">
            <div class="card-header"><h2><?= icon('wallet') ?> Paiements</h2>
                <?php if ($canEdit && $enregistree && $nbAcceptes): ?><button class="btn btn-secondary btn-sm" data-open="dlgPaiement"><?= icon('plus', 15) ?> Encaisser</button><?php endif; ?></div>
            <?php if ($paiements): ?>
                <div class="table-wrap"><table class="table">
                    <thead><tr><th>Date</th><th>Objet</th><th>Mode</th><th>Référence</th><th>Encaissé par</th><th class="num">Montant</th></tr></thead>
                    <tbody><?php foreach ($paiements as $p): ?>
                        <tr><td class="nowrap text-2"><?= e(dt($p['date_paiement'])) ?></td>
                            <td><?= badge($p['objet_paiement'], $p['objet_paiement'] === 'Commande' ? 'teal' : 'warning') ?></td>
                            <td><?= e($p['mode_paiement']) ?></td><td class="mono small"><?= e($p['reference_paiement'] ?? '—') ?></td>
                            <td class="text-2"><?= e(full_name($p['nom_employe'], $p['prenom_employe'])) ?></td>
                            <td class="num strong"><?= money($p['montant_paiement']) ?></td></tr>
                    <?php endforeach; ?></tbody>
                </table></div>
            <?php else: ?>
                <div class="card-body muted small">Aucun paiement. Le traitement ne commence qu'après le paiement intégral (RG50).</div>
            <?php endif; ?>
        </div>

        <?php if ($retraits || $incidents): ?>
        <div class="grid grid-2">
            <?php if ($retraits): ?>
            <div class="card"><div class="card-header"><h3><?= icon('package') ?> Retraits</h3></div>
                <ul class="timeline"><?php foreach ($retraits as $r): ?>
                    <li><span class="tl-dot"></span><div class="tl-title"><?= e($r['nom_retirant']) ?> · <?= (int) $r['nb'] ?> vêtement(s)</div>
                        <div class="tl-sub"><?= e(dt($r['date_retrait'])) ?> · <?= e($r['mode_verification']) ?><?= $r['est_client'] ? '' : ' · mandataire (' . e($r['type_piece_identite']) . ')' ?></div></li>
                <?php endforeach; ?></ul></div>
            <?php endif; ?>
            <?php if ($incidents): ?>
            <div class="card"><div class="card-header"><h3><?= icon('alert') ?> Incidents</h3></div>
                <div class="list"><?php foreach ($incidents as $i): ?>
                    <a class="list-item" href="<?= e(url('incident', ['id' => $i['id_incident']])) ?>"><div class="grow"><div class="cell-main"><?= e($i['type_incident']) ?></div>
                        <div class="cell-sub"><?= e($i['motif_incident']) ?></div></div><?= badge($i['statut_incident']) ?></a>
                <?php endforeach; ?></div></div>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>

    <!-- Colonne de droite -->
    <div class="stack">
        <div class="card">
            <div class="card-header"><h2><?= icon('receipt') ?> Montant</h2>
                <?php if ($c['reste_a_payer'] <= 0 && $c['montant_total'] > 0 && $st !== 'Annulée'): ?><?= badge('Payée', 'good') ?><?php endif; ?></div>
            <div class="card-body">
                <div class="totals">
                    <div class="line"><span>Vêtements</span><span><?= money($c['montant_vetements']) ?></span></div>
                    <?php if ($c['montant_majoration'] > 0): ?><div class="line"><span>Majoration express (<?= num($c['taux_majoration_applique'], 0) ?> %)</span><span><?= money($c['montant_majoration']) ?></span></div><?php endif; ?>
                    <div class="line"><span>Suppléments</span><span><?= money($c['montant_supplements']) ?></span></div>
                    <?php if ($c['taux_remise'] > 0):
                        $sousTotal = $c['montant_vetements'] + $c['montant_majoration'] + $c['montant_supplements']; ?>
                        <div class="line discount"><span><?= icon('gift', 14) ?> Fidélité (<?= num($c['taux_remise'], 0) ?> %)</span><span>− <?= money($sousTotal - $c['montant_total']) ?></span></div>
                    <?php endif; ?>
                    <div class="total"><span>Total</span><span><?= money($c['montant_total']) ?></span></div>
                    <?php if ($c['montant_paye'] > 0): ?>
                        <div class="line"><span>Déjà payé</span><span><?= money($c['montant_paye']) ?></span></div>
                    <?php endif; ?>
                    <?php if ($c['reste_a_payer'] > 0 && $st !== 'Annulée'): ?>
                        <div class="line" style="font-weight:700"><span style="color:var(--warning)">Reste à payer</span><span style="color:var(--warning)"><?= money($c['reste_a_payer']) ?></span></div>
                    <?php endif; ?>
                </div>
                <?php if ($canEdit && $enregistree): ?>
                    <button class="btn btn-primary btn-block mt-2" data-open="dlgPaiement"<?= $nbAcceptes ? '' : ' disabled' ?>><?= icon('wallet') ?> Encaisser <?= $nbAcceptes ? money($c['reste_a_payer']) : '' ?></button>
                <?php endif; ?>
            </div>
        </div>

        <div class="card">
            <div class="card-header"><h3><?= icon('user') ?> Client</h3><a class="btn btn-ghost btn-sm" href="<?= e(url('client', ['id' => $c['id_client']])) ?>">Fiche</a></div>
            <div class="card-body">
                <div class="row" style="gap:12px">
                    <span class="avatar"><?= e(initials($c['nom_client'], $c['prenom_client'])) ?></span>
                    <div><div class="cell-main"><?= e(full_name($c['nom_client'], $c['prenom_client'])) ?></div>
                        <div class="cell-sub"><?= e($c['telephone_client']) ?></div></div>
                </div>
                <?php if ($c['adresse_client']): ?><div class="small text-2 row mt-2" style="gap:6px;align-items:flex-start"><?= icon('pin', 14) ?> <?= e($c['adresse_client']) ?></div><?php endif; ?>
            </div>
        </div>

        <div class="card">
            <div class="card-header"><h3><?= icon('clock') ?> Délais</h3>
                <?php if ($canEdit && $enregistree): ?>
                    <form method="post" action="<?= e(url('commande-action')) ?>" class="row" style="gap:6px"><?= csrf_field() ?>
                        <input type="hidden" name="id_commande" value="<?= $id ?>"><input type="hidden" name="action" value="changer_service">
                        <input type="hidden" name="type_service" value="<?= $c['type_service'] === 'Express' ? 'Normal' : 'Express' ?>">
                        <button class="btn btn-ghost btn-sm" type="submit"><?= icon('refresh', 14) ?> Passer en <?= $c['type_service'] === 'Express' ? 'normal' : 'express' ?></button></form>
                <?php endif; ?></div>
            <div class="card-body">
                <dl class="dl">
                    <dt>Durée de traitement</dt><dd><?= (int) $c['duree_appliquee_h'] ?> h</dd>
                    <dt>Paiement intégral</dt><dd><?= e(dt($c['date_paiement_integral'])) ?></dd>
                    <dt>Retrait prévu</dt><dd><?= e(dt($c['date_retrait_prevue'])) ?></dd>
                    <?php if ($c['mode_recuperation'] === 'Retrait'): ?><dt>Délai de grâce</dt><dd><?= (int) $c['delai_grace_applique'] ?> jours</dd><?php endif; ?>
                    <dt><?= $c['mode_recuperation'] === 'Retrait' ? 'Retrait effectif' : 'Livrée le' ?></dt><dd><?= e(dt($c['date_retrait_effective'])) ?></dd>
                    <dt>Enregistrée par</dt><dd><?= e(full_name($c['nom_employe'], $c['prenom_employe'])) ?></dd>
                </dl>
            </div>
        </div>

        <?php if ($code): ?>
        <div class="card">
            <div class="card-header"><h3><?= icon('qr') ?> Code de validation</h3><?= badge($code['statut_code']) ?></div>
            <div class="card-body">
                <div class="code-box"><span class="code-digits masked" id="codeDigits"><?= e($code['code_numerique']) ?></span>
                    <button class="btn btn-ghost btn-sm" data-reveal="codeDigits"><?= icon('eye', 15) ?> Afficher</button></div>
                <p class="small muted mt-1">Envoyé au client le <?= e(dt($code['date_generation'])) ?>. Il le présente au retrait ou au livreur.</p>
                <?php if ($canEdit): ?>
                    <form method="post" action="<?= e(url('commande-action')) ?>" class="mt-2" data-confirm="Générer un nouveau code ? L'ancien ne fonctionnera plus."><?= csrf_field() ?>
                        <input type="hidden" name="id_commande" value="<?= $id ?>"><input type="hidden" name="action" value="regenerer_code">
                        <button class="btn btn-secondary btn-sm btn-block" type="submit"><?= icon('refresh', 15) ?> Code perdu : régénérer</button></form>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>

        <?php if ($livraison): ?>
        <div class="card">
            <div class="card-header"><h3><?= icon('truck') ?> Livraison</h3><?= badge($livraison['statut_livraison']) ?></div>
            <div class="card-body stack-sm">
                <div class="small text-2 row" style="gap:6px;align-items:flex-start"><?= icon('pin', 14) ?> <?= e($livraison['adresse_livraison']) ?></div>
                <?php if ($livraison['id_employe']): ?>
                    <div class="row mt-1" style="gap:10px"><span class="avatar avatar-soft" style="width:32px;height:32px"><?= e(initials($livraison['nom_employe'], $livraison['prenom_employe'])) ?></span>
                        <div><div class="cell-main"><?= e(full_name($livraison['nom_employe'], $livraison['prenom_employe'])) ?></div><div class="cell-sub"><?= e($livraison['telephone_employe']) ?></div></div></div>
                <?php else: ?>
                    <div class="small" style="color:var(--warning)">En attente d'un livreur libre (premier arrivé, premier servi).</div>
                <?php endif; ?>
                <?php if ($livraison['nb_tentatives'] > 0): ?><div class="small muted"><?= (int) $livraison['nb_tentatives'] ?> tentative(s) échouée(s)<?= $livraison['motif_echec'] ? ' — ' . e($livraison['motif_echec']) : '' ?></div><?php endif; ?>
                <?php if ($livraison['date_livraison']): ?><div class="small muted">Livrée le <?= e(dt($livraison['date_livraison'])) ?> (<?= e($livraison['mode_validation']) ?>)</div><?php endif; ?>
                <?php if ($preuves): ?><div class="row-wrap mt-1"><?php foreach ($preuves as $p): ?><a href="<?= e($p['url_photo']) ?>" target="_blank"><img class="photo-thumb" src="<?= e($p['url_photo']) ?>" alt="Preuve de livraison"></a><?php endforeach; ?></div><?php endif; ?>
                <a class="btn btn-ghost btn-sm mt-1" href="<?= e(url('livraisons')) ?>">Gérer les livraisons</a>
            </div>
        </div>
        <?php endif; ?>

        <?php if ($factures): ?>
        <div class="card">
            <div class="card-header"><h3><?= icon('file') ?> Factures</h3></div>
            <div class="list"><?php foreach ($factures as $f): ?>
                <a class="list-item" target="_blank" href="<?= e(url('ticket', ['id' => $id, 'facture' => $f['id_facture']])) ?>">
                    <span class="kpi-icon tone-<?= $f['type_facture'] === 'Principale' ? 'teal' : 'warning' ?>" style="width:34px;height:34px"><?= icon('file', 16) ?></span>
                    <div class="grow"><div class="cell-main mono"><?= e($f['numero_facture']) ?></div><div class="cell-sub"><?= e($f['type_facture']) ?> · <?= e(dt($f['date_facture'], false)) ?></div></div>
                    <span class="strong tnum"><?= money($f['montant_facture']) ?></span></a>
            <?php endforeach; ?></div>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php if ($canEdit && $enregistree): ?>
<!-- Dialogue : ajout d'un vêtement -->
<dialog class="modal" id="dlgVetement" style="width:min(640px,calc(100vw - 32px))">
    <form method="post" action="<?= e(url('commande-action')) ?>">
        <?= csrf_field() ?><input type="hidden" name="id_commande" value="<?= $id ?>"><input type="hidden" name="action" value="ajouter_vetement">
        <div class="modal-header"><h3><?= icon('shirt') ?> Ajouter un vêtement</h3><button class="icon-btn" data-close aria-label="Fermer"><?= icon('x') ?></button></div>
        <div class="modal-body">
            <div class="form-grid">
                <div class="field span-2"><label class="req" for="id_article">Nature du vêtement</label>
                    <select class="select" id="id_article" name="id_article" required>
                        <option value="">Choisir…</option>
                        <?php $cur = null; foreach ($articles as $a):
                            if ($cur !== $a['libelle_categorie']) { if ($cur !== null) echo '</optgroup>'; $cur = $a['libelle_categorie'];
                                echo '<optgroup label="' . e($cur . ' — ' . ($a['unite_facturation'] === 'Pièce' ? money($a['prix_categorie']) . ' la pièce' : 'au poids')) . '">'; } ?>
                            <option value="<?= $a['id_article'] ?>"><?= e($a['libelle_article']) ?></option>
                        <?php endforeach; if ($cur !== null) echo '</optgroup>'; ?>
                    </select>
                    <?php if (!$articles): ?><span class="hint" style="color:var(--critical)">Aucune catégorie active dans cette agence : l'administrateur doit définir les tarifs.</span><?php endif; ?>
                </div>
                <div class="field"><label class="req" for="poids_kg">Poids</label>
                    <div class="input-group"><input class="input has-suffix" id="poids_kg" name="poids_kg" type="number" step="0.001" min="0.001" required placeholder="0,000"><span class="suffix">kg</span></div></div>
                <div class="field"><label for="quantite">Quantité identique</label>
                    <input class="input" id="quantite" name="quantite" type="number" min="1" max="50" value="1"><span class="hint">Une étiquette par pièce.</span></div>
                <div class="field span-2"><label class="req" for="etat_initial">État constaté au dépôt</label>
                    <input class="input" id="etat_initial" name="etat_initial" required value="Bon état" list="etats">
                    <datalist id="etats"><option value="Bon état"><option value="Usé"><option value="Délavé"><option value="Fragile"></datalist></div>
                <div class="field span-2"><label for="anomalies">Anomalies</label>
                    <input class="input" id="anomalies" name="anomalies" placeholder="Taches, déchirures, bouton manquant…"></div>
                <div class="field"><label for="majoration_speciale">Majoration spéciale</label>
                    <div class="input-group"><input class="input has-suffix" id="majoration_speciale" name="majoration_speciale" type="number" min="0" step="50" value="0"><span class="suffix">FCFA</span></div>
                    <span class="hint">Traitement particulier (RG31).</span></div>
                <div class="field" style="justify-content:center"><label class="check"><input type="checkbox" name="accord_client" value="1"> Le client accepte la majoration</label></div>
                <div class="field"><label for="code_etiquette">Code d'étiquette</label>
                    <input class="input mono" id="code_etiquette" name="code_etiquette" placeholder="Automatique"></div>
                <div class="field" style="justify-content:center"><label class="check"><input type="checkbox" name="refuse" value="1"> Vêtement refusé</label></div>
                <div class="field span-2" data-show-when="refuse=1"><label class="req" for="motif_refus">Motif du refus</label>
                    <input class="input" id="motif_refus" name="motif_refus" data-req placeholder="Ex. tissu trop abîmé, matière non traitée"></div>
            </div>
        </div>
        <div class="modal-footer"><button class="btn btn-ghost" data-close>Annuler</button><button class="btn btn-primary" type="submit"><?= icon('check') ?> Ajouter</button></div>
    </form>
</dialog>

<!-- Dialogue : refus d'un vêtement -->
<dialog class="modal" id="dlgRefus">
    <form method="post" action="<?= e(url('commande-action')) ?>">
        <?= csrf_field() ?><input type="hidden" name="id_commande" value="<?= $id ?>"><input type="hidden" name="action" value="refuser_vetement"><input type="hidden" name="id_vetement">
        <div class="modal-header"><h3><?= icon('ban') ?> Refuser le vêtement</h3><button class="icon-btn" data-close aria-label="Fermer"><?= icon('x') ?></button></div>
        <div class="modal-body stack">
            <p class="text-2"><strong data-text="vet_label"></strong> ne sera pas traité ni facturé (RG30).</p>
            <div class="field"><label class="req" for="motif_refus2">Motif</label><input class="input" id="motif_refus2" name="motif_refus" required></div>
        </div>
        <div class="modal-footer"><button class="btn btn-ghost" data-close>Annuler</button><button class="btn btn-danger" type="submit">Refuser</button></div>
    </form>
</dialog>

<!-- Dialogue : supplément -->
<dialog class="modal" id="dlgSupp">
    <form method="post" action="<?= e(url('commande-action')) ?>">
        <?= csrf_field() ?><input type="hidden" name="id_commande" value="<?= $id ?>"><input type="hidden" name="action" value="ajouter_supplement">
        <div class="modal-header"><h3><?= icon('sparkles') ?> Ajouter un supplément</h3><button class="icon-btn" data-close aria-label="Fermer"><?= icon('x') ?></button></div>
        <div class="modal-body">
            <div class="form-grid">
                <div class="field span-2"><label class="req" for="id_supplement">Supplément</label>
                    <select class="select" id="id_supplement" name="id_supplement" required>
                        <?php foreach ($catalogueSupp as $s): ?><option value="<?= $s['id_supplement'] ?>"><?= e($s['libelle_supplement']) ?> — <?= money($s['prix_supplement']) ?> (<?= $s['portee_supplement'] === 'Vêtement' ? 'par vêtement' : 'par commande' ?>)</option><?php endforeach; ?>
                    </select></div>
                <div class="field span-2"><label for="id_vetement">Vêtement concerné</label>
                    <select class="select" id="id_vetement" name="id_vetement">
                        <option value="">— Toute la commande (portée « Commande ») —</option>
                        <?php foreach ($vets as $v): if ($v['statut_vetement'] === 'Refusé') continue; ?>
                            <option value="<?= $v['id_vetement'] ?>"><?= e($v['libelle_article']) ?> · <?= e($v['code_etiquette']) ?></option>
                        <?php endforeach; ?>
                    </select><span class="hint">Repassage, blanchissage et détachage s'appliquent à un vêtement précis (RG44).</span></div>
                <div class="field"><label for="quantite_supp">Quantité</label><input class="input" id="quantite_supp" name="quantite_supp" type="number" min="1" value="1"></div>
            </div>
        </div>
        <div class="modal-footer"><button class="btn btn-ghost" data-close>Annuler</button><button class="btn btn-primary" type="submit"><?= icon('check') ?> Ajouter</button></div>
    </form>
</dialog>

<!-- Dialogue : paiement -->
<dialog class="modal" id="dlgPaiement">
    <form method="post" action="<?= e(url('commande-action')) ?>">
        <?= csrf_field() ?><input type="hidden" name="id_commande" value="<?= $id ?>"><input type="hidden" name="action" value="paiement">
        <div class="modal-header"><h3><?= icon('wallet') ?> Encaisser un paiement</h3><button class="icon-btn" data-close aria-label="Fermer"><?= icon('x') ?></button></div>
        <div class="modal-body stack">
            <div class="code-box"><span class="text-2">Reste à payer</span><span class="strong" style="font-size:22px"><?= money($c['reste_a_payer']) ?></span></div>
            <div class="field"><label class="req" for="montant">Montant reçu</label>
                <div class="input-group"><input class="input has-suffix" style="font-size:18px;font-weight:700" id="montant" name="montant" type="number" min="1" max="<?= (int) $c['reste_a_payer'] ?>" step="1" value="<?= (int) $c['reste_a_payer'] ?>" required><span class="suffix">FCFA</span></div>
                <span class="hint">Paiement en plusieurs fois possible ; le traitement démarre après le solde (RG50, RG51).</span></div>
            <div>
                <p class="label mb-2" style="margin-bottom:8px">Mode de paiement</p>
                <div class="choices" style="grid-template-columns:repeat(2,1fr)">
                    <?php foreach (MODES_PAIEMENT as $i => $m):
                        $ic = ['Espèces' => 'wallet', 'MTN Mobile Money' => 'phone', 'Orange Money' => 'phone', 'Autre' => 'more'][$m]; ?>
                        <label class="choice"><input type="radio" name="mode_paiement" value="<?= e($m) ?>"<?= $i === 0 ? ' checked' : '' ?>>
                            <span class="choice-card" style="padding:11px;align-items:center"><span class="choice-icon" style="width:30px;height:30px"><?= icon($ic, 16) ?></span><strong><?= e($m) ?></strong></span></label>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="field" data-show-when="mode_paiement=MTN Mobile Money|Orange Money|Autre"><label class="req" for="reference">Référence de la transaction</label>
                <input class="input mono" id="reference" name="reference" data-req placeholder="Ex. MP241118.1234.A56789"><span class="hint">Fournie par l'opérateur (RG52).</span></div>
        </div>
        <div class="modal-footer"><button class="btn btn-ghost" data-close>Annuler</button><button class="btn btn-primary" type="submit"><?= icon('check') ?> Enregistrer le paiement</button></div>
    </form>
</dialog>
<?php endif; ?>
