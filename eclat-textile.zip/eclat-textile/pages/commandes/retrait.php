<?php
/**
 * Remise des vêtements en agence (RG71 à RG79) : vérification du code, retrait total ou partiel,
 * règlement préalable des frais de retard.
 */
$id = (int) get('id');
$c = load_commande($id);
if (!$c || $c['mode_recuperation'] !== 'Retrait' || !in_array($c['statut_commande'], ['Terminée', 'Partiellement retirée'], true)) {
    flash('error', 'Cette commande n\'est pas prête à être retirée en agence.');
    redirect('commande', ['id' => $id]);
}
$title = 'Retrait · ' . $c['numero_commande'];
$prets = rows("SELECT v.*, a.libelle_article FROM vetement v JOIN article a ON a.id_article = v.id_article
                WHERE v.id_commande = ? AND v.statut_vetement = 'Prêt' AND v.id_retrait IS NULL ORDER BY v.id_vetement", [$id]);
$jours = jours_retard($id);
$fraisJour = (float) $c['frais_retard_applique'];
$fraisRemis = (float) val('SELECT fn_frais_retard(?, TRUE)', [$id]);       // déjà dus pour les vêtements remis
$fraisPayes = (float) val("SELECT fn_total_paye(?, 'Frais de retard')", [$id]);
$parVetement = $jours * $fraisJour;
$nomClient = full_name($c['nom_client'], $c['prenom_client']);

if (is_post()) {
    csrf_check();
    try {
        $choisis = array_map('intval', (array) ($_POST['vetements'] ?? []));
        $idsPrets = array_map(fn($v) => (int) $v['id_vetement'], $prets);
        $choisis = array_values(array_intersect($choisis, $idsPrets));
        if (!$choisis) throw new RuntimeException('Sélectionnez au moins un vêtement à remettre.');

        $mode = (string) post('mode_verification');
        $estClient = post('est_client') === '1';
        if ($mode === 'Identité') {
            if (!post('type_piece_identite') || !post('num_piece_identite')) {
                throw new RuntimeException('Le contrôle par identité exige le type et le numéro de la pièce.');
            }
        } else {
            $reconnu = verifier_code($id, (string) post('code'));
            if ($reconnu === null) throw new RuntimeException('Code de validation incorrect ou inactif (RG58).');
            $mode = $reconnu;
        }
        if (!$estClient && (!post('type_piece_identite') || !post('num_piece_identite'))) {
            throw new RuntimeException('RG73 : un mandataire doit présenter une pièce d\'identité.');
        }
        $aPayer = max(0, $fraisRemis + count($choisis) * $parVetement - $fraisPayes);

        transaction(function () use ($id, $choisis, $mode, $estClient, $aPayer, $nomClient) {
            if ($aPayer > 0) {
                $mp = in_array(post('mode_paiement'), MODES_PAIEMENT, true) ? post('mode_paiement') : 'Espèces';
                q("INSERT INTO paiement (montant_paiement, mode_paiement, reference_paiement, objet_paiement, id_commande, id_employe)
                   VALUES (?, ?, ?, 'Frais de retard', ?, ?)", [$aPayer, $mp, $mp === 'Espèces' ? null : post('reference'), $id, my_id()]);
            }
            q('INSERT INTO retrait (nom_retirant, est_client, mode_verification, type_piece_identite, num_piece_identite, id_commande, id_employe)
               VALUES (?, ?, ?, ?, ?, ?, ?)', [
                $estClient ? $nomClient : (post('nom_retirant') ?: 'Mandataire'), $estClient ? 1 : 0, $mode,
                nullable(post('type_piece_identite')), nullable(post('num_piece_identite')), $id, my_id(),
            ]);
            $idr = (int) db()->lastInsertId();
            foreach ($choisis as $v) {
                q('UPDATE vetement SET id_retrait = ? WHERE id_vetement = ?', [$idr, $v]);
            }
        });
        $st = val('SELECT statut_commande FROM commande WHERE id_commande = ?', [$id]);
        flash('success', $st === 'Retirée' ? 'Tous les vêtements ont été remis : commande retirée.' : count($choisis) . ' vêtement(s) remis. Retrait partiel enregistré.');
        redirect('commande', ['id' => $id]);
    } catch (Throwable $ex) {
        flash('error', db_error($ex));
        redirect('retrait', ['id' => $id]);
    }
}

echo page_header('Remise au client', 'Commande <span class="ref">' . e($c['numero_commande']) . '</span> · ' . e($nomClient), '', url('commande', ['id' => $id]));
?>
<form method="post" class="grid grid-main-wide" id="formRetrait"
      data-par-vetement="<?= $parVetement ?>" data-deja="<?= $fraisRemis - $fraisPayes ?>">
    <?= csrf_field() ?>
    <div class="stack">
        <div class="card">
            <div class="card-header"><h2><?= icon('shirt') ?> Vêtements à remettre</h2>
                <label class="check small"><input type="checkbox" id="toutCocher" checked> Tout sélectionner</label></div>
            <div class="list">
                <?php foreach ($prets as $v): ?>
                    <label class="list-item" style="cursor:pointer">
                        <input type="checkbox" class="vet-check" name="vetements[]" value="<?= $v['id_vetement'] ?>" checked style="width:18px;height:18px;accent-color:var(--primary)">
                        <span class="garment-icon"><?= icon('shirt', 16) ?></span>
                        <span class="grow"><span class="cell-main"><?= e($v['libelle_article']) ?></span>
                            <span class="cell-sub mono" style="display:block"><?= e($v['code_etiquette']) ?> · <?= num($v['poids_kg'], 2) ?> kg</span></span>
                        <?php if ($parVetement > 0): ?><span class="chip" style="color:var(--warning)"><?= icon('clock', 13) ?> <?= money($parVetement) ?></span><?php endif; ?>
                    </label>
                <?php endforeach; ?>
            </div>
            <?php if (!$prets): ?><?= empty_state('Aucun vêtement prêt', 'Tous les vêtements prêts ont déjà été remis.', 'check-circle') ?><?php endif; ?>
        </div>

        <div class="card">
            <div class="card-header"><h2><?= icon('shield') ?> Vérification</h2></div>
            <div class="card-body stack">
                <div class="choices">
                    <label class="choice"><input type="radio" name="mode_verification" value="Code" checked>
                        <span class="choice-card"><span class="choice-icon"><?= icon('qr') ?></span><span><strong>Code client</strong><small>QR code scanné ou code à 6 chiffres</small></span></span></label>
                    <label class="choice"><input type="radio" name="mode_verification" value="Identité">
                        <span class="choice-card"><span class="choice-icon"><?= icon('user') ?></span><span><strong>Pièce d'identité</strong><small>Code perdu ou indisponible</small></span></span></label>
                </div>
                <div class="field" data-show-when="mode_verification=Code">
                    <label class="req" for="code">Code présenté</label>
                    <input class="input input-xl" id="code" name="code" data-req autocomplete="off" placeholder="000000" autofocus>
                    <button type="button" class="btn btn-secondary btn-block" data-qr-scan="code"><?= icon('camera', 16) ?> Scanner le QR code du client</button>
                    <span class="hint">Caméra de l'appareil, douchette USB ou saisie des 6 chiffres.</span>
                </div>
                <label class="check"><input type="checkbox" name="est_client" value="1" checked> Le client récupère lui-même ses vêtements</label>
                <div class="form-grid" data-show-when="est_client=0">
                    <div class="field span-2"><label class="req" for="nom_retirant">Nom du mandataire</label><input class="input" id="nom_retirant" name="nom_retirant" data-req></div>
                </div>
                <div class="form-grid" data-show-when="mode_verification=Identité" id="pieceA">
                    <div class="field"><label class="req">Type de pièce</label>
                        <select class="select" name="type_piece_identite" data-req><option value="">Choisir…</option><?php foreach (TYPES_PIECE as $t): ?><option><?= e($t) ?></option><?php endforeach; ?></select></div>
                    <div class="field"><label class="req">Numéro de la pièce</label><input class="input mono" name="num_piece_identite" data-req></div>
                </div>
                <div class="form-grid" data-show-when="est_client=0" id="pieceB">
                    <div class="field"><label class="req">Pièce du mandataire</label>
                        <select class="select" name="type_piece_identite_m" data-req><option value="">Choisir…</option><?php foreach (TYPES_PIECE as $t): ?><option><?= e($t) ?></option><?php endforeach; ?></select></div>
                    <div class="field"><label class="req">Numéro</label><input class="input mono" name="num_piece_identite_m" data-req></div>
                </div>
            </div>
        </div>
    </div>

    <div class="stack">
        <div class="card">
            <div class="card-header"><h2><?= icon('clock') ?> Frais de retard</h2><?= $jours > 0 ? badge($jours . ' j de retard', 'warning') : badge('Dans les délais', 'good') ?></div>
            <div class="card-body">
                <div class="totals">
                    <div class="line"><span>Disponible depuis le</span><span><?= e(dt($c['date_retrait_prevue'], false)) ?></span></div>
                    <div class="line"><span>Délai de grâce</span><span><?= (int) $c['delai_grace_applique'] ?> jours</span></div>
                    <div class="line"><span>Frais par jour et vêtement</span><span><?= money($fraisJour) ?></span></div>
                    <div class="total"><span>À régler maintenant</span><span id="aPayer"><?= money(max(0, $fraisRemis + count($prets) * $parVetement - $fraisPayes)) ?></span></div>
                </div>
                <div id="blocPaiementFrais" class="stack mt-2">
                    <div class="field"><label>Mode de paiement des frais</label>
                        <select class="select" name="mode_paiement"><?php foreach (MODES_PAIEMENT as $m): ?><option><?= e($m) ?></option><?php endforeach; ?></select></div>
                    <div class="field" data-show-when="mode_paiement=MTN Mobile Money|Orange Money|Autre"><label class="req">Référence</label><input class="input mono" name="reference" data-req></div>
                    <p class="small muted">RG77 : les frais des vêtements remis sont réglés avant la remise. Une facture de frais est émise à la clôture.</p>
                </div>
            </div>
        </div>
        <button class="btn btn-primary btn-lg btn-block" type="submit"<?= $prets ? '' : ' disabled' ?>><?= icon('package') ?> Valider la remise</button>
    </div>
</form>
<script>
(function () {
    const f = document.getElementById('formRetrait');
    const par = parseFloat(f.dataset.parVetement), deja = parseFloat(f.dataset.deja);
    const out = document.getElementById('aPayer'), bloc = document.getElementById('blocPaiementFrais');
    const fmt = n => new Intl.NumberFormat('fr-FR').format(n) + ' FCFA';
    const checks = [...f.querySelectorAll('.vet-check')];
    function maj() {
        const n = checks.filter(c => c.checked).length;
        const v = Math.max(0, deja + n * par);
        out.textContent = fmt(v);
        bloc.style.display = v > 0 ? '' : 'none';
        bloc.querySelectorAll('[name=reference]').forEach(i => { if (v <= 0) i.required = false; });
    }
    checks.forEach(c => c.addEventListener('change', maj));
    document.getElementById('toutCocher').addEventListener('change', e => { checks.forEach(c => c.checked = e.target.checked); maj(); });
    // les deux blocs de pièce d'identité alimentent les mêmes colonnes
    f.addEventListener('submit', () => {
        const m = f.querySelector('[name=type_piece_identite_m]'), n = f.querySelector('[name=num_piece_identite_m]');
        const t = f.querySelector('[name=type_piece_identite]'), u = f.querySelector('[name=num_piece_identite]');
        if (!f.querySelector('[name=est_client]').checked && !t.value) { t.value = m.value; u.value = n.value; }
    });
    maj();
})();
</script>
