<?php
/** Liste des commandes, filtrable par état, agence et recherche libre. */
$title = 'Commandes';
$q = (string) get('q', '');
$statut = (string) get('statut', '');
$agence = is_gerant() ? my_agence() : (int) get('agence', 0);

$groupes = [
    ''          => ['Toutes', []],
    'encaisser' => ['À encaisser', ['Enregistrée']],
    'atelier'   => ['À l\'atelier', ['Payée', 'En traitement']],
    'prets'     => ['Prêtes', ['Terminée', 'Partiellement retirée']],
    'livraison' => ['Livraison', ['En attente de livreur', 'En livraison']],
    'terminees' => ['Clôturées', ['Retirée', 'Livrée']],
    'annulees'  => ['Annulées', ['Annulée']],
];
if (!isset($groupes[$statut])) $statut = '';

$where = []; $params = [];
if ($agence) { $where[] = 'm.id_agence = ?'; $params[] = $agence; }
if ($q !== '') {
    $where[] = '(m.numero_commande LIKE ? OR m.client LIKE ? OR cl.telephone_client LIKE ?)';
    array_push($params, "%$q%", "%$q%", "%$q%");
}
$base = 'FROM v_montants_commande m JOIN commande c ON c.id_commande = m.id_commande JOIN client cl ON cl.id_client = m.id_client';

// compteurs par groupe (avec les filtres agence / recherche)
$counts = [];
$byStatut = [];
foreach (rows('SELECT m.statut_commande s, COUNT(*) n ' . $base . ($where ? ' WHERE ' . implode(' AND ', $where) : '') . ' GROUP BY m.statut_commande', $params) as $r) {
    $byStatut[$r['s']] = (int) $r['n'];
}
foreach ($groupes as $k => [, $sts]) {
    $counts[$k] = $k === '' ? array_sum($byStatut) : array_sum(array_intersect_key($byStatut, array_flip($sts)));
}

if ($statut !== '') {
    $sts = $groupes[$statut][1];
    $where[] = 'm.statut_commande IN (' . implode(',', array_fill(0, count($sts), '?')) . ')';
    $params = array_merge($params, $sts);
}
$w = $where ? ' WHERE ' . implode(' AND ', $where) : '';
$pg = paginate((int) val('SELECT COUNT(*) ' . $base . $w, $params), 20);
$list = rows('SELECT m.*, c.date_commande, cl.telephone_client, a.nom_agence,
                     (SELECT COUNT(*) FROM vetement v WHERE v.id_commande = m.id_commande AND v.statut_vetement <> \'Refusé\') nb_vet
              ' . $base . ' JOIN agence a ON a.id_agence = m.id_agence' . $w . '
              ORDER BY c.date_commande DESC LIMIT ' . $pg['limit'] . ' OFFSET ' . $pg['offset'], $params);

$actions = is_gerant() ? '<a class="btn btn-primary" href="' . e(url('commande-nouvelle')) . '">' . icon('plus') . ' Nouveau dépôt</a>' : '';
echo page_header('Commandes', is_gerant() ? 'Dépôts de l\'agence ' . e(user()['agence']) : 'Toutes les commandes du réseau', $actions);
?>
<div class="card card-flush">
    <form class="toolbar" method="get">
        <input type="hidden" name="p" value="commandes">
        <?php if ($statut) : ?><input type="hidden" name="statut" value="<?= e($statut) ?>"><?php endif; ?>
        <div class="input-group"><?= icon('search', 16) ?><input class="input" type="search" name="q" value="<?= e($q) ?>" placeholder="N° de commande, client ou téléphone"></div>
        <?php if (is_admin()): ?>
            <select class="select" name="agence" style="width:auto" onchange="this.form.submit()">
                <option value="0">Toutes les agences</option>
                <?php foreach (agences() as $a): ?><option value="<?= $a['id_agence'] ?>"<?= selected($agence, $a['id_agence']) ?>><?= e($a['nom_agence']) ?></option><?php endforeach; ?>
            </select>
        <?php endif; ?>
        <button class="btn btn-secondary" type="submit">Rechercher</button>
    </form>
    <div class="toolbar">
        <div class="segmented">
            <?php foreach ($groupes as $k => [$lbl]): ?>
                <a class="<?= $statut === $k ? 'active' : '' ?>" href="<?= e(url('commandes', array_filter(['statut' => $k, 'q' => $q, 'agence' => is_admin() ? $agence : null]))) ?>"><?= e($lbl) ?> <span class="count"><?= $counts[$k] ?></span></a>
            <?php endforeach; ?>
        </div>
    </div>
    <?php if ($list): ?>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Commande</th><th>Client</th><?php if (is_admin()): ?><th>Agence</th><?php endif; ?><th>Service</th><th class="num">Vêtements</th><th class="num">Montant</th><th class="num">Reste dû</th><th>Statut</th></tr></thead>
        <tbody>
        <?php foreach ($list as $c): ?>
            <tr class="clickable" data-href="<?= e(url('commande', ['id' => $c['id_commande']])) ?>">
                <td><span class="ref"><?= e($c['numero_commande']) ?></span><div class="cell-sub mt-1"><?= e(dt($c['date_commande'])) ?></div></td>
                <td><div class="cell-main"><?= e($c['client']) ?></div><div class="cell-sub"><?= e($c['telephone_client']) ?></div></td>
                <?php if (is_admin()): ?><td class="text-2"><?= e($c['nom_agence']) ?></td><?php endif; ?>
                <td><div class="row-wrap" style="gap:6px">
                    <?= $c['type_service'] === 'Express' ? '<span class="chip" style="color:var(--warning)">' . icon('zap', 13) . ' Express</span>' : '<span class="chip">Normal</span>' ?>
                    <?= $c['mode_recuperation'] === 'Livraison' ? '<span class="chip">' . icon('truck', 13) . ' Livraison</span>' : '' ?>
                </div></td>
                <td class="num"><?= (int) $c['nb_vet'] ?></td>
                <td class="num strong"><?= money($c['montant_total']) ?></td>
                <td class="num"><?= $c['reste_a_payer'] > 0 && $c['statut_commande'] !== 'Annulée' ? '<span style="color:var(--warning);font-weight:700">' . money($c['reste_a_payer']) . '</span>' : '<span class="muted">—</span>' ?></td>
                <td><?= badge($c['statut_commande']) ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table></div>
    <?= pagination_links($pg) ?>
    <?php else: ?>
        <?= empty_state($q !== '' ? 'Aucune commande ne correspond' : 'Aucune commande', $q !== '' ? 'Essayez un autre numéro, nom ou téléphone.' : 'Les dépôts enregistrés au comptoir apparaîtront ici.', 'receipt',
            is_gerant() ? '<a class="btn btn-primary" href="' . e(url('commande-nouvelle')) . '">' . icon('plus') . ' Nouveau dépôt</a>' : '') ?>
    <?php endif; ?>
</div>
