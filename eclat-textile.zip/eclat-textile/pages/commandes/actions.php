<?php
/**
 * Actions du gérant sur une commande (formulaires POST de la fiche commande).
 * Chaque action est vérifiée par les déclencheurs ; leurs messages sont affichés tels quels.
 */
if (!is_post()) {
    redirect('commandes');
}
csrf_check();
$id = (int) post('id_commande');
$c = load_commande($id);
if (!$c) {
    flash('error', 'Commande introuvable.');
    redirect('commandes');
}
$action = (string) post('action');
$ok = null;

try {
    switch ($action) {
        case 'ajouter_vetement':
            $refuse = post('refuse') === '1';
            $maj = (float) str_replace(',', '.', (string) post('majoration_speciale', '0'));
            $accord = post('accord_client') === '1';
            if ($maj > 0 && !$accord) {
                throw new RuntimeException('RG31 : une majoration spéciale nécessite l\'accord du client.');
            }
            $poids = (float) str_replace(',', '.', (string) post('poids_kg'));
            $qte = max(1, min(50, (int) post('quantite', 1)));
            transaction(function () use ($id, $refuse, $maj, $accord, $poids, $qte) {
                for ($i = 0; $i < $qte; $i++) {
                    q('INSERT INTO vetement (code_etiquette, poids_kg, etat_initial, anomalies, majoration_speciale, accord_client, date_accord,
                                             statut_vetement, motif_refus, id_commande, id_article)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', [
                        $qte === 1 ? (string) post('code_etiquette', '') : '',
                        $poids, post('etat_initial') ?: 'Bon état', nullable(post('anomalies')),
                        $refuse ? 0 : $maj, $accord ? 1 : 0, $accord ? date('Y-m-d H:i:s') : null,
                        $refuse ? 'Refusé' : 'Accepté', $refuse ? (post('motif_refus') ?: 'Non précisé') : null,
                        $id, (int) post('id_article'),
                    ]);
                }
            });
            $ok = $refuse ? 'Vêtement enregistré comme refusé (non facturé).' : ($qte > 1 ? "$qte vêtements ajoutés et étiquetés." : 'Vêtement ajouté et étiqueté.');
            break;

        case 'refuser_vetement':
            q("UPDATE vetement SET statut_vetement = 'Refusé', motif_refus = ? WHERE id_vetement = ? AND id_commande = ?",
                [post('motif_refus') ?: 'Non précisé', (int) post('id_vetement'), $id]);
            $ok = 'Vêtement refusé : il n\'est plus facturé.';
            break;

        case 'ajouter_supplement':
            $idVet = nullable(post('id_vetement'));
            q('INSERT INTO supplement_applique (prix_supp_applique, quantite_supp, id_commande, id_supplement, id_vetement) VALUES (0, ?, ?, ?, ?)',
                [max(1, (int) post('quantite_supp', 1)), $id, (int) post('id_supplement'), $idVet === null ? null : (int) $idVet]);
            $ok = 'Supplément ajouté.';
            break;

        case 'changer_service':
            q('UPDATE commande SET type_service = ? WHERE id_commande = ?', [post('type_service') === 'Express' ? 'Express' : 'Normal', $id]);
            $ok = 'Type de service mis à jour.';
            break;

        case 'paiement':
            $montant = (float) str_replace([' ', ','], ['', '.'], (string) post('montant'));
            $mode = in_array(post('mode_paiement'), MODES_PAIEMENT, true) ? post('mode_paiement') : 'Espèces';
            q("INSERT INTO paiement (montant_paiement, mode_paiement, reference_paiement, objet_paiement, id_commande, id_employe)
               VALUES (?, ?, ?, 'Commande', ?, ?)", [$montant, $mode, $mode === 'Espèces' ? nullable(post('reference')) : post('reference'), $id, my_id()]);
            $statut = val('SELECT statut_commande FROM commande WHERE id_commande = ?', [$id]);
            $ok = $statut === 'Payée'
                ? 'Paiement intégral reçu : facture émise et code de validation envoyé au client.'
                : 'Acompte de ' . money($montant) . ' enregistré.';
            break;

        case 'statut':
            $cible = (string) post('statut');
            if (!in_array($cible, ['En traitement', 'Terminée', 'Annulée'], true)) {
                throw new RuntimeException('Action non reconnue.');
            }
            q('UPDATE commande SET statut_commande = ? WHERE id_commande = ?', [$cible, $id]);
            $nouveau = val('SELECT statut_commande FROM commande WHERE id_commande = ?', [$id]);
            $ok = match ($nouveau) {
                'En traitement' => 'Traitement démarré : les vêtements sont à l\'atelier.',
                'Terminée' => $c['mode_recuperation'] === 'Retrait'
                    ? 'Commande terminée : le client est avisé que ses vêtements sont prêts.'
                    : 'Commande terminée : livraison créée et livreur affecté.',
                'En attente de livreur' => 'Commande terminée : aucun livreur libre, la livraison est en file d\'attente.',
                'Annulée' => 'Commande annulée.',
                default => 'Statut mis à jour.',
            };
            break;

        case 'vetement_pret':
            $idv = post('id_vetement');
            if ($idv === 'tous') {
                q("UPDATE vetement SET statut_vetement = 'Prêt' WHERE id_commande = ? AND statut_vetement = 'En traitement'", [$id]);
                $ok = 'Tous les vêtements sont prêts.';
            } else {
                q("UPDATE vetement SET statut_vetement = 'Prêt' WHERE id_vetement = ? AND id_commande = ? AND statut_vetement = 'En traitement'", [(int) $idv, $id]);
                $ok = 'Vêtement marqué prêt.';
            }
            break;

        case 'regenerer_code':
            q('CALL sp_regenerer_code(?, ?)', [$id, my_id()]);
            $ok = 'Nouveau code généré et envoyé au client ; l\'ancien est désactivé.';
            break;

        default:
            throw new RuntimeException('Action non reconnue.');
    }
    flash('success', $ok);
} catch (Throwable $ex) {
    flash('error', db_error($ex));
}
redirect('commande', ['id' => $id]);
