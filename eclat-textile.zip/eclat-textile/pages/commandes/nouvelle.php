<?php
/**
 * Nouveau dépôt — étape 1 : client, type de service, mode de récupération.
 * La base copie la configuration de l'agence et calcule la réduction de fidélité (RG19 à RG21, RG38).
 */
$title = 'Nouveau dépôt';
$ag = row('SELECT * FROM agence WHERE id_agence = ?', [my_agence()]);
$livPrix = val("SELECT ts.prix_supplement FROM tarif_supplement ts JOIN supplement s ON s.id_supplement = ts.id_supplement
                 WHERE ts.id_agence = ? AND s.libelle_supplement = 'Livraison à domicile' AND ts.actif_supplement = TRUE", [my_agence()]);

if (is_post()) {
    csrf_check();
    $idClient = (int) post('id_client');
    try {
        if (!$idClient) throw new RuntimeException('Sélectionnez un client.');
        $mode = post('mode_recuperation') === 'Livraison' ? 'Livraison' : 'Retrait';
        if ($mode === 'Livraison' && $livPrix === null) throw new RuntimeException('La livraison à domicile n\'est pas proposée par cette agence (tarif inactif).');
        // Les colonnes *_applique sont recopiées par le déclencheur trg_commande_bi (valeurs provisoires ici)
        q('INSERT INTO commande (numero_commande, type_service, mode_recuperation, id_agence, id_client, id_employe,
                                 duree_appliquee_h, taux_majoration_applique, tarif_kg_applique, seuil_poids_applique,
                                 prix_hors_cat_applique, delai_grace_applique, frais_retard_applique)
           VALUES (\'\', ?, ?, ?, ?, ?, 1, 0, 1, 1, 1, 0, 0)',
            [post('type_service') === 'Express' ? 'Express' : 'Normal', $mode, my_agence(), $idClient, my_id()]);
        $id = (int) db()->lastInsertId();
        $c = row('SELECT numero_commande, taux_remise FROM commande WHERE id_commande = ?', [$id]);
        flash('success', 'Commande ' . $c['numero_commande'] . ' créée. Ajoutez maintenant les vêtements déposés.'
            . ($c['taux_remise'] > 0 ? ' Réduction de fidélité de ' . num($c['taux_remise'], 0) . ' % appliquée !' : ''));
        redirect('commande', ['id' => $id]);
    } catch (Throwable $ex) {
        flash('error', db_error($ex));
        redirect('commande-nouvelle', ['client' => $idClient ?: null]);
    }
}

$q = (string) get('q', '');
$selId = (int) get('client', 0);
$sel = $selId ? row('SELECT cl.*, a.nom_agence, f.nb_commandes_eligibles, f.seuil_fidelite, f.reduction_disponible
                       FROM client cl JOIN agence a ON a.id_agence = cl.id_agence JOIN v_fidelite_clients f ON f.id_client = cl.id_client
                      WHERE cl.id_client = ?', [$selId]) : null;
$results = [];
if ($q !== '') {
    $results = rows("SELECT cl.*, a.nom_agence FROM client cl JOIN agence a ON a.id_agence = cl.id_agence
                      WHERE cl.telephone_client LIKE ? OR CONCAT(cl.nom_client, ' ', COALESCE(cl.prenom_client,'')) LIKE ?
                         OR CONCAT(COALESCE(cl.prenom_client,''), ' ', cl.nom_client) LIKE ?
                      ORDER BY cl.nom_client LIMIT 12", ["%$q%", "%$q%", "%$q%"]);
} elseif (!$sel) {
    $results = rows('SELECT cl.*, a.nom_agence FROM client cl JOIN agence a ON a.id_agence = cl.id_agence
                      LEFT JOIN commande c ON c.id_client = cl.id_client
                      WHERE cl.id_agence = ? GROUP BY cl.id_client ORDER BY MAX(c.date_commande) DESC, cl.id_client DESC LIMIT 6', [my_agence()]);
}

echo page_header('Nouveau dépôt', 'Étape 1 sur 2 — le client et le service. Les vêtements sont pesés et étiquetés à l\'étape suivante.', '', url('commandes'));
?>
<div class="grid grid-main-wide">
    <div class="card">
        <div class="card-header"><h2><?= icon('user') ?> Client</h2>
            <a class="btn btn-secondary btn-sm" href="<?= e(url('client-form', ['retour' => 'commande'])) ?>"><?= icon('plus', 15) ?> Nouveau client</a></div>
        <div class="card-body">
            <?php if ($sel): ?>
                <div class="row between" style="align-items:flex-start">
                    <div class="row" style="gap:14px">
                        <span class="avatar avatar-lg"><?= e(initials($sel['nom_client'], $sel['prenom_client'])) ?></span>
                        <div>
                            <h3 style="font-size:18px"><?= e(full_name($sel['nom_client'], $sel['prenom_client'])) ?></h3>
                            <div class="text-2 row-wrap mt-1" style="gap:14px">
                                <span class="row" style="gap:6px"><?= icon('phone', 15) ?> <?= e($sel['telephone_client']) ?></span>
                                <span class="row" style="gap:6px"><?= icon('pin', 15) ?> <?= e($sel['adresse_client'] ?: 'Adresse non renseignée') ?></span>
                            </div>
                        </div>
                    </div>
                    <a class="btn btn-ghost btn-sm" href="<?= e(url('commande-nouvelle')) ?>">Changer</a>
                </div>
                <div class="divider"></div>
                <?php if ((int) $sel['id_agence'] === my_agence()):
                    $pct = min(100, $sel['nb_commandes_eligibles'] / max(1, $sel['seuil_fidelite']) * 100); ?>
                    <div class="row between"><span class="label row" style="gap:8px"><?= icon('gift', 16) ?> Fidélité</span>
                        <span class="text-2 small"><?= (int) $sel['nb_commandes_eligibles'] ?> / <?= (int) $sel['seuil_fidelite'] ?> commandes</span></div>
                    <div class="progress mt-1"><span style="width:<?= $pct ?>%"></span></div>
                    <?php if ($sel['reduction_disponible']): ?>
                        <div class="alert alert-good mt-2"><?= icon('gift') ?><div><strong>Réduction disponible</strong>La réduction de <?= num($ag['taux_fidelite'], 0) ?> % sera appliquée automatiquement à ce dépôt.</div></div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="alert alert-info"><?= icon('store') ?><div>Client fidèle de l'agence <strong style="display:inline"><?= e($sel['nom_agence']) ?></strong> : la fidélité ne s'applique pas ici (RG19).</div></div>
                <?php endif; ?>
            <?php else: ?>
                <form method="get" class="mb-2">
                    <input type="hidden" name="p" value="commande-nouvelle">
                    <div class="input-group"><?= icon('search', 16) ?>
                        <input class="input" type="search" name="q" value="<?= e($q) ?>" placeholder="Téléphone ou nom du client" autofocus>
                    </div>
                </form>
                <p class="section-title"><?= $q !== '' ? 'Résultats' : 'Clients récents de l\'agence' ?></p>
                <?php if ($results): ?>
                    <div class="stack-sm">
                    <?php foreach ($results as $r): ?>
                        <a class="demo-account" href="<?= e(url('commande-nouvelle', ['client' => $r['id_client']])) ?>">
                            <span class="avatar avatar-soft"><?= e(initials($r['nom_client'], $r['prenom_client'])) ?></span>
                            <span class="grow"><strong><?= e(full_name($r['nom_client'], $r['prenom_client'])) ?></strong>
                                <small><?= e($r['telephone_client']) ?> · fidèle à <?= e($r['nom_agence']) ?></small></span>
                            <?= icon('chevron', 16, 'muted') ?>
                        </a>
                    <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <?= empty_state('Aucun client trouvé', 'Vérifiez le numéro ou créez la fiche du client.', 'user',
                        '<a class="btn btn-primary" href="' . e(url('client-form', ['retour' => 'commande', 'telephone' => $q])) . '">' . icon('plus') . ' Créer le client</a>') ?>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>

    <form class="card" method="post">
        <?= csrf_field() ?>
        <input type="hidden" name="id_client" value="<?= $sel ? (int) $sel['id_client'] : '' ?>">
        <div class="card-header"><h2><?= icon('sliders') ?> Service</h2></div>
        <div class="card-body stack">
            <div>
                <p class="section-title">Type de service</p>
                <div class="choices">
                    <label class="choice"><input type="radio" name="type_service" value="Normal" checked>
                        <span class="choice-card"><span class="choice-icon"><?= icon('clock') ?></span><span><strong>Normal</strong><small>Prêt en <?= (int) $ag['duree_normal_h'] ?> h</small></span></span></label>
                    <label class="choice"><input type="radio" name="type_service" value="Express">
                        <span class="choice-card"><span class="choice-icon"><?= icon('zap') ?></span><span><strong>Express</strong><small><?= (int) $ag['duree_express_h'] ?> h · +<?= num($ag['taux_majoration_express'], 0) ?> %</small></span></span></label>
                </div>
            </div>
            <div>
                <p class="section-title">Récupération</p>
                <div class="choices">
                    <label class="choice"><input type="radio" name="mode_recuperation" value="Retrait" checked>
                        <span class="choice-card"><span class="choice-icon"><?= icon('store') ?></span><span><strong>En agence</strong><small>Avec le code de retrait</small></span></span></label>
                    <label class="choice"><input type="radio" name="mode_recuperation" value="Livraison"<?= ($sel && !$sel['adresse_client']) || $livPrix === null ? ' disabled' : '' ?>>
                        <span class="choice-card"><span class="choice-icon"><?= icon('truck') ?></span><span><strong>À domicile</strong>
                            <small><?= $livPrix === null ? 'Non proposée' : '+' . money($livPrix) ?></small></span></span></label>
                </div>
                <?php if ($sel && !$sel['adresse_client']): ?>
                    <p class="hint small muted mt-1">La livraison nécessite l'adresse du client. <a href="<?= e(url('client-form', ['id' => $sel['id_client'], 'retour' => 'commande'])) ?>">Compléter la fiche</a></p>
                <?php endif; ?>
            </div>
            <div class="alert alert-info"><?= icon('shield') ?><div class="small">Les tarifs, durées et taux en vigueur sont figés dans la commande dès son enregistrement (RG38).</div></div>
        </div>
        <div class="card-footer"><button class="btn btn-primary btn-lg btn-block" type="submit"<?= $sel ? '' : ' disabled' ?>>Continuer : ajouter les vêtements <?= icon('chevron', 16) ?></button></div>
    </form>
</div>
