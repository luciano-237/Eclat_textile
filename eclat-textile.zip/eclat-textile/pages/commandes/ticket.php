<?php
/** Ticket de dépôt / facture imprimable, avec QR code et code de validation. */
$id = (int) get('id');
$c = load_commande($id);
if (!$c) {
    flash('error', 'Commande introuvable.');
    redirect('commandes');
}
$layout = 'print';
$facture = get('facture') ? row('SELECT * FROM facture WHERE id_facture = ? AND id_commande = ?', [(int) get('facture'), $id]) : null;
$title = $facture ? 'Facture ' . $facture['numero_facture'] : 'Ticket ' . $c['numero_commande'];
$vets = rows("SELECT v.*, a.libelle_article FROM vetement v JOIN article a ON a.id_article = v.id_article
               WHERE v.id_commande = ? AND v.statut_vetement <> 'Refusé' ORDER BY v.id_vetement", [$id]);
$supps = rows('SELECT sa.*, s.libelle_supplement FROM supplement_applique sa JOIN supplement s ON s.id_supplement = sa.id_supplement WHERE sa.id_commande = ?', [$id]);
$lot = row('SELECT * FROM v_lot_poids WHERE id_commande = ?', [$id]);
$paiements = rows('SELECT * FROM paiement WHERE id_commande = ? ORDER BY date_paiement', [$id]);
$code = row("SELECT * FROM code_validation WHERE id_commande = ? AND statut_code = 'Actif'", [$id]);
$lotMontant = 0;
if ($lot && $lot['nb_vetements_lot'] > 0) {
    $lotMontant = $lot['mode_facturation_lot'] === 'Poids' ? round($lot['poids_lot_kg'] * $c['tarif_kg_applique']) : $lot['nb_vetements_lot'] * $c['prix_hors_cat_applique'];
}
?>
<div class="print-actions">
    <button class="btn btn-primary" data-print><?= icon('printer') ?> Imprimer</button>
    <a class="btn btn-secondary" href="<?= e(url('commande', ['id' => $id])) ?>"><?= icon('back') ?> Retour à la commande</a>
</div>
<div class="ticket">
    <div class="t-center">
        <img src="assets/img/logo.svg" alt="" width="44" height="44">
        <h1 class="mt-1"><?= e(cfg('app_name')) ?> — <?= e($c['nom_agence']) ?></h1>
        <div><?= e($c['adresse_agence']) ?>, <?= e($c['ville_agence']) ?></div>
        <div>Tél. <?= e($c['telephone_agence']) ?></div>
    </div>
    <hr class="t-sep">
    <?php if ($facture): ?>
        <div class="t-center"><strong style="font-size:15px">FACTURE <?= $facture['type_facture'] === 'Principale' ? '' : 'DE FRAIS DE RETARD' ?></strong><br>
            N° <?= e($facture['numero_facture']) ?> · <?= e(dt($facture['date_facture'])) ?></div>
        <hr class="t-sep">
    <?php endif; ?>
    <table>
        <tr><td>Commande</td><td class="r"><strong><?= e($c['numero_commande']) ?></strong></td></tr>
        <tr><td>Déposée le</td><td class="r"><?= e(dt($c['date_commande'])) ?></td></tr>
        <tr><td>Client</td><td class="r"><?= e(full_name($c['nom_client'], $c['prenom_client'])) ?></td></tr>
        <tr><td>Téléphone</td><td class="r"><?= e($c['telephone_client']) ?></td></tr>
        <tr><td>Service</td><td class="r"><?= e($c['type_service']) ?> · <?= e($c['mode_recuperation'] === 'Livraison' ? 'livraison' : 'retrait en agence') ?></td></tr>
        <?php if ($c['date_retrait_prevue']): ?><tr><td>Disponible le</td><td class="r"><strong><?= e(dt($c['date_retrait_prevue'])) ?></strong></td></tr><?php endif; ?>
    </table>
    <hr class="t-sep">
    <?php if ($facture && $facture['type_facture'] !== 'Principale'): ?>
        <table><tr><td>Frais de retard réglés</td><td class="r t-total"><?= money($facture['montant_facture']) ?></td></tr></table>
    <?php else: ?>
    <table>
        <?php foreach ($vets as $v): ?>
            <tr><td><?= e($v['libelle_article']) ?><br><small style="color:#666"><?= e($v['code_etiquette']) ?> · <?= num($v['poids_kg'], 2) ?> kg</small></td>
                <td class="r"><?= $v['prix_applique'] !== null ? money($v['prix_applique']) : '<small>lot</small>' ?></td></tr>
            <?php if ($v['majoration_speciale'] > 0): ?><tr><td style="padding-left:10px"><small>Traitement spécial</small></td><td class="r"><?= money($v['majoration_speciale']) ?></td></tr><?php endif; ?>
        <?php endforeach; ?>
        <?php if ($lotMontant > 0): ?>
            <tr><td>Lot au poids (<?= num($lot['poids_lot_kg'], 2) ?> kg<?= $lot['mode_facturation_lot'] === 'Poids' ? '' : ', à la pièce' ?>)</td><td class="r"><?= money($lotMontant) ?></td></tr>
        <?php endif; ?>
        <?php foreach ($supps as $s): ?>
            <tr><td><?= e($s['libelle_supplement']) ?><?= $s['quantite_supp'] > 1 ? ' × ' . (int) $s['quantite_supp'] : '' ?></td><td class="r"><?= money($s['prix_supp_applique'] * $s['quantite_supp']) ?></td></tr>
        <?php endforeach; ?>
        <?php if ($c['montant_majoration'] > 0): ?><tr><td>Majoration express (<?= num($c['taux_majoration_applique'], 0) ?> %)</td><td class="r"><?= money($c['montant_majoration']) ?></td></tr><?php endif; ?>
        <?php if ($c['taux_remise'] > 0): ?><tr><td>Réduction fidélité (<?= num($c['taux_remise'], 0) ?> %)</td><td class="r">− <?= money($c['montant_vetements'] + $c['montant_majoration'] + $c['montant_supplements'] - $c['montant_total']) ?></td></tr><?php endif; ?>
    </table>
    <hr class="t-sep">
    <table>
        <tr><td class="t-total">TOTAL</td><td class="r t-total"><?= money($facture['montant_facture'] ?? $c['montant_total']) ?></td></tr>
        <?php foreach ($paiements as $p): if ($p['objet_paiement'] !== 'Commande') continue; ?>
            <tr><td><small><?= e($p['mode_paiement']) ?> · <?= e(dt($p['date_paiement'])) ?></small></td><td class="r"><small><?= money($p['montant_paiement']) ?></small></td></tr>
        <?php endforeach; ?>
        <?php if ($c['reste_a_payer'] > 0): ?><tr><td><strong>Reste à payer</strong></td><td class="r"><strong><?= money($c['reste_a_payer']) ?></strong></td></tr><?php endif; ?>
    </table>
    <?php endif; ?>
    <?php if ($code && !$facture): ?>
        <hr class="t-sep">
        <div class="t-center"><strong>Code de retrait</strong></div>
        <div class="qr" data-qr="<?= e(qr_payload($code)) ?>"></div>
        <div class="code"><?= e($code['code_numerique']) ?></div>
        <div class="t-center" style="color:#666;font-size:11px;margin-top:6px">Présentez ce QR code ou ce code à 6 chiffres<br>pour récupérer vos vêtements. Ne le communiquez pas.</div>
    <?php endif; ?>
    <hr class="t-sep">
    <div class="t-center" style="font-size:11px;color:#666">
        <?php if ($c['mode_recuperation'] === 'Retrait'): ?>Au-delà de <?= (int) $c['delai_grace_applique'] ?> jours après la date de disponibilité, des frais de <?= money($c['frais_retard_applique']) ?> par jour et par vêtement s'appliquent.<br><?php endif; ?>
        Merci de votre confiance !
    </div>
</div>
