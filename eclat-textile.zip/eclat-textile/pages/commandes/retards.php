<?php
/** Retards de retrait (RG74 à RG77) et rappels à envoyer (RG87). */
$title = 'Retards & rappels';
$a = my_agence();

if (is_post()) {
    csrf_check();
    $n = 0;
    foreach (rows('SELECT * FROM v_rappels_a_envoyer r JOIN commande c ON c.id_commande = r.id_commande WHERE c.id_agence = ?', [$a]) as $r) {
        $deja = val("SELECT 1 FROM notification WHERE id_commande = ? AND type_notification = 'Rappel de retrait' AND DATE(date_notification) = CURRENT_DATE", [$r['id_commande']]);
        if ($deja) continue;
        q("INSERT INTO notification (type_notification, contenu, id_client, id_commande) VALUES ('Rappel de retrait', ?, ?, ?)", [
            'Rappel : vos vêtements (commande n° ' . $r['numero_commande'] . ') vous attendent. Sans retrait avant le '
            . dt($r['fin_delai_grace'], false) . ', des frais de retard s\'appliqueront.', $r['id_client'], $r['id_commande'],
        ]);
        $n++;
    }
    flash($n ? 'success' : 'info', $n ? "$n rappel(s) mis en file d'envoi." : 'Aucun nouveau rappel à envoyer aujourd\'hui.');
    redirect('retards');
}

$retards = rows('SELECT f.*, cl.nom_client, cl.prenom_client FROM v_frais_retard f JOIN commande c ON c.id_commande = f.id_commande
                   JOIN client cl ON cl.id_client = c.id_client WHERE f.id_agence = ? ORDER BY f.fin_delai_grace', [$a]);
$rappels = rows('SELECT r.*, cl.nom_client, cl.prenom_client,
                        (SELECT MAX(n.date_notification) FROM notification n WHERE n.id_commande = r.id_commande AND n.type_notification = \'Rappel de retrait\') dernier
                   FROM v_rappels_a_envoyer r JOIN commande c ON c.id_commande = r.id_commande JOIN client cl ON cl.id_client = r.id_client
                  WHERE c.id_agence = ? ORDER BY r.fin_delai_grace', [$a]);
$totalDus = array_sum(array_map(fn($r) => $r['frais_retard_dus'] - $r['frais_retard_payes'], $retards));

echo page_header('Retards & rappels', 'Vêtements prêts non récupérés dans l\'agence ' . e(user()['agence']));
?>
<div class="grid grid-3 mb-2">
    <?= kpi('Commandes en retard', num(count($retards)), 'clock', count($retards) ? 'warning' : 'good', 'Délai de grâce dépassé') ?>
    <?= kpi('Frais de retard à percevoir', kpi_money($totalDus), 'wallet', 'teal', 'Réglés au moment du retrait') ?>
    <?= kpi('Rappels à envoyer', num(count($rappels)), 'bell', 'info', 'Commandes prêtes, délai de grâce en cours') ?>
</div>

<div class="card card-flush mb-2">
    <div class="card-header"><h2><?= icon('bell') ?> Rappels de retrait</h2>
        <form method="post"><?= csrf_field() ?><button class="btn btn-primary btn-sm" type="submit"<?= $rappels ? '' : ' disabled' ?>><?= icon('send', 15) ?> Envoyer les rappels du jour</button></form></div>
    <?php if ($rappels): ?>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Commande</th><th>Client</th><th>Disponible depuis</th><th>Fin du délai de grâce</th><th>Dernier rappel</th></tr></thead>
        <tbody><?php foreach ($rappels as $r): ?>
            <tr class="clickable" data-href="<?= e(url('commande', ['id' => $r['id_commande']])) ?>">
                <td><span class="ref"><?= e($r['numero_commande']) ?></span></td>
                <td><div class="cell-main"><?= e(full_name($r['nom_client'], $r['prenom_client'])) ?></div><div class="cell-sub"><?= e($r['telephone_client']) ?></div></td>
                <td class="text-2"><?= e(dt($r['date_retrait_prevue'])) ?></td>
                <td><span class="strong"><?= e(dt($r['fin_delai_grace'], false)) ?></span> <span class="muted small">(<?= e(rel_time($r['fin_delai_grace'])) ?>)</span></td>
                <td class="text-2"><?= $r['dernier'] ? e(rel_time($r['dernier'])) : '<span class="muted">Jamais</span>' ?></td>
            </tr>
        <?php endforeach; ?></tbody>
    </table></div>
    <?php else: echo empty_state('Aucun rappel à envoyer', 'Les commandes prêtes dont la date de retrait est passée apparaîtront ici.', 'bell'); endif; ?>
</div>

<div class="card card-flush">
    <div class="card-header"><h2><?= icon('clock') ?> Frais de retard en cours</h2></div>
    <?php if ($retards): ?>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Commande</th><th>Client</th><th>Fin du délai de grâce</th><th class="num">Vêtements restants</th><th class="num">Frais dus</th><th class="num">Déjà payés</th><th></th></tr></thead>
        <tbody><?php foreach ($retards as $r): ?>
            <tr>
                <td><a href="<?= e(url('commande', ['id' => $r['id_commande']])) ?>"><span class="ref"><?= e($r['numero_commande']) ?></span></a></td>
                <td><div class="cell-main"><?= e(full_name($r['nom_client'], $r['prenom_client'])) ?></div><div class="cell-sub"><?= e($r['telephone_client']) ?></div></td>
                <td class="text-2"><?= e(dt($r['fin_delai_grace'], false)) ?></td>
                <td class="num"><?= (int) $r['vetements_restants'] ?></td>
                <td class="num strong" style="color:var(--warning)"><?= money($r['frais_retard_dus']) ?></td>
                <td class="num"><?= money($r['frais_retard_payes']) ?></td>
                <td class="actions"><a class="btn btn-secondary btn-sm" href="<?= e(url('retrait', ['id' => $r['id_commande']])) ?>"><?= icon('package', 14) ?> Remettre</a></td>
            </tr>
        <?php endforeach; ?></tbody>
    </table></div>
    <?php else: echo empty_state('Aucun retard', 'Tous les clients récupèrent leurs vêtements dans le délai de grâce.', 'check-circle'); endif; ?>
</div>
