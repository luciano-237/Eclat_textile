<?php
/**
 * Exécution d'une livraison par le livreur (RG66 à RG70) :
 * récupération à l'agence, validation par code + photo, ou échec motivé.
 */
$id = (int) get('id');
$l = row('SELECT l.*, c.numero_commande, c.id_agence, c.id_commande, cl.nom_client, cl.prenom_client, cl.telephone_client
            FROM livraison l JOIN commande c ON c.id_commande = l.id_commande JOIN client cl ON cl.id_client = c.id_client
           WHERE l.id_livraison = ? AND l.id_employe = ?', [$id, my_id()]);
if (!$l) {
    flash('error', 'Livraison introuvable.');
    redirect('tournee');
}
$title = 'Livraison ' . $l['numero_commande'];

if (is_post()) {
    csrf_check();
    try {
        switch (post('action')) {
            case 'demarrer':
                q("UPDATE livraison SET statut_livraison = 'En cours' WHERE id_livraison = ?", [$id]);
                flash('success', 'Colis récupéré à l\'agence : bonne route !');
                redirect('livraison', ['id' => $id]);

            case 'livrer':
                $mode = verifier_code((int) $l['id_commande'], (string) post('code'));
                if ($mode === null) throw new RuntimeException('Code incorrect : demandez au client son code à 6 chiffres ou son QR code (RG67).');
                $f = $_FILES['photo'] ?? null;
                $err = $f['error'] ?? UPLOAD_ERR_NO_FILE;
                if ($err === UPLOAD_ERR_INI_SIZE || $err === UPLOAD_ERR_FORM_SIZE) {
                    throw new RuntimeException('Photo trop lourde pour le serveur (limite : ' . ini_get('upload_max_filesize') . '). Reprenez la photo.');
                }
                if ($err === UPLOAD_ERR_PARTIAL) throw new RuntimeException('La photo n\'a été reçue qu\'en partie (connexion coupée ?). Réessayez.');
                if ($err === UPLOAD_ERR_NO_FILE) throw new RuntimeException('RG68 : une photo justificative est obligatoire.');
                if ($err !== UPLOAD_ERR_OK) throw new RuntimeException('Le serveur n\'a pas pu recevoir la photo (erreur ' . $err . ').');
                if ($f['size'] > 8 * 1024 * 1024) throw new RuntimeException('Photo trop lourde (8 Mo maximum).');
                $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
                $ext = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'][$mime] ?? null;
                if (!$ext) throw new RuntimeException('Format de photo non accepté (JPEG, PNG ou WebP).');
                $dir = cfg('upload_dir') . '/preuves/' . date('Y-m');
                if (!is_dir($dir) && !mkdir($dir, 0775, true)) throw new RuntimeException('Impossible d\'enregistrer la photo sur le serveur.');
                $name = 'L' . $id . '-' . bin2hex(random_bytes(6)) . '.' . $ext;
                if (!move_uploaded_file($f['tmp_name'], "$dir/$name")) throw new RuntimeException('Échec de l\'enregistrement de la photo.');
                transaction(function () use ($id, $name, $mode) {
                    q('INSERT INTO preuve_livraison (url_photo, id_livraison) VALUES (?, ?)', ['uploads/preuves/' . date('Y-m') . '/' . $name, $id]);
                    q("UPDATE livraison SET statut_livraison = 'Livrée', mode_validation = ?, date_livraison = NOW() WHERE id_livraison = ?", [$mode, $id]);
                });
                q('CALL sp_affecter_livraisons_attente(?)', [$l['id_agence']]);       // RG64
                flash('success', 'Livraison validée. Le client a reçu sa confirmation.');
                redirect('tournee');

            case 'echec':
                if (!post('motif_echec')) throw new RuntimeException('Indiquez le motif de l\'échec.');
                transaction(function () use ($id, $l) {
                    q("UPDATE livraison SET statut_livraison = 'Échouée', motif_echec = ? WHERE id_livraison = ?", [post('motif_echec'), $id]);
                    q("INSERT INTO incident (type_incident, motif_incident, description_incident, id_commande, id_employe) VALUES ('Échec de livraison', ?, ?, ?, ?)",
                        [post('motif_echec'), nullable(post('details')), $l['id_commande'], my_id()]);
                });
                q('CALL sp_affecter_livraisons_attente(?)', [$l['id_agence']]);
                flash('warning', 'Échec enregistré : le colis retourne à l\'agence et le gérant est informé.');
                redirect('tournee');
        }
    } catch (Throwable $ex) {
        flash('error', db_error($ex));
        if (post('action') === 'livrer') {
            $_SESSION['code_saisi'][$id] = (string) post('code');   // le livreur n'a pas à le retaper
        }
        redirect('livraison', ['id' => $id]);
    }
}
$codeSaisi = $_SESSION['code_saisi'][$id] ?? '';
unset($_SESSION['code_saisi'][$id]);
$vets = rows("SELECT v.code_etiquette, a.libelle_article, v.statut_vetement FROM vetement v JOIN article a ON a.id_article = v.id_article
               WHERE v.id_commande = ? AND v.statut_vetement <> 'Refusé'", [$l['id_commande']]);
$st = $l['statut_livraison'];
echo page_header('Livraison ' . $l['numero_commande'], badge($st), '', url('tournee'));
?>
<div class="grid grid-main">
    <div class="stack">
        <?php if ($st === 'Assignée'): ?>
            <div class="card"><div class="card-body stack">
                <div class="alert alert-info"><?= icon('store') ?><div><strong>Étape 1 : récupérer le colis</strong>Passez à l'agence, vérifiez les étiquettes ci-contre puis confirmez la prise en charge.</div></div>
                <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="demarrer">
                    <button class="btn btn-primary btn-lg btn-block" type="submit"><?= icon('package') ?> J'ai récupéré le colis</button></form>
            </div></div>
        <?php elseif ($st === 'En cours'): ?>
            <form method="post" enctype="multipart/form-data" class="card"><?= csrf_field() ?><input type="hidden" name="action" value="livrer">
                <div class="card-header"><h2><?= icon('check-circle') ?> Valider la remise</h2></div>
                <div class="card-body stack">
                    <div class="field"><label class="req" for="code">Code du client</label>
                        <input class="input input-xl" id="code" name="code" required inputmode="numeric" autocomplete="off" placeholder="000000" value="<?= e($codeSaisi) ?>">
                        <button type="button" class="btn btn-secondary btn-lg btn-block" data-qr-scan="code"><?= icon('camera', 18) ?> Scanner le QR code du client</button>
                        <span class="hint">Ou saisissez le code à 6 chiffres reçu par WhatsApp.</span></div>
                    <div class="field"><span class="label req">Photo justificative</span>
                        <label class="dropzone"><input type="file" name="photo" accept="image/*" capture="environment" required>
                            <?= icon('camera', 28) ?><strong class="dz-label">Prendre ou choisir une photo</strong><span class="small muted">Colis remis, devant le domicile</span></label></div>
                    <button class="btn btn-success btn-lg btn-block" type="submit"><?= icon('check') ?> Confirmer la livraison</button>
                </div>
            </form>
        <?php endif; ?>
        <?php if (in_array($st, ['Assignée', 'En cours'], true)): ?>
            <details class="card">
                <summary class="card-header" style="cursor:pointer;list-style:none"><h3><?= icon('alert') ?> Signaler un échec</h3><?= icon('chevron', 16) ?></summary>
                <form method="post" class="card-body stack"><?= csrf_field() ?><input type="hidden" name="action" value="echec">
                    <div class="field"><label class="req" for="motif_echec">Motif</label>
                        <select class="select" id="motif_echec" name="motif_echec" required>
                            <option value="">Choisir…</option><option>Client absent</option><option>Adresse introuvable</option><option>Client injoignable</option><option>Client refuse le colis</option><option>Code de validation non présenté</option><option>Autre</option></select></div>
                    <div class="field"><label for="details">Précisions</label><textarea class="textarea" id="details" name="details" rows="2"></textarea></div>
                    <button class="btn btn-danger btn-block" type="submit">Enregistrer l'échec</button>
                    <p class="small muted">Le colis retourne à l'agence ; la livraison sera reprogrammée (RG69).</p>
                </form>
            </details>
        <?php endif; ?>
    </div>
    <div class="stack">
        <div class="card"><div class="card-header"><h3><?= icon('user') ?> Client</h3></div>
            <div class="card-body stack-sm">
                <div class="cell-main"><?= e(full_name($l['nom_client'], $l['prenom_client'])) ?></div>
                <div class="text-2 row" style="gap:6px;align-items:flex-start"><?= icon('pin', 15) ?> <?= e($l['adresse_livraison']) ?></div>
                <div class="row-wrap mt-1">
                    <a class="btn btn-secondary btn-sm" href="tel:<?= e($l['telephone_client']) ?>"><?= icon('phone', 15) ?> <?= e($l['telephone_client']) ?></a>
                    <a class="btn btn-secondary btn-sm" target="_blank" rel="noopener" href="https://www.google.com/maps/search/?api=1&query=<?= e(rawurlencode($l['adresse_livraison'])) ?>"><?= icon('pin', 15) ?> Itinéraire</a>
                </div>
            </div></div>
        <div class="card"><div class="card-header"><h3><?= icon('shirt') ?> Contenu du colis</h3><span class="chip"><?= count($vets) ?></span></div>
            <div class="list"><?php foreach ($vets as $v): ?>
                <div class="list-item"><div class="grow"><div class="cell-main"><?= e($v['libelle_article']) ?></div><div class="cell-sub mono"><?= e($v['code_etiquette']) ?></div></div></div>
            <?php endforeach; ?></div></div>
    </div>
</div>
