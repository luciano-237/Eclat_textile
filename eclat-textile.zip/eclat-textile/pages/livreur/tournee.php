<?php
/** Feuille de route du livreur (RG66) — pensée pour le téléphone. */
$title = 'Ma tournée';
$missions = rows("SELECT l.*, c.numero_commande, cl.nom_client, cl.prenom_client, cl.telephone_client,
                         (SELECT COUNT(*) FROM vetement v WHERE v.id_commande = c.id_commande AND v.statut_vetement = 'Prêt') nb_vet
                    FROM livraison l JOIN commande c ON c.id_commande = l.id_commande JOIN client cl ON cl.id_client = c.id_client
                   WHERE l.id_employe = ? AND l.statut_livraison IN ('Assignée', 'En cours')
                   ORDER BY l.statut_livraison = 'En cours' DESC, l.date_assignation", [my_id()]);
$dispo = val('SELECT disponibilite_livreur FROM employe WHERE id_employe = ?', [my_id()]);
echo page_header('Ma tournée', strftime_fr() . ' · ' . badge($dispo));
?>
<?php if ($missions): ?>
<div class="grid grid-2">
    <?php foreach ($missions as $m): ?>
        <div class="mission">
            <div class="mission-head">
                <div><span class="ref"><?= e($m['numero_commande']) ?></span><div class="cell-sub mt-1">Affectée <?= e(rel_time($m['date_assignation'])) ?></div></div>
                <?= badge($m['statut_livraison']) ?>
            </div>
            <div class="mission-body">
                <div class="mission-line"><?= icon('user', 16) ?><div><strong style="color:var(--text)"><?= e(full_name($m['nom_client'], $m['prenom_client'])) ?></strong></div></div>
                <div class="mission-line"><?= icon('pin', 16) ?><div><?= e($m['adresse_livraison']) ?></div></div>
                <div class="mission-line"><?= icon('package', 16) ?><div><?= (int) $m['nb_vet'] ?> vêtement(s)<?= $m['nb_tentatives'] ? ' · ' . (int) $m['nb_tentatives'] . ' tentative(s) précédente(s)' : '' ?></div></div>
            </div>
            <div class="mission-actions">
                <a class="btn btn-secondary btn-sm" href="tel:<?= e($m['telephone_client']) ?>"><?= icon('phone', 15) ?> Appeler</a>
                <a class="btn btn-secondary btn-sm" target="_blank" rel="noopener" href="https://www.google.com/maps/search/?api=1&query=<?= e(rawurlencode($m['adresse_livraison'])) ?>"><?= icon('pin', 15) ?> Itinéraire</a>
                <a class="btn btn-primary btn-sm" style="margin-left:auto" href="<?= e(url('livraison', ['id' => $m['id_livraison']])) ?>"><?= $m['statut_livraison'] === 'Assignée' ? 'Démarrer' : 'Finaliser' ?> <?= icon('chevron', 15) ?></a>
            </div>
        </div>
    <?php endforeach; ?>
</div>
<?php else: ?>
    <div class="card"><?= empty_state('Aucune livraison en cours', 'Dès qu\'une commande de votre agence est prête à être livrée, elle vous est affectée automatiquement.', 'truck') ?></div>
<?php endif; ?>
