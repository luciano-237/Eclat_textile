<?php
/** Livraisons à domicile (RG62 à RG70) : file d'attente, affectation, reprogrammation. */
$title = 'Livraisons';
$agence = is_gerant() ? my_agence() : (int) get('agence', 0);

if (is_post() && is_gerant()) {
    csrf_check();
    try {
        $idl = (int) post('id_livraison');
        $own = $idl ? val('SELECT 1 FROM livraison l JOIN commande c ON c.id_commande = l.id_commande WHERE l.id_livraison = ? AND c.id_agence = ?', [$idl, $agence]) : true;
        if (!$own) throw new RuntimeException('Livraison introuvable.');
        switch (post('action')) {
            case 'affecter':
                q("UPDATE livraison SET statut_livraison = 'Assignée', id_employe = ? WHERE id_livraison = ?", [(int) post('id_employe'), $idl]);
                flash('success', 'Livraison affectée : le livreur et le client sont avisés.');
                break;
            case 'auto':
                q('CALL sp_affecter_livraisons_attente(?)', [$agence]);
                flash('success', 'Affectation automatique effectuée (premier arrivé, premier servi).');
                break;
            case 'reprogrammer':
                q("UPDATE livraison SET statut_livraison = 'En attente de livreur' WHERE id_livraison = ?", [$idl]);
                q('CALL sp_affecter_livraisons_attente(?)', [$agence]);
                flash('success', 'Livraison reprogrammée.');
                break;
            case 'dispo':
                $d = in_array(post('disponibilite'), ['Libre', 'Hors service'], true) ? post('disponibilite') : 'Libre';
                q("UPDATE employe e JOIN role r ON r.id_role = e.id_role SET e.disponibilite_livreur = ?
                    WHERE e.id_employe = ? AND e.id_agence = ? AND r.libelle_role = 'Livreur' AND e.disponibilite_livreur <> 'Occupé'",
                    [$d, (int) post('id_employe'), $agence]);
                if ($d === 'Libre') q('CALL sp_affecter_livraisons_attente(?)', [$agence]);
                flash('success', 'Disponibilité du livreur mise à jour.');
                break;
        }
    } catch (Throwable $ex) {
        flash('error', db_error($ex));
    }
    redirect('livraisons', ['onglet' => get('onglet')]);
}

$onglets = [
    'attente' => ['En attente', ['En attente de livreur']],
    'cours'   => ['En cours', ['Assignée', 'En cours']],
    'echec'   => ['Échouées', ['Échouée']],
    'livrees' => ['Livrées', ['Livrée']],
];
$onglet = isset($onglets[get('onglet')]) ? get('onglet') : 'attente';
$sts = $onglets[$onglet][1];

$cond = $agence ? ' AND c.id_agence = ' . (int) $agence : '';
$counts = [];
foreach (rows('SELECT l.statut_livraison s, COUNT(*) n FROM livraison l JOIN commande c ON c.id_commande = l.id_commande WHERE 1=1' . $cond . ' GROUP BY l.statut_livraison') as $r) {
    $counts[$r['s']] = (int) $r['n'];
}
$list = rows('SELECT l.*, c.numero_commande, c.id_agence, a.nom_agence, cl.nom_client, cl.prenom_client, cl.telephone_client, e.nom_employe, e.prenom_employe
                FROM livraison l JOIN commande c ON c.id_commande = l.id_commande JOIN client cl ON cl.id_client = c.id_client
                JOIN agence a ON a.id_agence = c.id_agence LEFT JOIN employe e ON e.id_employe = l.id_employe
               WHERE l.statut_livraison IN (' . implode(',', array_fill(0, count($sts), '?')) . ')' . $cond . '
               ORDER BY ' . ($onglet === 'livrees' ? 'l.date_livraison DESC' : 'l.date_creation_livraison, l.id_livraison') . ' LIMIT 100', $sts);
$livreurs = rows("SELECT e.*, a.nom_agence,
                         (SELECT COUNT(*) FROM livraison l WHERE l.id_employe = e.id_employe AND l.statut_livraison = 'Livrée') nb_livrees
                    FROM employe e JOIN role r ON r.id_role = e.id_role JOIN agence a ON a.id_agence = e.id_agence
                   WHERE r.libelle_role = 'Livreur' AND e.statut_compte = 'Actif'" . ($agence ? ' AND e.id_agence = ' . (int) $agence : '') . '
                   ORDER BY e.disponibilite_livreur, e.nom_employe');
$libres = array_values(array_filter($livreurs, fn($l) => $l['disponibilite_livreur'] === 'Libre'));

$actions = '';
if (is_gerant() && ($counts['En attente de livreur'] ?? 0) && $libres) {
    $actions = '<form method="post">' . csrf_field() . '<input type="hidden" name="action" value="auto"><button class="btn btn-primary" type="submit">'
        . icon('zap') . ' Affecter automatiquement</button></form>';
}
echo page_header('Livraisons', is_gerant() ? 'Livraisons à domicile de l\'agence ' . e(user()['agence']) : 'Livraisons du réseau', $actions);
?>
<div class="grid grid-main">
    <div class="card card-flush">
        <div class="toolbar">
            <div class="segmented">
                <?php foreach ($onglets as $k => [$lbl, $ss]): $n = array_sum(array_intersect_key($counts, array_flip($ss))); ?>
                    <a class="<?= $onglet === $k ? 'active' : '' ?>" href="<?= e(url('livraisons', array_filter(['onglet' => $k, 'agence' => is_admin() ? $agence : null]))) ?>"><?= e($lbl) ?> <span class="count"><?= $n ?></span></a>
                <?php endforeach; ?>
            </div>
            <?php if (is_admin()): ?>
                <form method="get" style="margin-left:auto"><input type="hidden" name="p" value="livraisons"><input type="hidden" name="onglet" value="<?= e($onglet) ?>">
                    <select class="select" name="agence" onchange="this.form.submit()"><option value="0">Toutes les agences</option>
                        <?php foreach (agences() as $ag): ?><option value="<?= $ag['id_agence'] ?>"<?= selected($agence, $ag['id_agence']) ?>><?= e($ag['nom_agence']) ?></option><?php endforeach; ?></select></form>
            <?php endif; ?>
        </div>
        <?php if ($list): ?>
        <div class="table-wrap"><table class="table">
            <thead><tr><th>Commande</th><th>Client</th><th class="hide-sm">Adresse</th><th>Livreur</th><th>Statut</th><th></th></tr></thead>
            <tbody><?php foreach ($list as $l): ?>
                <tr>
                    <td><a href="<?= e(url('commande', ['id' => $l['id_commande']])) ?>"><span class="ref"><?= e($l['numero_commande']) ?></span></a>
                        <div class="cell-sub mt-1"><?= $onglet === 'livrees' ? 'Livrée ' . e(rel_time($l['date_livraison'])) : 'En file ' . e(rel_time($l['date_creation_livraison'])) ?></div></td>
                    <td><div class="cell-main"><?= e(full_name($l['nom_client'], $l['prenom_client'])) ?></div><div class="cell-sub"><?= e($l['telephone_client']) ?></div></td>
                    <td class="hide-sm text-2" style="max-width:220px"><?= e($l['adresse_livraison']) ?></td>
                    <td><?= $l['id_employe'] ? e(full_name($l['nom_employe'], $l['prenom_employe'])) : '<span class="muted">—</span>' ?>
                        <?php if ($l['nb_tentatives'] > 0): ?><div class="cell-sub" style="color:var(--warning)"><?= (int) $l['nb_tentatives'] ?> échec(s)<?= $l['motif_echec'] ? ' · ' . e($l['motif_echec']) : '' ?></div><?php endif; ?></td>
                    <td><?= badge($l['statut_livraison']) ?></td>
                    <td class="actions">
                        <?php if (is_gerant() && $l['statut_livraison'] === 'En attente de livreur'): ?>
                            <button class="btn btn-secondary btn-sm" data-open="dlgAffecter" data-fill='<?= e(json_encode(['id_livraison' => $l['id_livraison'], 'num' => $l['numero_commande']])) ?>'<?= $libres ? '' : ' disabled title="Aucun livreur libre"' ?>><?= icon('user', 14) ?> Affecter</button>
                        <?php elseif (is_gerant() && $l['statut_livraison'] === 'Échouée'): ?>
                            <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="reprogrammer"><input type="hidden" name="id_livraison" value="<?= $l['id_livraison'] ?>">
                                <button class="btn btn-secondary btn-sm" type="submit"><?= icon('refresh', 14) ?> Reprogrammer</button></form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?></tbody>
        </table></div>
        <?php else: echo empty_state('Aucune livraison ici', $onglet === 'attente' ? 'Toutes les livraisons ont un livreur.' : '', 'truck'); endif; ?>
    </div>

    <div class="card">
        <div class="card-header"><h2><?= icon('users') ?> Livreurs</h2><span class="chip"><?= count($libres) ?> libre<?= count($libres) > 1 ? 's' : '' ?></span></div>
        <?php if ($livreurs): ?>
        <div class="list"><?php foreach ($livreurs as $lv): ?>
            <div class="list-item">
                <span class="avatar avatar-soft"><?= e(initials($lv['nom_employe'], $lv['prenom_employe'])) ?></span>
                <div class="grow"><div class="cell-main"><?= e(full_name($lv['nom_employe'], $lv['prenom_employe'])) ?></div>
                    <div class="cell-sub"><?= is_admin() ? e($lv['nom_agence']) . ' · ' : '' ?><?= (int) $lv['nb_livrees'] ?> livrée(s) · <?= e($lv['telephone_employe']) ?></div></div>
                <?php if (is_gerant() && $lv['disponibilite_livreur'] !== 'Occupé'): ?>
                    <form method="post" title="Changer la disponibilité"><?= csrf_field() ?><input type="hidden" name="action" value="dispo"><input type="hidden" name="id_employe" value="<?= $lv['id_employe'] ?>">
                        <input type="hidden" name="disponibilite" value="<?= $lv['disponibilite_livreur'] === 'Libre' ? 'Hors service' : 'Libre' ?>">
                        <button class="btn btn-ghost btn-sm" type="submit" style="padding:0 4px"><?= badge($lv['disponibilite_livreur']) ?></button></form>
                <?php else: ?><?= badge($lv['disponibilite_livreur']) ?><?php endif; ?>
            </div>
        <?php endforeach; ?></div>
        <div class="card-footer small muted">Un livreur qui redevient libre reçoit automatiquement la livraison en attente la plus ancienne (RG64).</div>
        <?php else: echo empty_state('Aucun livreur actif', '', 'users'); endif; ?>
    </div>
</div>

<?php if (is_gerant()): ?>
<dialog class="modal" id="dlgAffecter">
    <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="affecter"><input type="hidden" name="id_livraison">
        <div class="modal-header"><h3><?= icon('truck') ?> Affecter la livraison <span class="ref" data-text="num"></span></h3><button class="icon-btn" data-close><?= icon('x') ?></button></div>
        <div class="modal-body stack">
            <p class="text-2">Seuls les livreurs libres de l'agence peuvent recevoir une livraison (RG65).</p>
            <div class="choices" style="grid-template-columns:1fr">
                <?php foreach ($libres as $i => $lv): ?>
                    <label class="choice"><input type="radio" name="id_employe" value="<?= $lv['id_employe'] ?>"<?= $i === 0 ? ' checked' : '' ?>>
                        <span class="choice-card" style="align-items:center"><span class="avatar avatar-soft" style="width:32px;height:32px"><?= e(initials($lv['nom_employe'], $lv['prenom_employe'])) ?></span>
                            <span><strong><?= e(full_name($lv['nom_employe'], $lv['prenom_employe'])) ?></strong><small><?= e($lv['telephone_employe']) ?></small></span></span></label>
                <?php endforeach; ?>
            </div>
        </div>
        <div class="modal-footer"><button class="btn btn-ghost" data-close>Annuler</button><button class="btn btn-primary" type="submit"><?= icon('check') ?> Affecter</button></div>
    </form>
</dialog>
<?php endif; ?>
