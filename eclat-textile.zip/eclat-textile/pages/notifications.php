<?php
/**
 * Notifications SMS / WhatsApp (RG84 à RG88).
 * L'envoi réel dépend de la plateforme de messagerie ; ici l'envoi est simulé
 * pour faire avancer le statut (« En attente » → « Envoyée »).
 */
$title = 'Notifications';
$agence = is_gerant() ? my_agence() : (int) get('agence', 0);
$statut = in_array(get('statut'), ['En attente', 'Envoyée', 'Échouée'], true) ? get('statut') : '';

$scope = $agence ? ' AND (c.id_agence = ' . (int) $agence . ' OR (n.id_commande IS NULL AND cl.id_agence = ' . (int) $agence . '))' : '';
$from = ' FROM notification n JOIN client cl ON cl.id_client = n.id_client LEFT JOIN commande c ON c.id_commande = n.id_commande WHERE 1=1' . $scope;

if (is_post()) {
    csrf_check();
    $idn = (int) post('id_notification');
    $sql = "UPDATE notification n JOIN client cl ON cl.id_client = n.id_client LEFT JOIN commande c ON c.id_commande = n.id_commande
               SET n.statut_envoi = 'Envoyée', n.resultat = 'Envoi simulé depuis l''application', n.date_notification = NOW()
             WHERE n.statut_envoi <> 'Envoyée'" . $scope . ($idn ? ' AND n.id_notification = ' . $idn : '');
    $n = q($sql)->rowCount();
    flash('success', $n . ' notification(s) marquée(s) comme envoyée(s).');
    redirect('notifications', array_filter(['statut' => $statut, 'agence' => is_admin() ? $agence : null]));
}

$counts = [];
foreach (rows('SELECT n.statut_envoi s, COUNT(*) k' . $from . ' GROUP BY n.statut_envoi') as $r) $counts[$r['s']] = (int) $r['k'];
$params = [];
$w = '';
if ($statut) { $w = ' AND n.statut_envoi = ?'; $params[] = $statut; }
$pg = paginate((int) val('SELECT COUNT(*)' . $from . $w, $params), 25);
$list = rows('SELECT n.*, cl.nom_client, cl.prenom_client, cl.telephone_client, c.numero_commande' . $from . $w
    . ' ORDER BY n.id_notification DESC LIMIT ' . $pg['limit'] . ' OFFSET ' . $pg['offset'], $params);
$typeIcon = ['Dépôt' => 'receipt', 'Paiement' => 'wallet', 'Code de validation' => 'qr', 'Disponibilité' => 'check-circle',
    'Rappel de retrait' => 'clock', 'Affectation livreur' => 'truck', 'Livraison' => 'package'];

$actions = ($counts['En attente'] ?? 0) ? '<form method="post">' . csrf_field() . '<button class="btn btn-primary" type="submit">' . icon('send') . ' Envoyer les ' . $counts['En attente'] . ' en attente</button></form>' : '';
echo page_header('Notifications', 'Avis envoyés aux clients par WhatsApp ou SMS', $actions);
?>
<div class="card card-flush">
    <div class="toolbar">
        <div class="segmented">
            <?php foreach (['' => 'Toutes', 'En attente' => 'En attente', 'Envoyée' => 'Envoyées', 'Échouée' => 'Échouées'] as $k => $lbl): ?>
                <a class="<?= $statut === $k ? 'active' : '' ?>" href="<?= e(url('notifications', array_filter(['statut' => $k, 'agence' => is_admin() ? $agence : null]))) ?>"><?= e($lbl) ?>
                    <span class="count"><?= $k === '' ? array_sum($counts) : ($counts[$k] ?? 0) ?></span></a>
            <?php endforeach; ?>
        </div>
        <?php if (is_admin()): ?>
            <form method="get" style="margin-left:auto"><input type="hidden" name="p" value="notifications"><input type="hidden" name="statut" value="<?= e($statut) ?>">
                <select class="select" name="agence" onchange="this.form.submit()"><option value="0">Toutes les agences</option>
                    <?php foreach (agences() as $ag): ?><option value="<?= $ag['id_agence'] ?>"<?= selected($agence, $ag['id_agence']) ?>><?= e($ag['nom_agence']) ?></option><?php endforeach; ?></select></form>
        <?php endif; ?>
    </div>
    <?php if ($list): ?>
    <div class="list">
        <?php foreach ($list as $n): ?>
            <div class="list-item" style="align-items:flex-start">
                <span class="kpi-icon tone-<?= $n['statut_envoi'] === 'Envoyée' ? 'good' : ($n['statut_envoi'] === 'Échouée' ? 'critical' : 'info') ?>" style="width:38px;height:38px"><?= icon($typeIcon[$n['type_notification']] ?? 'bell', 17) ?></span>
                <div class="grow">
                    <div class="row-wrap" style="gap:8px"><strong><?= e($n['type_notification']) ?></strong>
                        <span class="chip"><?= e($n['canal']) ?></span>
                        <span class="muted small"><?= e(full_name($n['nom_client'], $n['prenom_client'])) ?> · <?= e($n['telephone_client']) ?></span>
                        <?php if ($n['numero_commande']): ?><a href="<?= e(url('commande', ['id' => $n['id_commande']])) ?>"><span class="ref"><?= e($n['numero_commande']) ?></span></a><?php endif; ?></div>
                    <div class="text-2 mt-1" style="max-width:760px"><?= e(preg_replace('/\b\d{6}\b/', '••••••', $n['contenu'])) ?></div>
                    <div class="cell-sub mt-1"><?= e(dt($n['date_notification'])) ?><?= $n['resultat'] ? ' · ' . e($n['resultat']) : '' ?></div>
                </div>
                <div class="row" style="gap:8px">
                    <?= badge($n['statut_envoi']) ?>
                    <?php if ($n['statut_envoi'] !== 'Envoyée'): ?>
                        <form method="post"><?= csrf_field() ?><input type="hidden" name="id_notification" value="<?= $n['id_notification'] ?>">
                            <button class="btn btn-ghost btn-sm" type="submit" title="Simuler l'envoi"><?= icon('send', 14) ?></button></form>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    <?= pagination_links($pg) ?>
    <?php else: echo empty_state('Aucune notification', '', 'bell'); endif; ?>
</div>
