<?php
/** Catalogue commun au réseau : catégories, articles (natures de vêtements) et suppléments (RG22, RG41). */
$title = 'Catalogue';
if (is_post()) {
    csrf_check();
    try {
        switch (post('action')) {
            case 'categorie':
                if (post('id')) {
                    q('UPDATE categorie_article SET libelle_categorie = ?, description_categorie = ? WHERE id_categorie = ?', [post('libelle'), nullable(post('description')), (int) post('id')]);
                } else {
                    q('INSERT INTO categorie_article (libelle_categorie, description_categorie) VALUES (?, ?)', [post('libelle'), nullable(post('description'))]);
                }
                flash('success', 'Catégorie enregistrée. Pensez à définir son tarif dans chaque agence.');
                break;
            case 'article':
                if (post('id')) {
                    q('UPDATE article SET libelle_article = ?, id_categorie = ? WHERE id_article = ?', [post('libelle'), (int) post('id_categorie'), (int) post('id')]);
                } else {
                    q('INSERT INTO article (libelle_article, id_categorie) VALUES (?, ?)', [post('libelle'), (int) post('id_categorie')]);
                }
                flash('success', 'Article enregistré.');
                break;
            case 'supplement':
                $portee = post('portee') === 'Commande' ? 'Commande' : 'Vêtement';
                if (post('id') && val('SELECT libelle_supplement FROM supplement WHERE id_supplement = ?', [(int) post('id')]) === 'Livraison à domicile'
                    && (post('libelle') !== 'Livraison à domicile' || $portee !== 'Commande')) {
                    throw new RuntimeException('« Livraison à domicile » est ajouté automatiquement par la base (RG45) : son libellé et sa portée ne se modifient pas.');
                }
                if (post('id')) {
                    q('UPDATE supplement SET libelle_supplement = ?, description_supplement = ?, portee_supplement = ? WHERE id_supplement = ?', [post('libelle'), nullable(post('description')), $portee, (int) post('id')]);
                } else {
                    q('INSERT INTO supplement (libelle_supplement, description_supplement, portee_supplement) VALUES (?, ?, ?)', [post('libelle'), nullable(post('description')), $portee]);
                }
                flash('success', 'Supplément enregistré.');
                break;
        }
    } catch (Throwable $ex) {
        flash('error', db_error($ex));
    }
    redirect('catalogue');
}
$cats = rows('SELECT ca.*, (SELECT COUNT(*) FROM article a WHERE a.id_categorie = ca.id_categorie) nb FROM categorie_article ca ORDER BY libelle_categorie');
$arts = rows('SELECT a.*, ca.libelle_categorie, (SELECT COUNT(*) FROM vetement v WHERE v.id_article = a.id_article) nb FROM article a JOIN categorie_article ca ON ca.id_categorie = a.id_categorie ORDER BY ca.libelle_categorie, a.libelle_article');
$sups = rows('SELECT * FROM supplement ORDER BY portee_supplement DESC, libelle_supplement');
echo page_header('Catalogue', 'Commun à toutes les agences ; chaque agence fixe ses propres prix', '<a class="btn btn-secondary" href="' . e(url('tarifs')) . '">' . icon('tag') . ' Tarifs par agence</a>');
?>
<div class="grid grid-3">
    <div class="card">
        <div class="card-header"><h2><?= icon('layers') ?> Catégories</h2><button class="btn btn-primary btn-sm" data-open="dlgCat" data-fill='{"id":"","libelle":"","description":""}'><?= icon('plus', 14) ?></button></div>
        <div class="list"><?php foreach ($cats as $c): ?>
            <div class="list-item"><div class="grow"><div class="cell-main"><?= e($c['libelle_categorie']) ?></div><div class="cell-sub"><?= e($c['description_categorie'] ?: '—') ?> · <?= (int) $c['nb'] ?> article(s)</div></div>
                <button class="icon-btn" data-open="dlgCat" data-fill='<?= e(json_encode(['id' => $c['id_categorie'], 'libelle' => $c['libelle_categorie'], 'description' => $c['description_categorie'] ?? ''])) ?>' title="Modifier"><?= icon('edit', 15) ?></button></div>
        <?php endforeach; ?></div>
    </div>
    <div class="card">
        <div class="card-header"><h2><?= icon('shirt') ?> Articles</h2><button class="btn btn-primary btn-sm" data-open="dlgArt" data-fill='{"id":"","libelle":""}'><?= icon('plus', 14) ?></button></div>
        <div style="padding:12px 16px 0"><div class="input-group"><?= icon('search', 15) ?><input class="input" data-filter="#listeArticles" placeholder="Filtrer…" style="height:36px"></div></div>
        <div class="list" id="listeArticles" style="max-height:560px;overflow:auto"><?php foreach ($arts as $a): ?>
            <div class="list-item" data-search="<?= e($a['libelle_article'] . ' ' . $a['libelle_categorie']) ?>"><div class="grow"><div class="cell-main"><?= e($a['libelle_article']) ?></div><div class="cell-sub"><?= e($a['libelle_categorie']) ?> · <?= (int) $a['nb'] ?> déposé(s)</div></div>
                <button class="icon-btn" data-open="dlgArt" data-fill='<?= e(json_encode(['id' => $a['id_article'], 'libelle' => $a['libelle_article'], 'id_categorie' => $a['id_categorie']])) ?>' title="Modifier"><?= icon('edit', 15) ?></button></div>
        <?php endforeach; ?></div>
    </div>
    <div class="card">
        <div class="card-header"><h2><?= icon('sparkles') ?> Suppléments</h2><button class="btn btn-primary btn-sm" data-open="dlgSup" data-fill='{"id":"","libelle":"","description":""}'><?= icon('plus', 14) ?></button></div>
        <div class="list"><?php foreach ($sups as $s): ?>
            <div class="list-item"><div class="grow"><div class="cell-main"><?= e($s['libelle_supplement']) ?></div><div class="cell-sub"><?= e($s['description_supplement'] ?: '—') ?></div></div>
                <span class="chip"><?= e($s['portee_supplement']) ?></span>
                <button class="icon-btn" data-open="dlgSup" data-fill='<?= e(json_encode(['id' => $s['id_supplement'], 'libelle' => $s['libelle_supplement'], 'description' => $s['description_supplement'] ?? '', 'portee' => $s['portee_supplement']])) ?>' title="Modifier"><?= icon('edit', 15) ?></button></div>
        <?php endforeach; ?></div>
    </div>
</div>

<?php
$dlg = function (string $id, string $titre, string $action, string $champs) {
    return '<dialog class="modal" id="' . $id . '"><form method="post">' . csrf_field() . '<input type="hidden" name="action" value="' . $action . '"><input type="hidden" name="id">'
        . '<div class="modal-header"><h3>' . e($titre) . '</h3><button class="icon-btn" data-close>' . icon('x') . '</button></div>'
        . '<div class="modal-body stack">' . $champs . '</div>'
        . '<div class="modal-footer"><button class="btn btn-ghost" data-close>Annuler</button><button class="btn btn-primary" type="submit">' . icon('check') . ' Enregistrer</button></div></form></dialog>';
};
$opts = implode('', array_map(fn($c) => '<option value="' . $c['id_categorie'] . '">' . e($c['libelle_categorie']) . '</option>', $cats));
echo $dlg('dlgCat', 'Catégorie', 'categorie',
    '<div class="field"><label class="req">Libellé</label><input class="input" name="libelle" required maxlength="60"></div>'
    . '<div class="field"><label>Description</label><input class="input" name="description" maxlength="255"></div>');
echo $dlg('dlgArt', 'Article', 'article',
    '<div class="field"><label class="req">Nature du vêtement</label><input class="input" name="libelle" required maxlength="60" placeholder="Chemise, veste, drap…"></div>'
    . '<div class="field"><label class="req">Catégorie</label><select class="select" name="id_categorie" required>' . $opts . '</select></div>');
echo $dlg('dlgSup', 'Supplément', 'supplement',
    '<div class="field"><label class="req">Libellé</label><input class="input" name="libelle" required maxlength="60"></div>'
    . '<div class="field"><label>Description</label><input class="input" name="description" maxlength="255"></div>'
    . '<div class="field"><label class="req">Portée</label><select class="select" name="portee"><option value="Vêtement">Par vêtement</option><option value="Commande">Par commande</option></select></div>');
