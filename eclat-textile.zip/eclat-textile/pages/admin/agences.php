<?php
/** Agences du réseau (RG01 à RG06). */
$title = 'Agences';
$list = rows("SELECT a.*, t.chiffre_affaires, t.commandes_en_cours, t.incidents_ouverts,
                     (SELECT COUNT(*) FROM client c WHERE c.id_agence = a.id_agence) nb_clients,
                     (SELECT COUNT(*) FROM employe e WHERE e.id_agence = a.id_agence AND e.statut_compte = 'Actif') nb_employes,
                     (SELECT GROUP_CONCAT(CONCAT(COALESCE(e.prenom_employe,''), ' ', e.nom_employe) SEPARATOR ', ') FROM employe e JOIN role r ON r.id_role = e.id_role
                       WHERE e.id_agence = a.id_agence AND r.libelle_role = 'Gérant' AND e.statut_compte = 'Actif') gerants
                FROM agence a JOIN v_tableau_bord_agence t ON t.id_agence = a.id_agence ORDER BY a.statut_agence, a.nom_agence");
echo page_header('Agences', count($list) . ' agence(s) dans le réseau', '<a class="btn btn-primary" href="' . e(url('agence')) . '">' . icon('plus') . ' Nouvelle agence</a>');
?>
<?php if ($list): ?>
<div class="grid grid-3">
    <?php foreach ($list as $a): ?>
        <div class="card agency-card"<?= $a['statut_agence'] === 'Inactive' ? ' style="opacity:.7"' : '' ?>>
            <div class="card-body stack">
                <div class="agency-head">
                    <span class="agency-logo"><?= e(mb_strtoupper(mb_substr($a['nom_agence'], 0, 2))) ?></span>
                    <div class="grow"><h3 style="font-size:17px"><?= e($a['nom_agence']) ?></h3>
                        <div class="cell-sub"><?= e($a['ville_agence']) ?> · <?= e($a['telephone_agence']) ?></div></div>
                    <?= badge($a['statut_agence']) ?>
                </div>
                <div class="small text-2 row" style="gap:6px;align-items:flex-start"><?= icon('pin', 14) ?> <?= e($a['adresse_agence']) ?></div>
                <div class="small text-2 row" style="gap:6px"><?= icon('user', 14) ?> <?= $a['gerants'] ? e($a['gerants']) : '<span style="color:var(--warning)">Aucun gérant actif</span>' ?></div>
                <div class="stat-inline">
                    <div><strong><?= money($a['chiffre_affaires'], false) ?></strong><span>FCFA encaissés</span></div>
                    <div><strong><?= (int) $a['commandes_en_cours'] ?></strong><span>en cours</span></div>
                    <div><strong><?= (int) $a['nb_clients'] ?></strong><span>clients</span></div>
                    <div><strong><?= (int) $a['nb_employes'] ?></strong><span>employés</span></div>
                </div>
                <div class="row-wrap" style="gap:6px">
                    <span class="chip"><?= icon('clock', 13) ?> <?= (int) $a['duree_normal_h'] ?> h / <?= (int) $a['duree_express_h'] ?> h express</span>
                    <span class="chip"><?= icon('scale', 13) ?> <?= money($a['tarif_kg']) ?>/kg dès <?= num($a['seuil_poids_kg'], 1) ?> kg</span>
                    <span class="chip"><?= icon('gift', 13) ?> <?= num($a['taux_fidelite'], 0) ?> % après <?= (int) $a['seuil_fidelite'] ?></span>
                </div>
            </div>
            <div class="card-footer row between">
                <a class="btn btn-ghost btn-sm" href="<?= e(url('tarifs', ['agence' => $a['id_agence']])) ?>"><?= icon('tag', 14) ?> Tarifs</a>
                <a class="btn btn-secondary btn-sm" href="<?= e(url('agence', ['id' => $a['id_agence']])) ?>"><?= icon('sliders', 14) ?> Configurer</a>
            </div>
        </div>
    <?php endforeach; ?>
</div>
<?php else: ?>
    <div class="card"><?= empty_state('Aucune agence', 'Créez la première agence du réseau.', 'store', '<a class="btn btn-primary" href="' . e(url('agence')) . '">' . icon('plus') . ' Nouvelle agence</a>') ?></div>
<?php endif; ?>
