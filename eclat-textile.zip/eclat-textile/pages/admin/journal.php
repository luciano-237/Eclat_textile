<?php
/** Journal des actions, en lecture seule (RG89 à RG91). */
$title = 'Journal des actions';
$type = in_array(get('type'), ['Création', 'Modification', 'Suppression', 'Annulation', 'Connexion', 'Autre'], true) ? get('type') : '';
$where = []; $params = [];
if (is_gerant()) { $where[] = 'e.id_agence = ?'; $params[] = my_agence(); }
if ($type) { $where[] = 'j.type_action = ?'; $params[] = $type; }
if (get('q')) { $where[] = '(j.detail_action LIKE ? OR j.entite_concernee LIKE ?)'; array_push($params, '%' . get('q') . '%', '%' . get('q') . '%'); }
$w = $where ? ' WHERE ' . implode(' AND ', $where) : '';
$from = ' FROM journal_action j JOIN employe e ON e.id_employe = j.id_employe JOIN role r ON r.id_role = e.id_role';
$pg = paginate((int) val('SELECT COUNT(*)' . $from . $w, $params), 30);
$list = rows('SELECT j.*, e.nom_employe, e.prenom_employe, r.libelle_role' . $from . $w . ' ORDER BY j.id_action DESC LIMIT ' . $pg['limit'] . ' OFFSET ' . $pg['offset'], $params);
$tone = ['Création' => 'good', 'Modification' => 'info', 'Suppression' => 'critical', 'Annulation' => 'critical', 'Connexion' => 'neutral', 'Autre' => 'neutral'];

echo page_header('Journal des actions', 'Trace des opérations sensibles — ni modifiable, ni supprimable (RG91)');
?>
<div class="card card-flush">
    <form class="toolbar" method="get">
        <input type="hidden" name="p" value="journal">
        <div class="input-group"><?= icon('search', 16) ?><input class="input" type="search" name="q" value="<?= e(get('q')) ?>" placeholder="Rechercher dans le détail"></div>
        <select class="select" name="type" style="width:auto" onchange="this.form.submit()">
            <option value="">Tous les types</option>
            <?php foreach (array_keys($tone) as $t): ?><option<?= selected($type, $t) ?>><?= e($t) ?></option><?php endforeach; ?>
        </select>
        <span class="muted small" style="margin-left:auto"><?= num($pg['total']) ?> entrées</span>
    </form>
    <?php if ($list): ?>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Date</th><th>Action</th><th>Objet</th><th>Détail</th><th>Auteur</th></tr></thead>
        <tbody><?php foreach ($list as $j): ?>
            <tr><td class="nowrap text-2"><?= e(dt($j['date_action'])) ?></td>
                <td><?= badge($j['type_action'], $tone[$j['type_action']]) ?></td>
                <td><span class="mono small"><?= e($j['entite_concernee']) ?> #<?= (int) $j['id_entite'] ?></span></td>
                <td class="text-2" style="max-width:420px"><?= e($j['detail_action']) ?></td>
                <td><div class="cell-main"><?= e(full_name($j['nom_employe'], $j['prenom_employe'])) ?></div><div class="cell-sub"><?= e($j['libelle_role']) ?></div></td></tr>
        <?php endforeach; ?></tbody>
    </table></div>
    <?= pagination_links($pg) ?>
    <?php else: echo empty_state('Journal vide', '', 'history'); endif; ?>
</div>
