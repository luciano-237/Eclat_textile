<?php
/** Tarifs des catégories et des suppléments, propres à chaque agence (RG23 à RG25, RG41, RG42). */
$title = 'Tarifs';
$liste = agences();
if (!$liste) {
    flash('info', 'Créez d\'abord une agence.');
    redirect('agence');
}
$idA = (int) get('agence', $liste[0]['id_agence']);
$ag = row('SELECT * FROM agence WHERE id_agence = ?', [$idA]) ?? $liste[0];
$idA = (int) $ag['id_agence'];

$cats = rows('SELECT ca.*, t.prix_categorie, t.unite_facturation, t.actif_tarif,
                     (SELECT GROUP_CONCAT(a.libelle_article ORDER BY a.libelle_article SEPARATOR \', \') FROM article a WHERE a.id_categorie = ca.id_categorie) articles
                FROM categorie_article ca LEFT JOIN tarif_categorie t ON t.id_categorie = ca.id_categorie AND t.id_agence = ?
               ORDER BY ca.libelle_categorie', [$idA]);
$sups = rows('SELECT s.*, t.prix_supplement, t.actif_supplement FROM supplement s
                LEFT JOIN tarif_supplement t ON t.id_supplement = s.id_supplement AND t.id_agence = ? ORDER BY s.portee_supplement DESC, s.libelle_supplement', [$idA]);

if (is_post()) {
    csrf_check();
    try {
        $n = transaction(function () use ($idA, $cats, $sups) {
            $n = 0;
            foreach ($cats as $c) {
                $k = $c['id_categorie'];
                $prix = (float) ($_POST['prix_cat'][$k] ?? 0);
                $actif = isset($_POST['actif_cat'][$k]) ? 1 : 0;
                $unite = ($_POST['unite'][$k] ?? 'Pièce') === 'Poids' ? 'Poids' : 'Pièce';
                if ($c['prix_categorie'] === null) {
                    if ($actif && $prix > 0) {
                        q('INSERT INTO tarif_categorie (id_agence, id_categorie, prix_categorie, unite_facturation, actif_tarif) VALUES (?, ?, ?, ?, 1)', [$idA, $k, $prix, $unite]);
                        $n++;
                    }
                } elseif ((float) $c['prix_categorie'] !== $prix || $c['unite_facturation'] !== $unite || (int) $c['actif_tarif'] !== $actif) {
                    q('UPDATE tarif_categorie SET prix_categorie = ?, unite_facturation = ?, actif_tarif = ? WHERE id_agence = ? AND id_categorie = ?', [$prix, $unite, $actif, $idA, $k]);
                    $n++;
                }
            }
            foreach ($sups as $s) {
                $k = $s['id_supplement'];
                $prix = (float) ($_POST['prix_sup'][$k] ?? 0);
                $actif = isset($_POST['actif_sup'][$k]) ? 1 : 0;
                if ($s['prix_supplement'] === null) {
                    if ($actif) {
                        q('INSERT INTO tarif_supplement (id_agence, id_supplement, prix_supplement, actif_supplement) VALUES (?, ?, ?, 1)', [$idA, $k, $prix]);
                        $n++;
                    }
                } elseif ((float) $s['prix_supplement'] !== $prix || (int) $s['actif_supplement'] !== $actif) {
                    q('UPDATE tarif_supplement SET prix_supplement = ?, actif_supplement = ? WHERE id_agence = ? AND id_supplement = ?', [$prix, $actif, $idA, $k]);
                    $n++;
                }
            }
            return $n;
        });
        flash('success', $n ? "$n tarif(s) mis à jour. Les commandes déjà enregistrées ne changent pas (RG38)." : 'Aucune modification.');
    } catch (Throwable $ex) {
        flash('error', db_error($ex));
    }
    redirect('tarifs', ['agence' => $idA]);
}

echo page_header('Tarifs', 'Prix à la pièce calculés pour l\'état le plus sale (RG24) · les modifications sont journalisées');
?>
<div class="segmented mb-2">
    <?php foreach ($liste as $l): ?>
        <a class="<?= (int) $l['id_agence'] === $idA ? 'active' : '' ?>" href="<?= e(url('tarifs', ['agence' => $l['id_agence']])) ?>"><?= icon('store', 14) ?> <?= e($l['nom_agence']) ?></a>
    <?php endforeach; ?>
</div>
<form method="post" class="stack">
    <?= csrf_field() ?>
    <div class="card card-flush">
        <div class="card-header"><h2><?= icon('layers') ?> Catégories d'articles</h2><a class="btn btn-ghost btn-sm" href="<?= e(url('catalogue')) ?>">Gérer le catalogue</a></div>
        <div class="table-wrap"><table class="table">
            <thead><tr><th style="width:70px">Proposée</th><th>Catégorie</th><th style="width:190px">Facturation</th><th style="width:200px">Prix à la pièce</th></tr></thead>
            <tbody><?php foreach ($cats as $c): $k = $c['id_categorie']; ?>
                <tr>
                    <td><label class="check"><input type="checkbox" name="actif_cat[<?= $k ?>]" value="1"<?= checked($c['actif_tarif'] ?? false) ?>></label></td>
                    <td><div class="cell-main"><?= e($c['libelle_categorie']) ?></div><div class="cell-sub"><?= e($c['articles'] ?: 'Aucun article') ?></div></td>
                    <td><select class="select" name="unite[<?= $k ?>]"><option value="Pièce"<?= selected($c['unite_facturation'], 'Pièce') ?>>À la pièce</option><option value="Poids"<?= selected($c['unite_facturation'], 'Poids') ?>>Au poids (lot)</option></select></td>
                    <td><div class="input-group"><input class="input has-suffix" type="number" min="1" step="50" name="prix_cat[<?= $k ?>]" value="<?= $c['prix_categorie'] !== null ? (int) $c['prix_categorie'] : '' ?>" placeholder="0"><span class="suffix">FCFA</span></div></td>
                </tr>
            <?php endforeach; ?></tbody>
        </table></div>
        <div class="card-footer small muted">Les articles d'une catégorie « au poids » rejoignent le lot : <?= money($ag['tarif_kg']) ?>/kg à partir de <?= num($ag['seuil_poids_kg'], 1) ?> kg, sinon <?= money($ag['prix_piece_hors_categorie']) ?> la pièce (configuration de l'agence).</div>
    </div>
    <div class="card card-flush">
        <div class="card-header"><h2><?= icon('sparkles') ?> Suppléments</h2></div>
        <div class="table-wrap"><table class="table">
            <thead><tr><th style="width:70px">Proposé</th><th>Supplément</th><th>Portée</th><th style="width:200px">Prix</th></tr></thead>
            <tbody><?php foreach ($sups as $s): $k = $s['id_supplement']; ?>
                <tr>
                    <td><label class="check"><input type="checkbox" name="actif_sup[<?= $k ?>]" value="1"<?= checked($s['actif_supplement'] ?? false) ?>></label></td>
                    <td><div class="cell-main"><?= e($s['libelle_supplement']) ?></div><div class="cell-sub"><?= e($s['description_supplement']) ?></div></td>
                    <td><span class="chip"><?= e($s['portee_supplement'] === 'Vêtement' ? 'Par vêtement' : 'Par commande') ?></span></td>
                    <td><div class="input-group"><input class="input has-suffix" type="number" min="0" step="50" name="prix_sup[<?= $k ?>]" value="<?= $s['prix_supplement'] !== null ? (int) $s['prix_supplement'] : '' ?>" placeholder="0"><span class="suffix">FCFA</span></div></td>
                </tr>
            <?php endforeach; ?></tbody>
        </table></div>
    </div>
    <div class="row" style="justify-content:flex-end"><button class="btn btn-primary btn-lg" type="submit"><?= icon('check') ?> Enregistrer les tarifs de <?= e($ag['nom_agence']) ?></button></div>
</form>
