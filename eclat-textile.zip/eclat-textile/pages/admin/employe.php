<?php
/** Création / modification d'un compte employé (RG07 à RG15). Mot de passe stocké sous forme d'empreinte. */
$id = (int) get('id');
$e = $id ? row('SELECT e.*, r.libelle_role FROM employe e JOIN role r ON r.id_role = e.id_role WHERE e.id_employe = ?', [$id]) : null;
if ($id && !$e) {
    flash('error', 'Employé introuvable.');
    redirect('employes');
}
$title = $e ? full_name($e['nom_employe'], $e['prenom_employe']) : 'Nouvel employé';
$roles = rows('SELECT * FROM role ORDER BY id_role');

if (is_post()) {
    csrf_check();
    try {
        if (post('action') === 'statut' && $e) {
            if ($id === my_id()) throw new RuntimeException('Vous ne pouvez pas suspendre votre propre compte.');
            $nv = $e['statut_compte'] === 'Actif' ? 'Suspendu' : 'Actif';
            q('UPDATE employe SET statut_compte = ? WHERE id_employe = ?', [$nv, $id]);
            q("INSERT INTO journal_action (type_action, entite_concernee, id_entite, detail_action, id_employe) VALUES ('Modification', 'employe', ?, ?, ?)",
                [$id, 'Compte ' . ($nv === 'Actif' ? 'réactivé' : 'suspendu'), my_id()]);
            flash('success', $nv === 'Actif' ? 'Compte réactivé.' : 'Compte suspendu : la connexion est bloquée (RG13).');
            redirect('employe', ['id' => $id]);
        }
        $idRole = (int) post('id_role');
        $libRole = val('SELECT libelle_role FROM role WHERE id_role = ?', [$idRole]);
        $idAg = $libRole === 'Administrateur' ? null : ((int) post('id_agence') ?: null);
        $pw = (string) ($_POST['mot_de_passe'] ?? '');
        if (!filter_var(post('email_employe'), FILTER_VALIDATE_EMAIL)) throw new RuntimeException('Adresse e-mail invalide.');
        if ((!$e || $pw !== '') && mb_strlen($pw) < 8) throw new RuntimeException('Le mot de passe doit contenir au moins 8 caractères.');
        if ($e && $id === my_id() && $libRole !== 'Administrateur') throw new RuntimeException('Vous ne pouvez pas retirer votre propre rôle d\'administrateur.');
        $dispo = $libRole === 'Livreur' ? (in_array(post('disponibilite_livreur'), ['Libre', 'Occupé', 'Hors service'], true) ? post('disponibilite_livreur') : 'Libre') : null;
        $data = [post('nom_employe'), nullable(post('prenom_employe')), post('telephone_employe'), post('email_employe'), nullable(post('date_embauche')), $dispo, $idRole, $idAg];
        if ($e) {
            q('UPDATE employe SET nom_employe = ?, prenom_employe = ?, telephone_employe = ?, email_employe = ?, date_embauche = ?, disponibilite_livreur = ?, id_role = ?, id_agence = ? WHERE id_employe = ?', [...$data, $id]);
            if ($pw !== '') q('UPDATE employe SET mot_de_passe = ? WHERE id_employe = ?', [password_hash($pw, PASSWORD_DEFAULT), $id]);
            q("INSERT INTO journal_action (type_action, entite_concernee, id_entite, detail_action, id_employe) VALUES ('Modification', 'employe', ?, ?, ?)",
                [$id, 'Modification du compte ' . post('email_employe') . ($pw !== '' ? ' (mot de passe réinitialisé)' : ''), my_id()]);
            flash('success', 'Compte mis à jour.');
        } else {
            q('INSERT INTO employe (nom_employe, prenom_employe, telephone_employe, email_employe, date_embauche, disponibilite_livreur, id_role, id_agence, mot_de_passe) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                [...$data, password_hash($pw, PASSWORD_DEFAULT)]);
            $id = (int) db()->lastInsertId();
            q("INSERT INTO journal_action (type_action, entite_concernee, id_entite, detail_action, id_employe) VALUES ('Création', 'employe', ?, ?, ?)",
                [$id, 'Création du compte ' . post('email_employe') . ' (' . $libRole . ')', my_id()]);
            flash('success', 'Compte créé. Communiquez le mot de passe à l\'employé.');
        }
        redirect('employe', ['id' => $id]);
    } catch (Throwable $ex) {
        flash('error', db_error($ex));
    }
}
$v = fn($k, $d = '') => e($_POST[$k] ?? ($e[$k] ?? $d));
$roleSel = $_POST['id_role'] ?? ($e['id_role'] ?? val("SELECT id_role FROM role WHERE libelle_role = 'Gérant'"));
$agSel = $_POST['id_agence'] ?? ($e['id_agence'] ?? get('agence'));
$actions = '';
if ($e && $id !== my_id()) {
    $act = $e['statut_compte'] === 'Actif';
    $actions = '<form method="post" data-confirm="' . ($act ? 'Suspendre ce compte ?' : 'Réactiver ce compte ?') . '">' . csrf_field() . '<input type="hidden" name="action" value="statut">'
        . '<button class="btn ' . ($act ? 'btn-danger' : 'btn-success') . '" type="submit">' . icon($act ? 'lock' : 'check') . ' ' . ($act ? 'Suspendre le compte' : 'Réactiver le compte') . '</button></form>';
}
echo page_header($title, $e ? badge($e['libelle_role'], 'teal') . ' ' . badge($e['statut_compte']) : 'Un employé a un seul rôle ; gérants et livreurs sont rattachés à une agence (RG08, RG09).', $actions, url('employes'));
?>
<form method="post" class="card" style="max-width:860px">
    <?= csrf_field() ?>
    <div class="card-body stack">
        <div>
            <p class="section-title">Rôle</p>
            <div class="choices">
                <?php $ic = ['Administrateur' => 'shield', 'Gérant' => 'store', 'Livreur' => 'truck'];
                $desc = ['Administrateur' => 'Réseau, tarifs, comptes', 'Gérant' => 'Comptoir d\'une agence', 'Livreur' => 'Livraisons à domicile'];
                foreach ($roles as $r): ?>
                    <label class="choice"><input type="radio" name="id_role" value="<?= $r['id_role'] ?>"<?= checked((string) $roleSel === (string) $r['id_role']) ?>>
                        <span class="choice-card"><span class="choice-icon"><?= icon($ic[$r['libelle_role']]) ?></span><span><strong><?= e($r['libelle_role']) ?></strong><small><?= e($desc[$r['libelle_role']]) ?></small></span></span></label>
                <?php endforeach; ?>
            </div>
        </div>
        <div class="form-grid">
            <?php $idAdmin = val("SELECT id_role FROM role WHERE libelle_role = 'Administrateur'"); $idLiv = val("SELECT id_role FROM role WHERE libelle_role = 'Livreur'"); ?>
            <div class="field" data-show-when="id_role=<?= e(implode('|', array_diff(array_column($roles, 'id_role'), [$idAdmin]))) ?>"><label class="req" for="id_agence">Agence</label>
                <select class="select" id="id_agence" name="id_agence" data-req><option value="">Choisir…</option>
                    <?php foreach (agences() as $a): ?><option value="<?= $a['id_agence'] ?>"<?= selected($agSel, $a['id_agence']) ?>><?= e($a['nom_agence']) ?><?= $a['statut_agence'] === 'Inactive' ? ' (inactive)' : '' ?></option><?php endforeach; ?></select></div>
            <div class="field" data-show-when="id_role=<?= e($idLiv) ?>"><label for="disponibilite_livreur">Disponibilité</label>
                <select class="select" id="disponibilite_livreur" name="disponibilite_livreur">
                    <?php foreach (['Libre', 'Occupé', 'Hors service'] as $d): ?><option<?= selected($_POST['disponibilite_livreur'] ?? ($e['disponibilite_livreur'] ?? 'Libre'), $d) ?>><?= $d ?></option><?php endforeach; ?></select></div>
            <div class="field"><label class="req" for="nom_employe">Nom</label><input class="input" id="nom_employe" name="nom_employe" required maxlength="50" value="<?= $v('nom_employe') ?>"></div>
            <div class="field"><label for="prenom_employe">Prénom</label><input class="input" id="prenom_employe" name="prenom_employe" maxlength="50" value="<?= $v('prenom_employe') ?>"></div>
            <div class="field"><label class="req" for="email_employe">E-mail (identifiant)</label><input class="input" type="email" id="email_employe" name="email_employe" required maxlength="120" value="<?= $v('email_employe') ?>"></div>
            <div class="field"><label class="req" for="telephone_employe">Téléphone</label><input class="input" id="telephone_employe" name="telephone_employe" required maxlength="20" value="<?= $v('telephone_employe') ?>"></div>
            <div class="field"><label for="date_embauche">Date d'embauche</label><input class="input" type="date" id="date_embauche" name="date_embauche" value="<?= $v('date_embauche') ?>"></div>
            <div class="field"><label class="<?= $e ? '' : 'req' ?>" for="mot_de_passe"><?= $e ? 'Nouveau mot de passe' : 'Mot de passe' ?></label>
                <input class="input" type="password" id="mot_de_passe" name="mot_de_passe" minlength="8" autocomplete="new-password"<?= $e ? ' placeholder="Laisser vide pour ne pas changer"' : ' required' ?>></div>
        </div>
    </div>
    <div class="card-footer row" style="justify-content:flex-end"><a class="btn btn-ghost" href="<?= e(url('employes')) ?>">Annuler</a>
        <button class="btn btn-primary" type="submit"><?= icon('check') ?> Enregistrer</button></div>
</form>
