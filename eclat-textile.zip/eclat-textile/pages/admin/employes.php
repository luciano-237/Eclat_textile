<?php
/** Comptes du personnel (RG07 à RG15) et validation des demandes d'inscription. */
$title = 'Employés';
$role = (string) get('role', '');
$agence = (int) get('agence', 0);
$attente = get('vue') === 'attente';

// Validation ou refus rapide d'une demande d'inscription
if (is_post()) {
    csrf_check();
    $id = (int) post('id_employe');
    $dem = row(EMPLOYE_EN_ATTENTE_SQL . ' AND e.id_employe = ?', [$id]);
    try {
        if (!$dem) throw new RuntimeException('Cette demande n\'existe plus ou a déjà été traitée.');
        if (post('decision') === 'valider') {
            q("UPDATE employe SET statut_compte = 'Actif', date_embauche = COALESCE(date_embauche, CURRENT_DATE) WHERE id_employe = ?", [$id]);
            q("INSERT INTO journal_action (type_action, entite_concernee, id_entite, detail_action, id_employe) VALUES ('Modification', 'employe', ?, ?, ?)",
                [$id, 'Inscription validée : ' . $dem['email_employe'], my_id()]);
            flash('success', full_name($dem['nom_employe'], $dem['prenom_employe']) . ' peut maintenant se connecter.');
        } else {
            // Pas de suppression (historique conservé) : la demande reste un compte suspendu, marqué comme refusé.
            q("INSERT INTO journal_action (type_action, entite_concernee, id_entite, detail_action, id_employe) VALUES ('Autre', 'employe', ?, ?, ?)",
                [$id, 'Inscription refusée : ' . $dem['email_employe'], my_id()]);
            flash('info', 'Demande refusée : le compte reste suspendu.');
        }
    } catch (Throwable $ex) {
        flash('error', db_error($ex));
    }
    redirect('employes', $attente ? ['vue' => 'attente'] : []);
}

$where = []; $params = [];
if ($role !== '') { $where[] = 'r.libelle_role = ?'; $params[] = $role; }
if ($agence) { $where[] = 'e.id_agence = ?'; $params[] = $agence; }
$list = rows('SELECT e.*, r.libelle_role, a.nom_agence,
                     (SELECT MAX(date_action) FROM journal_action j WHERE j.id_employe = e.id_employe AND j.type_action = \'Connexion\') derniere_connexion,
                     (e.statut_compte = \'Suspendu\'
                      AND NOT EXISTS (SELECT 1 FROM journal_action j WHERE j.id_employe = e.id_employe AND j.type_action = \'Connexion\')
                      AND EXISTS (SELECT 1 FROM journal_action j WHERE j.id_entite = e.id_employe AND j.entite_concernee = \'employe\' AND j.detail_action LIKE \'Demande d\'\'inscription%\')
                      AND NOT EXISTS (SELECT 1 FROM journal_action j WHERE j.id_entite = e.id_employe AND j.entite_concernee = \'employe\' AND j.detail_action LIKE \'Inscription refusée%\')) en_attente
                FROM employe e JOIN role r ON r.id_role = e.id_role LEFT JOIN agence a ON a.id_agence = e.id_agence'
    . ($where ? ' WHERE ' . implode(' AND ', $where) : '') . ' ORDER BY en_attente DESC, e.statut_compte, r.id_role, a.nom_agence, e.nom_employe', $params);
$nbAttente = count(array_filter($list, fn($e) => $e['en_attente']));
if ($attente) {
    $list = array_values(array_filter($list, fn($e) => $e['en_attente']));
}
$roleTone = ['Administrateur' => 'violet', 'Gérant' => 'teal', 'Livreur' => 'info'];

echo page_header('Employés', count($list) . ' compte(s)', '<a class="btn btn-primary" href="' . e(url('employe')) . '">' . icon('plus') . ' Nouvel employé</a>');
?>
<?php if ($nbAttente && !$attente): ?>
    <div class="alert alert-warning mb-2"><?= icon('user') ?><div><strong><?= $nbAttente ?> demande(s) d'inscription en attente</strong>
        Ces personnes ne peuvent pas se connecter tant que vous n'avez pas validé leur compte. <a href="<?= e(url('employes', ['vue' => 'attente'])) ?>">Voir les demandes</a></div></div>
<?php endif; ?>
<div class="card card-flush">
    <form class="toolbar" method="get">
        <input type="hidden" name="p" value="employes">
        <div class="segmented">
            <?php foreach (['' => 'Tous', 'Gérant' => 'Gérants', 'Livreur' => 'Livreurs', 'Administrateur' => 'Administrateurs'] as $k => $l): ?>
                <a class="<?= !$attente && $role === $k ? 'active' : '' ?>" href="<?= e(url('employes', array_filter(['role' => $k, 'agence' => $agence]))) ?>"><?= e($l) ?></a>
            <?php endforeach; ?>
            <a class="<?= $attente ? 'active' : '' ?>" href="<?= e(url('employes', ['vue' => 'attente'])) ?>">À valider <span class="count"><?= $nbAttente ?></span></a>
        </div>
        <input type="hidden" name="role" value="<?= e($role) ?>">
        <select class="select" name="agence" style="width:auto;margin-left:auto" onchange="this.form.submit()">
            <option value="0">Toutes les agences</option>
            <?php foreach (agences() as $a): ?><option value="<?= $a['id_agence'] ?>"<?= selected($agence, $a['id_agence']) ?>><?= e($a['nom_agence']) ?></option><?php endforeach; ?>
        </select>
    </form>
    <?php if ($list): ?>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Employé</th><th>Rôle</th><th>Agence</th><th>Contact</th><th>Dernière connexion</th><th>Compte</th></tr></thead>
        <tbody><?php foreach ($list as $e): ?>
            <tr class="clickable" data-href="<?= e(url('employe', ['id' => $e['id_employe']])) ?>">
                <td><div class="cell-person"><span class="avatar"><?= e(initials($e['nom_employe'], $e['prenom_employe'])) ?></span>
                    <div><div class="cell-main"><?= e(full_name($e['nom_employe'], $e['prenom_employe'])) ?></div><div class="cell-sub"><?= e($e['email_employe']) ?></div></div></div></td>
                <td><?= badge($e['libelle_role'], $roleTone[$e['libelle_role']]) ?><?php if ($e['disponibilite_livreur']): ?><div class="mt-1"><?= badge($e['disponibilite_livreur']) ?></div><?php endif; ?></td>
                <td class="text-2"><?= e($e['nom_agence'] ?? 'Réseau') ?></td>
                <td class="text-2"><?= e($e['telephone_employe']) ?></td>
                <td class="text-2"><?= $e['derniere_connexion'] ? e(rel_time($e['derniere_connexion'])) : '<span class="muted">Jamais</span>' ?></td>
                <td class="nowrap">
                    <?php if ($e['en_attente']): ?>
                        <div class="row" style="gap:6px">
                            <?= badge('À valider', 'warning') ?>
                            <form method="post" action="<?= e(url('employes', $attente ? ['vue' => 'attente'] : [])) ?>"><?= csrf_field() ?><input type="hidden" name="id_employe" value="<?= $e['id_employe'] ?>">
                                <button class="btn btn-success btn-sm" name="decision" value="valider" type="submit"><?= icon('check', 14) ?> Valider</button></form>
                            <form method="post" action="<?= e(url('employes', $attente ? ['vue' => 'attente'] : [])) ?>" data-confirm="Refuser cette demande d'inscription ?"><?= csrf_field() ?><input type="hidden" name="id_employe" value="<?= $e['id_employe'] ?>">
                                <button class="btn btn-ghost btn-sm" name="decision" value="refuser" type="submit" title="Refuser"><?= icon('x', 14) ?></button></form>
                        </div>
                    <?php else: ?><?= badge($e['statut_compte']) ?><?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?></tbody>
    </table></div>
    <?php else: echo empty_state($attente ? 'Aucune demande en attente' : 'Aucun employé', $attente ? 'Les demandes faites depuis la page « Créer un compte » apparaissent ici.' : '', 'users'); endif; ?>
</div>
