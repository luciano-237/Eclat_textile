<?php
/** Création et configuration d'une agence (RG01 à RG06, RG39). Les changements sont journalisés (RG90). */
$id = (int) get('id');
$a = $id ? row('SELECT * FROM agence WHERE id_agence = ?', [$id]) : null;
if ($id && !$a) {
    flash('error', 'Agence introuvable.');
    redirect('agences');
}
$title = $a ? 'Agence ' . $a['nom_agence'] : 'Nouvelle agence';
$champs = ['nom_agence', 'adresse_agence', 'ville_agence', 'telephone_agence', 'duree_normal_h', 'duree_express_h', 'taux_majoration_express',
    'seuil_poids_kg', 'tarif_kg', 'prix_piece_hors_categorie', 'delai_grace_jours', 'frais_retard_jour', 'seuil_fidelite', 'taux_fidelite'];
$defauts = ['duree_normal_h' => 72, 'duree_express_h' => 24, 'taux_majoration_express' => 30, 'seuil_poids_kg' => 3, 'tarif_kg' => 500,
    'prix_piece_hors_categorie' => 500, 'delai_grace_jours' => 14, 'frais_retard_jour' => 100, 'seuil_fidelite' => 10, 'taux_fidelite' => 3];

if (is_post()) {
    csrf_check();
    try {
        if (post('action') === 'statut' && $a) {
            $nouveau = $a['statut_agence'] === 'Active' ? 'Inactive' : 'Active';
            q('UPDATE agence SET statut_agence = ? WHERE id_agence = ?', [$nouveau, $id]);
            flash('success', $nouveau === 'Active' ? 'Agence réactivée.' : 'Agence désactivée : elle ne peut plus enregistrer de clients ni de commandes (RG06).');
            redirect('agence', ['id' => $id]);
        }
        $vals = [];
        foreach ($champs as $ch) {
            $v = post($ch);
            $vals[] = in_array($ch, ['nom_agence', 'adresse_agence', 'ville_agence', 'telephone_agence'], true) ? $v : (float) str_replace(',', '.', (string) $v);
        }
        if ($a) {
            q('UPDATE agence SET ' . implode(' = ?, ', $champs) . ' = ? WHERE id_agence = ?', [...$vals, $id]);
            flash('success', 'Configuration enregistrée. Les commandes existantes conservent leurs valeurs (RG38).');
        } else {
            q('INSERT INTO agence (' . implode(', ', $champs) . ') VALUES (' . implode(', ', array_fill(0, count($champs), '?')) . ')', $vals);
            $id = (int) db()->lastInsertId();
            q("INSERT INTO journal_action (type_action, entite_concernee, id_entite, detail_action, id_employe) VALUES ('Création', 'agence', ?, ?, ?)",
                [$id, 'Création de l\'agence ' . post('nom_agence'), my_id()]);
            flash('success', 'Agence créée. Définissez maintenant ses tarifs et nommez un gérant.');
            redirect('tarifs', ['agence' => $id]);
        }
        redirect('agence', ['id' => $id]);
    } catch (Throwable $ex) {
        flash('error', db_error($ex));
    }
}
$v = fn($k) => e($_POST[$k] ?? ($a[$k] ?? ($defauts[$k] ?? '')));
$num = fn($k, $step = '1') => '<input class="input" type="number" min="0" step="' . $step . '" id="' . $k . '" name="' . $k . '" required value="' . $v($k) . '">';
$actions = '';
if ($a) {
    $actions = '<a class="btn btn-secondary" href="' . e(url('tarifs', ['agence' => $id])) . '">' . icon('tag') . ' Tarifs</a>'
        . '<form method="post" data-confirm="' . ($a['statut_agence'] === 'Active' ? 'Désactiver cette agence ?' : 'Réactiver cette agence ?') . '">' . csrf_field()
        . '<input type="hidden" name="action" value="statut"><button class="btn ' . ($a['statut_agence'] === 'Active' ? 'btn-danger' : 'btn-success') . '" type="submit">'
        . icon($a['statut_agence'] === 'Active' ? 'ban' : 'check') . ' ' . ($a['statut_agence'] === 'Active' ? 'Désactiver' : 'Réactiver') . '</button></form>';
}
echo page_header($title, $a ? badge($a['statut_agence']) . ' <span class="muted small">Créée le ' . e(dt($a['date_creation_agence'], false)) . '</span>' : 'La configuration sert à tous les calculs et est copiée dans chaque commande.', $actions, url('agences'));
?>
<form method="post" class="stack" style="max-width:980px">
    <?= csrf_field() ?>
    <div class="card"><div class="card-header"><h2><?= icon('store') ?> Identité</h2></div>
        <div class="card-body form-grid">
            <div class="field"><label class="req" for="nom_agence">Nom</label><input class="input" id="nom_agence" name="nom_agence" required maxlength="60" value="<?= $v('nom_agence') ?>"></div>
            <div class="field"><label class="req" for="ville_agence">Ville</label><input class="input" id="ville_agence" name="ville_agence" required maxlength="50" value="<?= $v('ville_agence') ?>"></div>
            <div class="field"><label class="req" for="adresse_agence">Adresse / quartier</label><input class="input" id="adresse_agence" name="adresse_agence" required maxlength="150" value="<?= $v('adresse_agence') ?>"></div>
            <div class="field"><label class="req" for="telephone_agence">Téléphone</label><input class="input" id="telephone_agence" name="telephone_agence" required maxlength="20" value="<?= $v('telephone_agence') ?>"></div>
        </div></div>

    <div class="grid grid-2">
        <div class="card"><div class="card-header"><h2><?= icon('clock') ?> Délais de traitement</h2></div>
            <div class="card-body form-grid">
                <div class="field"><label class="req" for="duree_normal_h">Service normal (h)</label><?= $num('duree_normal_h') ?></div>
                <div class="field"><label class="req" for="duree_express_h">Service express (h)</label><?= $num('duree_express_h') ?><span class="hint">Plus court que le normal.</span></div>
                <div class="field span-2"><label class="req" for="taux_majoration_express">Majoration express (%)</label><?= $num('taux_majoration_express', '0.01') ?></div>
            </div></div>
        <div class="card"><div class="card-header"><h2><?= icon('scale') ?> Lot au poids</h2></div>
            <div class="card-body form-grid">
                <div class="field"><label class="req" for="seuil_poids_kg">Seuil (kg)</label><?= $num('seuil_poids_kg', '0.01') ?></div>
                <div class="field"><label class="req" for="tarif_kg">Prix du kg (FCFA)</label><?= $num('tarif_kg') ?></div>
                <div class="field span-2"><label class="req" for="prix_piece_hors_categorie">Prix à la pièce sous le seuil (FCFA)</label><?= $num('prix_piece_hors_categorie') ?>
                    <span class="hint">RG28 / RG29 : au-delà du seuil le lot est facturé au poids, sinon à la pièce.</span></div>
            </div></div>
        <div class="card"><div class="card-header"><h2><?= icon('alert') ?> Retards de retrait</h2></div>
            <div class="card-body form-grid">
                <div class="field"><label class="req" for="delai_grace_jours">Délai de grâce (jours)</label><?= $num('delai_grace_jours') ?></div>
                <div class="field"><label class="req" for="frais_retard_jour">Frais / jour / vêtement</label><?= $num('frais_retard_jour') ?></div>
            </div></div>
        <div class="card"><div class="card-header"><h2><?= icon('gift') ?> Fidélité</h2></div>
            <div class="card-body form-grid">
                <div class="field"><label class="req" for="seuil_fidelite">Commandes requises</label><?= $num('seuil_fidelite') ?></div>
                <div class="field"><label class="req" for="taux_fidelite">Réduction (%)</label><?= $num('taux_fidelite', '0.01') ?></div>
            </div></div>
    </div>
    <div class="row" style="justify-content:flex-end"><a class="btn btn-ghost" href="<?= e(url('agences')) ?>">Annuler</a>
        <button class="btn btn-primary btn-lg" type="submit"><?= icon('check') ?> <?= $a ? 'Enregistrer la configuration' : 'Créer l\'agence' ?></button></div>
</form>
