<?php
/** Suivi et clôture d'un incident (RG82, RG83 ; clôture journalisée RG90). */
$id = (int) get('id');
$i = row('SELECT i.*, c.numero_commande, c.id_agence, cl.nom_client, cl.prenom_client, cl.telephone_client, e.nom_employe, e.prenom_employe
            FROM incident i JOIN commande c ON c.id_commande = i.id_commande JOIN client cl ON cl.id_client = c.id_client
            JOIN employe e ON e.id_employe = i.id_employe WHERE i.id_incident = ?', [$id]);
if (!$i || (is_gerant() && (int) $i['id_agence'] !== my_agence())) {
    flash('error', 'Incident introuvable.');
    redirect('incidents');
}
$title = 'Incident n° ' . $id;
$ouvert = $i['statut_incident'] !== 'Clôturé';

if (is_post() && is_gerant() && $ouvert) {
    csrf_check();
    try {
        $comp = (float) str_replace(',', '.', (string) post('montant_compensation', '0'));
        if (post('action') === 'cloturer') {
            if (!post('solution_apportee')) throw new RuntimeException('Indiquez la solution apportée pour clôturer (RG83).');
            q("UPDATE incident SET statut_incident = 'Clôturé', observation = ?, solution_apportee = ?, montant_compensation = ?, date_cloture = NOW() WHERE id_incident = ?",
                [nullable(post('observation')), post('solution_apportee'), $comp, $id]);
            flash('success', 'Incident clôturé.');
        } else {
            q("UPDATE incident SET statut_incident = 'En cours', observation = ?, montant_compensation = ? WHERE id_incident = ?",
                [nullable(post('observation')), $comp, $id]);
            flash('success', 'Suivi de l\'incident mis à jour.');
        }
    } catch (Throwable $ex) {
        flash('error', db_error($ex));
    }
    redirect('incident', ['id' => $id]);
}
$vets = rows('SELECT v.*, a.libelle_article FROM impliquer im JOIN vetement v ON v.id_vetement = im.id_vetement
               JOIN article a ON a.id_article = v.id_article WHERE im.id_incident = ?', [$id]);

echo page_header($i['type_incident'], badge($i['statut_incident']) . ' <span class="muted small">Déclaré le ' . e(dt($i['date_incident'])) . ' par ' . e(full_name($i['nom_employe'], $i['prenom_employe'])) . '</span>',
    '<a class="btn btn-secondary" href="' . e(url('commande', ['id' => $i['id_commande']])) . '">' . icon('receipt') . ' Commande ' . e($i['numero_commande']) . '</a>', url('incidents'));
?>
<div class="grid grid-main">
    <div class="stack">
        <div class="card">
            <div class="card-header"><h2><?= icon('alert') ?> <?= e($i['motif_incident']) ?></h2></div>
            <div class="card-body stack">
                <p class="text-2" style="white-space:pre-line"><?= e($i['description_incident'] ?: 'Pas de description détaillée.') ?></p>
                <?php if ($vets): ?>
                    <div><p class="section-title">Vêtements concernés</p><div class="row-wrap">
                        <?php foreach ($vets as $v): ?><span class="chip"><?= icon('shirt', 13) ?> <?= e($v['libelle_article']) ?> · <span class="mono"><?= e($v['code_etiquette']) ?></span></span><?php endforeach; ?></div></div>
                <?php endif; ?>
            </div>
        </div>
        <?php if ($ouvert && is_gerant()): ?>
        <form method="post" class="card"><?= csrf_field() ?>
            <div class="card-header"><h2><?= icon('edit') ?> Traitement</h2></div>
            <div class="card-body form-grid">
                <div class="field span-2"><label for="observation">Observations</label><textarea class="textarea" id="observation" name="observation"><?= e($i['observation']) ?></textarea></div>
                <div class="field span-2"><label for="solution_apportee">Solution apportée</label><input class="input" id="solution_apportee" name="solution_apportee" maxlength="255" placeholder="Obligatoire pour clôturer"></div>
                <div class="field"><label for="montant_compensation">Compensation accordée</label>
                    <div class="input-group"><input class="input has-suffix" id="montant_compensation" name="montant_compensation" type="number" min="0" step="100" value="<?= (int) $i['montant_compensation'] ?>"><span class="suffix">FCFA</span></div></div>
            </div>
            <div class="card-footer row" style="justify-content:flex-end">
                <button class="btn btn-secondary" type="submit" name="action" value="suivi"><?= icon('clock') ?> Marquer en cours</button>
                <button class="btn btn-primary" type="submit" name="action" value="cloturer"><?= icon('check-circle') ?> Clôturer</button>
            </div>
        </form>
        <?php else: ?>
        <div class="card"><div class="card-header"><h2><?= icon('check-circle') ?> Résolution</h2></div>
            <div class="card-body"><dl class="dl">
                <dt>Observations</dt><dd><?= e($i['observation'] ?: '—') ?></dd>
                <dt>Solution</dt><dd><?= e($i['solution_apportee'] ?: '—') ?></dd>
                <dt>Compensation</dt><dd><?= money($i['montant_compensation']) ?></dd>
                <dt>Clôturé le</dt><dd><?= e(dt($i['date_cloture'])) ?></dd>
            </dl></div></div>
        <?php endif; ?>
    </div>
    <div class="card"><div class="card-header"><h3><?= icon('user') ?> Client</h3></div>
        <div class="card-body"><div class="row" style="gap:12px"><span class="avatar"><?= e(initials($i['nom_client'], $i['prenom_client'])) ?></span>
            <div><div class="cell-main"><?= e(full_name($i['nom_client'], $i['prenom_client'])) ?></div><div class="cell-sub"><?= e($i['telephone_client']) ?></div></div></div></div></div>
</div>
