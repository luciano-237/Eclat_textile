<?php
/** Déclaration d'un incident sur une commande de l'agence (RG80, RG81). */
$title = 'Déclarer un incident';
$idc = (int) (post('id_commande') ?? get('commande', 0));
$num = (string) get('numero', '');
if (!$idc && $num !== '') {
    $idc = (int) val('SELECT id_commande FROM commande WHERE numero_commande = ? AND id_agence = ?', [$num, my_agence()]);
    if (!$idc) flash('error', 'Aucune commande de l\'agence ne porte ce numéro.');
}
$c = $idc ? load_commande($idc) : null;

if (is_post() && $c) {
    csrf_check();
    try {
        $type = in_array(post('type_incident'), TYPES_INCIDENT, true) ? post('type_incident') : 'Réclamation';
        if (!post('motif_incident')) throw new RuntimeException('Le motif est obligatoire.');
        $idi = transaction(function () use ($c, $type) {
            q('INSERT INTO incident (type_incident, motif_incident, description_incident, id_commande, id_employe) VALUES (?, ?, ?, ?, ?)',
                [$type, post('motif_incident'), nullable(post('description_incident')), $c['id_commande'], my_id()]);
            $idi = (int) db()->lastInsertId();
            foreach ((array) ($_POST['vetements'] ?? []) as $v) {
                q('INSERT INTO impliquer (id_incident, id_vetement) VALUES (?, ?)', [$idi, (int) $v]);
            }
            q("INSERT INTO journal_action (type_action, entite_concernee, id_entite, detail_action, id_employe) VALUES ('Création', 'incident', ?, ?, ?)",
                [$idi, $type . ' : ' . post('motif_incident'), my_id()]);
            return $idi;
        });
        flash('success', 'Incident déclaré.');
        redirect('incident', ['id' => $idi]);
    } catch (Throwable $ex) {
        flash('error', db_error($ex));
    }
}
$vets = $c ? rows("SELECT v.*, a.libelle_article FROM vetement v JOIN article a ON a.id_article = v.id_article WHERE v.id_commande = ? ORDER BY v.id_vetement", [$c['id_commande']]) : [];

echo page_header('Déclarer un incident', 'Perte, détérioration, erreur de traitement ou réclamation du client', '', $c ? url('commande', ['id' => $c['id_commande']]) : url('incidents'));
?>
<?php if (!$c): ?>
    <form method="get" class="card" style="max-width:560px">
        <input type="hidden" name="p" value="incident-nouveau">
        <div class="card-body stack">
            <div class="field"><label class="req" for="numero">Numéro de la commande</label>
                <div class="input-group"><?= icon('receipt', 16) ?><input class="input mono" id="numero" name="numero" required value="<?= e($num) ?>" placeholder="A01-261118-001" autofocus></div>
                <span class="hint">Numéro imprimé sur le ticket du client.</span></div>
        </div>
        <div class="card-footer row" style="justify-content:flex-end"><button class="btn btn-primary" type="submit">Continuer <?= icon('chevron', 16) ?></button></div>
    </form>
<?php else: ?>
<form method="post" class="grid grid-main">
    <?= csrf_field() ?><input type="hidden" name="id_commande" value="<?= (int) $c['id_commande'] ?>">
    <div class="card">
        <div class="card-header"><h2><?= icon('alert') ?> Incident</h2><span class="ref"><?= e($c['numero_commande']) ?></span></div>
        <div class="card-body stack">
            <div>
                <p class="label" style="margin-bottom:8px">Nature</p>
                <div class="choices">
                    <?php $ic = ['Perte' => 'search', 'Détérioration' => 'ban', 'Erreur de traitement' => 'droplet', 'Réclamation' => 'mail', 'Échec de livraison' => 'truck'];
                    foreach (TYPES_INCIDENT as $i => $t): ?>
                        <label class="choice"><input type="radio" name="type_incident" value="<?= e($t) ?>"<?= $i === 3 ? ' checked' : '' ?>>
                            <span class="choice-card" style="align-items:center;padding:11px"><span class="choice-icon" style="width:30px;height:30px"><?= icon($ic[$t], 16) ?></span><strong><?= e($t) ?></strong></span></label>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="field"><label class="req" for="motif_incident">Motif</label><input class="input" id="motif_incident" name="motif_incident" maxlength="255" required placeholder="Résumé en une phrase"></div>
            <div class="field"><label for="description_incident">Description détaillée</label><textarea class="textarea" id="description_incident" name="description_incident" rows="4"></textarea></div>
        </div>
        <div class="card-footer row" style="justify-content:flex-end"><button class="btn btn-primary" type="submit"><?= icon('check') ?> Déclarer l'incident</button></div>
    </div>
    <div class="card">
        <div class="card-header"><h3><?= icon('shirt') ?> Vêtements concernés</h3></div>
        <div class="list"><?php foreach ($vets as $v): ?>
            <label class="list-item" style="cursor:pointer"><input type="checkbox" name="vetements[]" value="<?= $v['id_vetement'] ?>" style="width:18px;height:18px;accent-color:var(--primary)">
                <span class="grow"><span class="cell-main"><?= e($v['libelle_article']) ?></span><span class="cell-sub mono" style="display:block"><?= e($v['code_etiquette']) ?></span></span>
                <?= badge($v['statut_vetement']) ?></label>
        <?php endforeach; ?></div>
        <div class="card-footer small muted">Facultatif. Un incident peut viser plusieurs vêtements de la commande (RG81).</div>
    </div>
</form>
<?php endif; ?>
