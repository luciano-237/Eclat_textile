<?php
/** Incidents et réclamations (RG80 à RG83). */
$title = 'Incidents';
$agence = is_gerant() ? my_agence() : (int) get('agence', 0);
$filtre = in_array(get('statut'), ['ouverts', 'clotures'], true) ? get('statut') : 'ouverts';
$where = [$filtre === 'ouverts' ? "i.statut_incident <> 'Clôturé'" : "i.statut_incident = 'Clôturé'"];
$params = [];
if ($agence) { $where[] = 'c.id_agence = ?'; $params[] = $agence; }
$list = rows('SELECT i.*, c.numero_commande, a.nom_agence, cl.nom_client, cl.prenom_client, e.nom_employe, e.prenom_employe,
                     (SELECT COUNT(*) FROM impliquer im WHERE im.id_incident = i.id_incident) nb_vet
                FROM incident i JOIN commande c ON c.id_commande = i.id_commande JOIN agence a ON a.id_agence = c.id_agence
                JOIN client cl ON cl.id_client = c.id_client JOIN employe e ON e.id_employe = i.id_employe
               WHERE ' . implode(' AND ', $where) . ' ORDER BY i.date_incident DESC LIMIT 200', $params);
$nb = row("SELECT SUM(i.statut_incident <> 'Clôturé') o, SUM(i.statut_incident = 'Clôturé') f, COALESCE(SUM(i.montant_compensation),0) m
             FROM incident i JOIN commande c ON c.id_commande = i.id_commande" . ($agence ? ' WHERE c.id_agence = ' . (int) $agence : ''));
$toneType = ['Perte' => 'critical', 'Détérioration' => 'critical', 'Erreur de traitement' => 'warning', 'Réclamation' => 'info', 'Échec de livraison' => 'violet'];

echo page_header('Incidents', 'Pertes, détériorations, réclamations et échecs de livraison',
    is_gerant() ? '<a class="btn btn-primary" href="' . e(url('incident-nouveau')) . '">' . icon('plus') . ' Déclarer un incident</a>' : '');
?>
<div class="grid grid-3 mb-2">
    <?= kpi('Incidents ouverts', num($nb['o'] ?? 0), 'alert', ($nb['o'] ?? 0) ? 'critical' : 'good') ?>
    <?= kpi('Incidents clôturés', num($nb['f'] ?? 0), 'check-circle', 'teal') ?>
    <?= kpi('Compensations accordées', kpi_money($nb['m'] ?? 0), 'wallet', 'violet') ?>
</div>
<div class="card card-flush">
    <div class="toolbar">
        <div class="segmented">
            <a class="<?= $filtre === 'ouverts' ? 'active' : '' ?>" href="<?= e(url('incidents', array_filter(['statut' => 'ouverts', 'agence' => is_admin() ? $agence : null]))) ?>">Ouverts <span class="count"><?= (int) ($nb['o'] ?? 0) ?></span></a>
            <a class="<?= $filtre === 'clotures' ? 'active' : '' ?>" href="<?= e(url('incidents', array_filter(['statut' => 'clotures', 'agence' => is_admin() ? $agence : null]))) ?>">Clôturés <span class="count"><?= (int) ($nb['f'] ?? 0) ?></span></a>
        </div>
        <?php if (is_admin()): ?>
            <form method="get" style="margin-left:auto"><input type="hidden" name="p" value="incidents"><input type="hidden" name="statut" value="<?= e($filtre) ?>">
                <select class="select" name="agence" onchange="this.form.submit()"><option value="0">Toutes les agences</option>
                    <?php foreach (agences() as $ag): ?><option value="<?= $ag['id_agence'] ?>"<?= selected($agence, $ag['id_agence']) ?>><?= e($ag['nom_agence']) ?></option><?php endforeach; ?></select></form>
        <?php endif; ?>
    </div>
    <?php if ($list): ?>
    <div class="table-wrap"><table class="table">
        <thead><tr><th>Incident</th><th>Commande</th><th>Client</th><th>Déclaré par</th><th class="num">Compensation</th><th>Statut</th></tr></thead>
        <tbody><?php foreach ($list as $i): ?>
            <tr class="clickable" data-href="<?= e(url('incident', ['id' => $i['id_incident']])) ?>">
                <td><?= badge($i['type_incident'], $toneType[$i['type_incident']] ?? 'neutral') ?>
                    <div class="cell-main mt-1"><?= e(mb_strimwidth($i['motif_incident'], 0, 60, '…')) ?></div>
                    <div class="cell-sub"><?= e(dt($i['date_incident'])) ?><?= $i['nb_vet'] ? ' · ' . (int) $i['nb_vet'] . ' vêtement(s)' : '' ?></div></td>
                <td><span class="ref"><?= e($i['numero_commande']) ?></span><?php if (is_admin()): ?><div class="cell-sub mt-1"><?= e($i['nom_agence']) ?></div><?php endif; ?></td>
                <td class="cell-main"><?= e(full_name($i['nom_client'], $i['prenom_client'])) ?></td>
                <td class="text-2"><?= e(full_name($i['nom_employe'], $i['prenom_employe'])) ?></td>
                <td class="num"><?= $i['montant_compensation'] > 0 ? money($i['montant_compensation']) : '—' ?></td>
                <td><?= badge($i['statut_incident']) ?></td>
            </tr>
        <?php endforeach; ?></tbody>
    </table></div>
    <?php else: echo empty_state($filtre === 'ouverts' ? 'Aucun incident ouvert' : 'Aucun incident clôturé', $filtre === 'ouverts' ? 'Tout se passe bien !' : '', 'check-circle'); endif; ?>
</div>
