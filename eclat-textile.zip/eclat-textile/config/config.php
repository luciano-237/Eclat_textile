<?php
/**
 * Configuration de l'application.
 * Adaptez ces valeurs à votre serveur MySQL.
 * Pour une configuration propre à votre poste, créez config.local.php
 * (même format) : ses valeurs remplacent celles-ci.
 */
$config = [
    'app_name'  => 'Éclat Textile',
    'app_tagline' => 'Pressing multi-agences',
    'db' => [
        'host'     => '127.0.0.1',
        'port'     => 3307,          // MySQL 8.4 installé sur ce poste écoute sur 3307
        'name'     => 'pressing',
        'user'     => 'root',
        'password' => '',
    ],
    'devise'    => 'FCFA',
    'timezone'  => 'Africa/Douala',
    'upload_dir' => __DIR__ . '/../public/uploads',
];

if (is_file(__DIR__ . '/config.local.php')) {
    $local = require __DIR__ . '/config.local.php';
    $config = array_replace_recursive($config, $local);
}

return $config;
