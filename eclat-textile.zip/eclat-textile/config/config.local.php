<?php
/*
 * Paramètres propres à ce poste (prioritaires sur config.php).
 * MySQL 9.1 de WampServer : port 3306, utilisateur root sans mot de passe.
 */
return ['db' => ['port' => 3306, 'user' => 'root', 'password' => '']];
