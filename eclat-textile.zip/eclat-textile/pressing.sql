-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : dim. 22 nov. 2026 à 19:23
-- Version du serveur : 9.1.0
-- Version de PHP : 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `pressing`
--

DELIMITER $$
--
-- Procédures
--
DROP PROCEDURE IF EXISTS `sp_affecter_livraisons_attente`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_affecter_livraisons_attente` (IN `p_id_agence` INT UNSIGNED)   BEGIN
    DECLARE v_livraison, v_livreur INT UNSIGNED;
    boucle: LOOP
        SET v_livraison = (SELECT l.id_livraison FROM livraison l JOIN commande c ON c.id_commande = l.id_commande
                            WHERE c.id_agence = p_id_agence AND l.statut_livraison = 'En attente de livreur'
                            ORDER BY l.date_creation_livraison, l.id_livraison LIMIT 1);
        SET v_livreur = (SELECT e.id_employe FROM employe e JOIN role r ON r.id_role = e.id_role
                          WHERE r.libelle_role = 'Livreur' AND e.id_agence = p_id_agence
                            AND e.statut_compte = 'Actif' AND e.disponibilite_livreur = 'Libre'
                          ORDER BY e.id_employe LIMIT 1);
        IF v_livraison IS NULL OR v_livreur IS NULL THEN
            LEAVE boucle;
        END IF;
        UPDATE livraison SET statut_livraison = 'Assignée', id_employe = v_livreur WHERE id_livraison = v_livraison;
    END LOOP;
END$$

DROP PROCEDURE IF EXISTS `sp_regenerer_code`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_regenerer_code` (IN `p_id_commande` INT UNSIGNED, IN `p_id_employe` INT UNSIGNED)   BEGIN
    DECLARE v_code CHAR(6);
    DECLARE v_client INT UNSIGNED;
    DECLARE v_numero VARCHAR(30);
    IF NOT EXISTS (SELECT 1 FROM code_validation WHERE id_commande = p_id_commande AND statut_code = 'Actif') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG61 : cette commande n''a pas de code actif à remplacer.';
    END IF;
    UPDATE code_validation SET statut_code = 'Désactivé' WHERE id_commande = p_id_commande AND statut_code = 'Actif';
    SET v_code = LPAD(FLOOR(RAND() * 1000000), 6, '0');
    INSERT INTO code_validation (valeur_qr, code_numerique, id_commande)
    VALUES (SHA2(CONCAT(UUID(), RAND()), 256), v_code, p_id_commande);
    SELECT id_client, numero_commande INTO v_client, v_numero FROM commande WHERE id_commande = p_id_commande;
    INSERT INTO notification (type_notification, contenu, id_client, id_commande)
    VALUES ('Code de validation', CONCAT('Nouveau code pour la commande n° ', v_numero, ' : ', v_code, '.'),
            v_client, p_id_commande);
    INSERT INTO journal_action (type_action, entite_concernee, id_entite, detail_action, id_employe)
    VALUES ('Modification', 'code_validation', p_id_commande, 'Régénération du code de validation', p_id_employe);
END$$

--
-- Fonctions
--
DROP FUNCTION IF EXISTS `fn_date_retrait_prevue`$$
CREATE DEFINER=`root`@`localhost` FUNCTION `fn_date_retrait_prevue` (`p_commande` INT UNSIGNED) RETURNS DATETIME READS SQL DATA BEGIN
    DECLARE v_date DATETIME;
    SELECT date_paiement_integral + INTERVAL duree_appliquee_h HOUR INTO v_date
      FROM commande WHERE id_commande = p_commande;
    RETURN v_date;
END$$

DROP FUNCTION IF EXISTS `fn_frais_retard`$$
CREATE DEFINER=`root`@`localhost` FUNCTION `fn_frais_retard` (`p_commande` INT UNSIGNED, `p_seulement_remis` BOOLEAN) RETURNS DECIMAL(12,2) READS SQL DATA BEGIN
    DECLARE v_mode VARCHAR(10);
    DECLARE v_frais DECIMAL(10,2);
    DECLARE v_limite DATE;
    DECLARE v_jours INT DEFAULT 0;
    SELECT mode_recuperation, frais_retard_applique,
           DATE(date_paiement_integral + INTERVAL duree_appliquee_h HOUR) + INTERVAL delai_grace_applique DAY
      INTO v_mode, v_frais, v_limite FROM commande WHERE id_commande = p_commande;
    IF v_mode <> 'Retrait' OR v_limite IS NULL THEN
        RETURN 0;                                           -- RG78 : pas de frais pour une livraison
    END IF;
    SELECT COALESCE(SUM(GREATEST(0, DATEDIFF(COALESCE(r.date_retrait, NOW()), v_limite))), 0) INTO v_jours
      FROM vetement v LEFT JOIN retrait r ON r.id_retrait = v.id_retrait
     WHERE v.id_commande = p_commande AND v.statut_vetement NOT IN ('Refusé', 'Livré')
       AND (p_seulement_remis = FALSE OR v.id_retrait IS NOT NULL);
    RETURN v_jours * v_frais;
END$$

DROP FUNCTION IF EXISTS `fn_montant_supplements`$$
CREATE DEFINER=`root`@`localhost` FUNCTION `fn_montant_supplements` (`p_commande` INT UNSIGNED) RETURNS DECIMAL(12,2) READS SQL DATA BEGIN
    DECLARE v_total DECIMAL(12,2) DEFAULT 0;
    SELECT COALESCE(SUM(prix_supp_applique * quantite_supp), 0) INTO v_total
      FROM supplement_applique WHERE id_commande = p_commande;
    RETURN v_total;
END$$

DROP FUNCTION IF EXISTS `fn_montant_total`$$
CREATE DEFINER=`root`@`localhost` FUNCTION `fn_montant_total` (`p_commande` INT UNSIGNED) RETURNS DECIMAL(12,2) READS SQL DATA BEGIN
    DECLARE v_vet, v_sous_total DECIMAL(12,2);
    DECLARE v_taux_maj, v_taux_remise DECIMAL(5,2);
    SELECT taux_majoration_applique, taux_remise INTO v_taux_maj, v_taux_remise
      FROM commande WHERE id_commande = p_commande;
    SET v_vet = fn_montant_vetements(p_commande);
    SET v_sous_total = v_vet + ROUND(v_vet * v_taux_maj / 100, 0) + fn_montant_supplements(p_commande);
    RETURN v_sous_total - ROUND(v_sous_total * v_taux_remise / 100, 0);
END$$

DROP FUNCTION IF EXISTS `fn_montant_vetements`$$
CREATE DEFINER=`root`@`localhost` FUNCTION `fn_montant_vetements` (`p_commande` INT UNSIGNED) RETURNS DECIMAL(12,2) READS SQL DATA BEGIN
    DECLARE v_seuil, v_tarif_kg, v_prix_hc DECIMAL(10,2);
    DECLARE v_pieces, v_poids, v_maj DECIMAL(12,3) DEFAULT 0;
    DECLARE v_nb INT DEFAULT 0;
    SELECT seuil_poids_applique, tarif_kg_applique, prix_hors_cat_applique
      INTO v_seuil, v_tarif_kg, v_prix_hc FROM commande WHERE id_commande = p_commande;
    SELECT COALESCE(SUM(prix_applique), 0) INTO v_pieces
      FROM vetement WHERE id_commande = p_commande AND statut_vetement <> 'Refusé' AND prix_applique IS NOT NULL;
    SELECT COALESCE(SUM(poids_kg), 0), COUNT(*) INTO v_poids, v_nb
      FROM vetement WHERE id_commande = p_commande AND statut_vetement <> 'Refusé' AND prix_applique IS NULL;
    SELECT COALESCE(SUM(majoration_speciale), 0) INTO v_maj
      FROM vetement WHERE id_commande = p_commande AND statut_vetement <> 'Refusé' AND accord_client = TRUE;
    RETURN v_pieces + v_maj
         + CASE WHEN v_nb = 0 THEN 0
                WHEN v_poids >= v_seuil THEN ROUND(v_poids * v_tarif_kg, 0)   -- RG28 : lot au poids
                ELSE v_nb * v_prix_hc END;                                    -- RG29 : à la pièce hors catégorie
END$$

DROP FUNCTION IF EXISTS `fn_nb_commandes_eligibles`$$
CREATE DEFINER=`root`@`localhost` FUNCTION `fn_nb_commandes_eligibles` (`p_client` INT UNSIGNED) RETURNS INT READS SQL DATA BEGIN
    DECLARE v_agence INT UNSIGNED;
    DECLARE v_depuis DATETIME;
    DECLARE v_nb INT DEFAULT 0;
    SELECT id_agence INTO v_agence FROM client WHERE id_client = p_client;
    SELECT MAX(date_commande) INTO v_depuis FROM commande
     WHERE id_client = p_client AND id_agence = v_agence AND taux_remise > 0 AND statut_commande <> 'Annulée';
    SELECT COUNT(*) INTO v_nb FROM commande
     WHERE id_client = p_client AND id_agence = v_agence
       AND statut_commande IN ('Retirée', 'Livrée') AND date_paiement_integral IS NOT NULL
       AND date_commande > COALESCE(v_depuis, '1000-01-01');
    RETURN v_nb;
END$$

DROP FUNCTION IF EXISTS `fn_total_paye`$$
CREATE DEFINER=`root`@`localhost` FUNCTION `fn_total_paye` (`p_commande` INT UNSIGNED, `p_objet` VARCHAR(15)) RETURNS DECIMAL(12,2) READS SQL DATA BEGIN
    DECLARE v_total DECIMAL(12,2) DEFAULT 0;
    SELECT COALESCE(SUM(montant_paiement), 0) INTO v_total
      FROM paiement WHERE id_commande = p_commande AND objet_paiement = p_objet;
    RETURN v_total;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `agence`
--

DROP TABLE IF EXISTS `agence`;
CREATE TABLE IF NOT EXISTS `agence` (
  `id_agence` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom_agence` varchar(60) NOT NULL,
  `adresse_agence` varchar(150) NOT NULL,
  `ville_agence` varchar(50) NOT NULL,
  `telephone_agence` varchar(20) NOT NULL,
  `statut_agence` varchar(10) NOT NULL DEFAULT 'Active',
  `date_creation_agence` date NOT NULL DEFAULT (curdate()),
  `duree_normal_h` smallint UNSIGNED NOT NULL COMMENT 'Durée du service normal, en heures',
  `duree_express_h` smallint UNSIGNED NOT NULL COMMENT 'Durée du service express, en heures',
  `taux_majoration_express` decimal(5,2) NOT NULL DEFAULT '30.00',
  `seuil_poids_kg` decimal(6,2) NOT NULL DEFAULT '3.00',
  `tarif_kg` decimal(10,2) NOT NULL DEFAULT '500.00',
  `prix_piece_hors_categorie` decimal(10,2) NOT NULL DEFAULT '500.00',
  `delai_grace_jours` smallint UNSIGNED NOT NULL DEFAULT '14',
  `frais_retard_jour` decimal(10,2) NOT NULL DEFAULT '100.00',
  `seuil_fidelite` smallint UNSIGNED NOT NULL DEFAULT '10',
  `taux_fidelite` decimal(5,2) NOT NULL DEFAULT '3.00',
  PRIMARY KEY (`id_agence`),
  UNIQUE KEY `uq_agence_nom` (`nom_agence`)
) ;

--
-- Déchargement des données de la table `agence`
--

INSERT INTO `agence` (`id_agence`, `nom_agence`, `adresse_agence`, `ville_agence`, `telephone_agence`, `statut_agence`, `date_creation_agence`, `duree_normal_h`, `duree_express_h`, `taux_majoration_express`, `seuil_poids_kg`, `tarif_kg`, `prix_piece_hors_categorie`, `delai_grace_jours`, `frais_retard_jour`, `seuil_fidelite`, `taux_fidelite`) VALUES
(1, 'Bastos', 'Rue 1.750, face ambassade de Chine', 'Yaoundé', '222 20 14 50', 'Active', '2026-11-19', 72, 24, 30.00, 3.00, 500.00, 500.00, 14, 100.00, 10, 3.00),
(2, 'Akwa', 'Boulevard de la Liberté', 'Douala', '233 42 18 70', 'Active', '2026-11-19', 48, 12, 30.00, 3.00, 500.00, 500.00, 14, 100.00, 10, 3.00);

--
-- Déclencheurs `agence`
--
DROP TRIGGER IF EXISTS `trg_agence_au`;
DELIMITER $$
CREATE TRIGGER `trg_agence_au` AFTER UPDATE ON `agence` FOR EACH ROW BEGIN
    IF @id_employe_session IS NOT NULL THEN
        INSERT INTO journal_action (type_action, entite_concernee, id_entite, detail_action, id_employe)
        VALUES ('Modification', 'agence', NEW.id_agence, CONCAT('Configuration de l'agence ', NEW.nom_agence,
                ' modifiée (statut ', NEW.statut_agence, ')'), @id_employe_session);
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `article`
--

DROP TABLE IF EXISTS `article`;
CREATE TABLE IF NOT EXISTS `article` (
  `id_article` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `libelle_article` varchar(60) NOT NULL COMMENT 'Nature du vêtement : chemise, veste, drap…',
  `id_categorie` int UNSIGNED NOT NULL,
  PRIMARY KEY (`id_article`),
  UNIQUE KEY `uq_article_libelle` (`libelle_article`),
  KEY `fk_article_categorie` (`id_categorie`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Natures de vêtements (REGROUPER)';

--
-- Déchargement des données de la table `article`
--

INSERT INTO `article` (`id_article`, `libelle_article`, `id_categorie`) VALUES
(1, 'Costume 2 pièces', 1),
(2, 'Veste', 1),
(3, 'Manteau', 1),
(4, 'Robe', 2),
(5, 'Robe de soirée', 2),
(6, 'Robe de mariée', 2),
(7, 'Drap', 3),
(8, 'Couverture', 3),
(9, 'Rideau', 3),
(10, 'Nappe', 3),
(11, 'Chemise', 4),
(12, 'Pantalon', 4),
(13, 'T-shirt', 4),
(14, 'Jupe', 4),
(15, 'Pagne', 4),
(16, 'Debardeur', 3);

-- --------------------------------------------------------

--
-- Structure de la table `categorie_article`
--

DROP TABLE IF EXISTS `categorie_article`;
CREATE TABLE IF NOT EXISTS `categorie_article` (
  `id_categorie` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `libelle_categorie` varchar(60) NOT NULL,
  `description_categorie` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_categorie`),
  UNIQUE KEY `uq_categorie_libelle` (`libelle_categorie`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Catégories d''articles (costumes, robes, linge de maison…)';

--
-- Déchargement des données de la table `categorie_article`
--

INSERT INTO `categorie_article` (`id_categorie`, `libelle_categorie`, `description_categorie`) VALUES
(1, 'Costumes', 'Costumes et vestes'),
(2, 'Robes', 'Robes, dont robes de soirée'),
(3, 'Linge de maison', 'Draps, couvertures, rideaux, serviettes'),
(4, 'Linge courant', 'Chemises, pantalons, t-shirts : facturés au poids');

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

DROP TABLE IF EXISTS `client`;
CREATE TABLE IF NOT EXISTS `client` (
  `id_client` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom_client` varchar(50) NOT NULL,
  `prenom_client` varchar(50) DEFAULT NULL,
  `telephone_client` varchar(20) NOT NULL COMMENT 'Unique : identifie le client, reçoit SMS et WhatsApp',
  `email_client` varchar(120) DEFAULT NULL,
  `adresse_client` varchar(255) DEFAULT NULL COMMENT 'Obligatoire si le client demande une livraison',
  `date_inscription` date NOT NULL DEFAULT (curdate()),
  `id_agence` int UNSIGNED NOT NULL COMMENT 'Agence de fidélité',
  PRIMARY KEY (`id_client`),
  UNIQUE KEY `uq_client_telephone` (`telephone_client`),
  KEY `fk_client_agence` (`id_agence`),
  KEY `idx_client_nom` (`nom_client`,`prenom_client`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Clients (RATTACHER : agence de fidélité)';

--
-- Déchargement des données de la table `client`
--

INSERT INTO `client` (`id_client`, `nom_client`, `prenom_client`, `telephone_client`, `email_client`, `adresse_client`, `date_inscription`, `id_agence`) VALUES
(1, 'Atangana', 'Brice', '677112233', NULL, 'Quartier Bastos, villa 12', '2026-10-10', 1),
(2, 'Fotso', 'Mireille', '699445566', NULL, 'Mvan, derrière la station', '2026-10-10', 1),
(3, 'Onana', 'Yves', '655778899', NULL, NULL, '2026-10-10', 1),
(4, 'Nkeng', 'Laure', '691223344', NULL, 'Odza, carrefour Bel-Air', '2026-10-10', 1),
(5, 'Tchoua', 'Arnaud', '670998877', NULL, 'Bonapriso, rue Njo-Njo', '2026-10-10', 2),
(6, 'Eyenga', 'Grâce', '694556677', NULL, NULL, '2026-10-10', 2);

--
-- Déclencheurs `client`
--
DROP TRIGGER IF EXISTS `trg_client_bi`;
DELIMITER $$
CREATE TRIGGER `trg_client_bi` BEFORE INSERT ON `client` FOR EACH ROW BEGIN
    IF (SELECT statut_agence FROM agence WHERE id_agence = NEW.id_agence) <> 'Active' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG06 : une agence inactive ne peut plus enregistrer de client.';
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `code_validation`
--

DROP TABLE IF EXISTS `code_validation`;
CREATE TABLE IF NOT EXISTS `code_validation` (
  `id_code` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `valeur_qr` varchar(64) NOT NULL COMMENT 'Valeur encodée dans le QR code',
  `code_numerique` char(6) NOT NULL,
  `statut_code` varchar(10) NOT NULL DEFAULT 'Actif',
  `date_generation` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_utilisation` datetime DEFAULT NULL,
  `id_commande` int UNSIGNED NOT NULL,
  `code_actif` int UNSIGNED GENERATED ALWAYS AS (if((`statut_code` = _utf8mb4'Actif'),`id_commande`,NULL)) STORED,
  PRIMARY KEY (`id_code`),
  UNIQUE KEY `uq_code_valeur` (`valeur_qr`),
  UNIQUE KEY `uq_code_un_seul_actif` (`code_actif`),
  KEY `fk_code_commande` (`id_commande`)
) ;

--
-- Déchargement des données de la table `code_validation`
--

INSERT INTO `code_validation` (`id_code`, `valeur_qr`, `code_numerique`, `statut_code`, `date_generation`, `date_utilisation`, `id_commande`) VALUES
(1, '3f546cb97df67cc8bd59c8136f43bdabba16088105bd838c3f0f2f4dc285218c', '612889', 'Utilisé', '2026-11-19 13:28:38', '2026-11-19 13:28:38', 1),
(2, '6cc36d2b8687fb4cb79d9006839f0b75bf976a4f20a8dd3cd7c4ac7c1b440366', '803862', 'Actif', '2026-11-19 13:28:38', NULL, 2),
(3, '727e14f06f2079ab831297d35a39438e4d9b5b7d619397dd924c70c34e430e53', '757382', 'Utilisé', '2026-11-19 13:28:38', '2026-11-20 08:15:56', 3),
(4, 'fc56f500a3a5b0fe758459f3b5f09d61cda3633e7c9a479d2c3cd6ea4e37763f', '155504', 'Actif', '2026-11-19 13:28:38', NULL, 4),
(5, '15493cf624cb7eb5bac6a2eec3a5d98c8419136f189ce9896841dc4697d4dbba', '138142', 'Actif', '2026-11-19 13:28:38', NULL, 5),
(6, '2edc1499f2b20a935c30e6780ae705d31bc66a1f5bfdaee17d6a0a390051ad7d', '225159', 'Utilisé', '2026-11-19 13:28:38', '2026-11-21 13:39:11', 7),
(7, 'c0c00606df0dc9bc42016c7a99b38da70d42b43011e42247cb140da65953d3ad', '034747', 'Utilisé', '2026-11-19 13:28:38', '2026-11-20 20:35:14', 8),
(8, 'e9effe5e1bd253c2a89af065fab569c8f85503c2ed27693cec92a4a02d255765', '376826', 'Actif', '2026-11-20 20:38:30', NULL, 10);

-- --------------------------------------------------------

--
-- Structure de la table `commande`
--

DROP TABLE IF EXISTS `commande`;
CREATE TABLE IF NOT EXISTS `commande` (
  `id_commande` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `numero_commande` varchar(30) NOT NULL COMMENT 'Numéro lisible imprimé sur le ticket',
  `date_commande` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `statut_commande` varchar(25) NOT NULL DEFAULT 'Enregistrée',
  `type_service` varchar(10) NOT NULL DEFAULT 'Normal',
  `mode_recuperation` varchar(10) NOT NULL DEFAULT 'Retrait',
  `duree_appliquee_h` smallint UNSIGNED NOT NULL,
  `taux_majoration_applique` decimal(5,2) NOT NULL,
  `tarif_kg_applique` decimal(10,2) NOT NULL,
  `seuil_poids_applique` decimal(6,2) NOT NULL,
  `prix_hors_cat_applique` decimal(10,2) NOT NULL,
  `delai_grace_applique` smallint UNSIGNED NOT NULL,
  `frais_retard_applique` decimal(10,2) NOT NULL,
  `taux_remise` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT 'Réduction de fidélité appliquée (RG20)',
  `date_paiement_integral` datetime DEFAULT NULL,
  `date_retrait_effective` datetime DEFAULT NULL COMMENT 'Récupération complète ou livraison',
  `id_agence` int UNSIGNED NOT NULL,
  `id_client` int UNSIGNED NOT NULL,
  `id_employe` int UNSIGNED NOT NULL COMMENT 'Gérant qui a enregistré la commande',
  PRIMARY KEY (`id_commande`),
  UNIQUE KEY `uq_commande_numero` (`numero_commande`),
  KEY `fk_commande_client` (`id_client`),
  KEY `fk_commande_employe` (`id_employe`),
  KEY `idx_commande_statut` (`id_agence`,`statut_commande`),
  KEY `idx_commande_date` (`date_commande`)
) ;

--
-- Déchargement des données de la table `commande`
--

INSERT INTO `commande` (`id_commande`, `numero_commande`, `date_commande`, `statut_commande`, `type_service`, `mode_recuperation`, `duree_appliquee_h`, `taux_majoration_applique`, `tarif_kg_applique`, `seuil_poids_applique`, `prix_hors_cat_applique`, `delai_grace_applique`, `frais_retard_applique`, `taux_remise`, `date_paiement_integral`, `date_retrait_effective`, `id_agence`, `id_client`, `id_employe`) VALUES
(1, 'A01-261119-001', '2026-11-13 09:28:38', 'Retirée', 'Normal', 'Retrait', 72, 0.00, 500.00, 3.00, 500.00, 14, 100.00, 0.00, '2026-11-19 13:28:38', '2026-11-19 13:28:38', 1, 1, 2),
(2, 'A01-261119-002', '2026-11-14 10:28:38', 'Terminée', 'Express', 'Retrait', 24, 30.00, 500.00, 3.00, 500.00, 14, 100.00, 0.00, '2026-11-19 13:28:38', NULL, 1, 2, 2),
(3, 'A01-261119-003', '2026-11-15 11:28:38', 'Livrée', 'Normal', 'Livraison', 72, 0.00, 500.00, 3.00, 500.00, 14, 100.00, 0.00, '2026-11-19 13:28:38', '2026-11-20 08:15:56', 1, 4, 2),
(4, 'A01-261119-004', '2026-11-16 11:28:38', 'En traitement', 'Normal', 'Retrait', 72, 0.00, 500.00, 3.00, 500.00, 14, 100.00, 0.00, '2026-11-19 13:28:38', NULL, 1, 3, 2),
(5, 'A01-261119-005', '2026-11-18 10:28:38', 'Payée', 'Express', 'Retrait', 24, 30.00, 500.00, 3.00, 500.00, 14, 100.00, 0.00, '2026-11-19 13:28:38', NULL, 1, 1, 2),
(6, 'A01-261119-006', '2026-11-19 10:28:38', 'Enregistrée', 'Normal', 'Retrait', 72, 0.00, 500.00, 3.00, 500.00, 14, 100.00, 0.00, NULL, NULL, 1, 2, 2),
(7, 'A02-261119-001', '2026-11-17 10:28:38', 'Livrée', 'Normal', 'Livraison', 48, 0.00, 500.00, 3.00, 500.00, 14, 100.00, 0.00, '2026-11-19 13:28:38', '2026-11-21 13:39:11', 2, 5, 5),
(8, 'A02-261119-002', '2026-11-18 11:28:38', 'Retirée', 'Express', 'Retrait', 12, 30.00, 500.00, 3.00, 500.00, 14, 100.00, 0.00, '2026-11-19 13:28:38', '2026-11-20 20:35:14', 2, 6, 5),
(9, 'A01-261119-007', '2026-11-19 21:58:12', 'Enregistrée', 'Express', 'Livraison', 24, 30.00, 500.00, 3.00, 500.00, 14, 100.00, 0.00, NULL, NULL, 1, 2, 2),
(10, 'A02-261120-001', '2026-11-20 20:36:14', 'En livraison', 'Normal', 'Livraison', 48, 0.00, 500.00, 3.00, 500.00, 14, 100.00, 0.00, '2026-11-20 20:38:30', NULL, 2, 5, 5),
(11, 'A02-261121-001', '2026-11-21 13:41:24', 'Annulée', 'Normal', 'Retrait', 48, 0.00, 500.00, 3.00, 500.00, 14, 100.00, 0.00, NULL, NULL, 2, 6, 5);

--
-- Déclencheurs `commande`
--
DROP TRIGGER IF EXISTS `trg_commande_ai`;
DELIMITER $$
CREATE TRIGGER `trg_commande_ai` AFTER INSERT ON `commande` FOR EACH ROW BEGIN
    DECLARE v_supp INT UNSIGNED;
    IF NEW.mode_recuperation = 'Livraison' THEN
        SET v_supp = (SELECT id_supplement FROM supplement WHERE libelle_supplement = 'Livraison à domicile');
        INSERT INTO supplement_applique (prix_supp_applique, id_commande, id_supplement) VALUES (0, NEW.id_commande, v_supp);
    END IF;
    INSERT INTO notification (type_notification, contenu, id_client, id_commande)
    VALUES ('Dépôt', CONCAT('Votre dépôt n° ', NEW.numero_commande, ' est enregistré.'), NEW.id_client, NEW.id_commande);
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `trg_commande_bi`;
DELIMITER $$
CREATE TRIGGER `trg_commande_bi` BEFORE INSERT ON `commande` FOR EACH ROW BEGIN
    DECLARE v_statut_agence VARCHAR(10);
    DECLARE v_d_norm, v_d_exp, v_grace, v_seuil_fid SMALLINT UNSIGNED;
    DECLARE v_maj, v_taux_fid DECIMAL(5,2);
    DECLARE v_seuil DECIMAL(6,2);
    DECLARE v_kg, v_hc, v_frais DECIMAL(10,2);
    DECLARE v_agence_client INT UNSIGNED;
    DECLARE v_prefixe VARCHAR(20);

    SELECT statut_agence, duree_normal_h, duree_express_h, taux_majoration_express, seuil_poids_kg, tarif_kg,
           prix_piece_hors_categorie, delai_grace_jours, frais_retard_jour, seuil_fidelite, taux_fidelite
      INTO v_statut_agence, v_d_norm, v_d_exp, v_maj, v_seuil, v_kg, v_hc, v_grace, v_frais, v_seuil_fid, v_taux_fid
      FROM agence WHERE id_agence = NEW.id_agence;
    IF v_statut_agence <> 'Active' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG06 : une agence inactive ne peut plus enregistrer de commande.';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM employe e JOIN role r ON r.id_role = e.id_role
                    WHERE e.id_employe = NEW.id_employe AND r.libelle_role = 'Gérant'
                      AND e.id_agence = NEW.id_agence AND e.statut_compte = 'Actif') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG32 : la commande est enregistrée par un gérant actif de l'agence.';
    END IF;
    IF NEW.mode_recuperation = 'Livraison'
       AND (SELECT adresse_client FROM client WHERE id_client = NEW.id_client) IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Livraison impossible : l'adresse du client n'est pas renseignée.';
    END IF;

    SET NEW.statut_commande = 'Enregistrée';
    SET NEW.duree_appliquee_h        = IF(NEW.type_service = 'Express', v_d_exp, v_d_norm);
    SET NEW.taux_majoration_applique = IF(NEW.type_service = 'Express', v_maj, 0);
    SET NEW.tarif_kg_applique = v_kg, NEW.seuil_poids_applique = v_seuil, NEW.prix_hors_cat_applique = v_hc,
        NEW.delai_grace_applique = v_grace, NEW.frais_retard_applique = v_frais;
    SET NEW.date_paiement_integral = NULL, NEW.date_retrait_effective = NULL;

    -- RG19 à RG21 : réduction si le seuil est atteint dans l'agence de fidélité du client
    SET v_agence_client = (SELECT id_agence FROM client WHERE id_client = NEW.id_client);
    IF v_agence_client = NEW.id_agence AND fn_nb_commandes_eligibles(NEW.id_client) >= v_seuil_fid THEN
        SET NEW.taux_remise = v_taux_fid;
    ELSE
        SET NEW.taux_remise = 0;
    END IF;

    -- Numéro lisible : A<agence>-<AAMMJJ>-<rang du jour> (plus grand rang du jour + 1 : jamais de doublon)
    IF NEW.numero_commande IS NULL OR NEW.numero_commande = '' THEN
        SET v_prefixe = CONCAT('A', LPAD(NEW.id_agence, 2, '0'), '-', DATE_FORMAT(NOW(), '%y%m%d'), '-');
        SET NEW.numero_commande = CONCAT(v_prefixe, LPAD(
            (SELECT COALESCE(MAX(CAST(SUBSTRING_INDEX(numero_commande, '-', -1) AS UNSIGNED)), 0) + 1
               FROM commande WHERE numero_commande LIKE CONCAT(v_prefixe, '%')), 3, '0'));
    END IF;
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `trg_commande_bu`;
DELIMITER $$
CREATE TRIGGER `trg_commande_bu` BEFORE UPDATE ON `commande` FOR EACH ROW BEGIN
    DECLARE v_livreur INT UNSIGNED;
    DECLARE v_adresse VARCHAR(255);
    DECLARE v_duree SMALLINT UNSIGNED;
    DECLARE v_taux DECIMAL(5,2);

    -- Les choix et valeurs copiées sont figés dès que la commande n'est plus « Enregistrée »
    IF OLD.statut_commande <> 'Enregistrée'
       AND (NEW.type_service <> OLD.type_service OR NEW.mode_recuperation <> OLD.mode_recuperation
            OR NEW.taux_remise <> OLD.taux_remise OR NEW.id_client <> OLD.id_client OR NEW.id_agence <> OLD.id_agence
            OR NEW.duree_appliquee_h <> OLD.duree_appliquee_h OR NEW.tarif_kg_applique <> OLD.tarif_kg_applique
            OR NEW.taux_majoration_applique <> OLD.taux_majoration_applique) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG38 : une commande payée ne peut plus être modifiée.';
    END IF;
    IF OLD.statut_commande = 'Enregistrée' AND NEW.type_service <> OLD.type_service THEN
        SELECT IF(NEW.type_service = 'Express', duree_express_h, duree_normal_h),
               IF(NEW.type_service = 'Express', taux_majoration_express, 0)
          INTO v_duree, v_taux FROM agence WHERE id_agence = NEW.id_agence;
        SET NEW.duree_appliquee_h = v_duree, NEW.taux_majoration_applique = v_taux;
    END IF;

    IF NEW.statut_commande <> OLD.statut_commande THEN
        IF (OLD.statut_commande, NEW.statut_commande) NOT IN (
               ('Enregistrée', 'Payée'), ('Enregistrée', 'Annulée'), ('Payée', 'Annulée'), ('Payée', 'En traitement'),
               ('En traitement', 'Terminée'), ('Terminée', 'Partiellement retirée'), ('Terminée', 'Retirée'),
               ('Partiellement retirée', 'Retirée'), ('Terminée', 'En livraison'),
               ('Terminée', 'En attente de livreur'), ('En attente de livreur', 'En livraison'),
               ('En livraison', 'Livrée'), ('En livraison', 'En attente de livreur')) THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG34 : ce changement de statut de commande n'est pas autorisé.';
        END IF;

        -- RG50 : passage à « Payée » seulement quand la totalité est réglée
        IF NEW.statut_commande = 'Payée' THEN
            IF fn_total_paye(NEW.id_commande, 'Commande') < fn_montant_total(NEW.id_commande) THEN
                SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG50 : la commande n'est pas entièrement payée.';
            END IF;
            SET NEW.date_paiement_integral = COALESCE(NEW.date_paiement_integral, NOW());
        END IF;

        -- Début du traitement : les vêtements acceptés passent « En traitement »
        IF NEW.statut_commande = 'En traitement' THEN
            UPDATE vetement SET statut_vetement = 'En traitement'
             WHERE id_commande = NEW.id_commande AND statut_vetement = 'Accepté';
        END IF;

        -- Commande terminée : tous les vêtements acceptés doivent être prêts
        IF NEW.statut_commande = 'Terminée' THEN
            IF EXISTS (SELECT 1 FROM vetement WHERE id_commande = NEW.id_commande
                                               AND statut_vetement IN ('Accepté', 'En traitement')) THEN
                SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Tous les vêtements acceptés doivent être prêts.';
            END IF;
            IF NEW.mode_recuperation = 'Livraison' THEN
                -- RG62, RG63 : création de la livraison et recherche d'un livreur libre de l'agence
                SET v_adresse = (SELECT adresse_client FROM client WHERE id_client = NEW.id_client);
                SET v_livreur = (SELECT e.id_employe FROM employe e JOIN role r ON r.id_role = e.id_role
                                  WHERE r.libelle_role = 'Livreur' AND e.id_agence = NEW.id_agence
                                    AND e.statut_compte = 'Actif' AND e.disponibilite_livreur = 'Libre'
                                  ORDER BY e.id_employe LIMIT 1);
                IF v_livreur IS NULL THEN
                    INSERT INTO livraison (adresse_livraison, id_commande) VALUES (v_adresse, NEW.id_commande);
                    SET NEW.statut_commande = 'En attente de livreur';
                ELSE
                    INSERT INTO livraison (adresse_livraison, statut_livraison, date_assignation, id_commande, id_employe)
                    VALUES (v_adresse, 'Assignée', NOW(), NEW.id_commande, v_livreur);
                    UPDATE employe SET disponibilite_livreur = 'Occupé' WHERE id_employe = v_livreur;
                    INSERT INTO notification (type_notification, contenu, id_client, id_commande)
                    VALUES ('Affectation livreur', CONCAT('Un livreur a été affecté à votre commande n° ',
                            NEW.numero_commande, '.'), NEW.id_client, NEW.id_commande);
                END IF;
            ELSE
                INSERT INTO notification (type_notification, contenu, id_client, id_commande)
                VALUES ('Disponibilité', CONCAT('Vos vêtements (commande n° ', NEW.numero_commande,
                        ') sont prêts à être retirés.'), NEW.id_client, NEW.id_commande);
            END IF;
        END IF;

        -- RG90 : annulation journalisée
        IF NEW.statut_commande = 'Annulée' THEN
            INSERT INTO journal_action (type_action, entite_concernee, id_entite, detail_action, id_employe)
            VALUES ('Annulation', 'commande', NEW.id_commande, CONCAT('Annulation de la commande ', NEW.numero_commande),
                    COALESCE(@id_employe_session, NEW.id_employe));
        END IF;
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `employe`
--

DROP TABLE IF EXISTS `employe`;
CREATE TABLE IF NOT EXISTS `employe` (
  `id_employe` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom_employe` varchar(50) NOT NULL,
  `prenom_employe` varchar(50) DEFAULT NULL,
  `telephone_employe` varchar(20) NOT NULL,
  `email_employe` varchar(120) NOT NULL COMMENT 'Identifiant de connexion',
  `mot_de_passe` varchar(255) NOT NULL COMMENT 'Empreinte sécurisée, jamais en clair',
  `statut_compte` varchar(10) NOT NULL DEFAULT 'Actif',
  `date_embauche` date DEFAULT NULL,
  `disponibilite_livreur` varchar(12) DEFAULT NULL,
  `id_role` tinyint UNSIGNED NOT NULL,
  `id_agence` int UNSIGNED DEFAULT NULL,
  PRIMARY KEY (`id_employe`),
  UNIQUE KEY `uq_employe_email` (`email_employe`),
  KEY `fk_employe_role` (`id_role`),
  KEY `idx_employe_livreur` (`id_agence`,`disponibilite_livreur`)
) ;

--
-- Déchargement des données de la table `employe`
--

INSERT INTO `employe` (`id_employe`, `nom_employe`, `prenom_employe`, `telephone_employe`, `email_employe`, `mot_de_passe`, `statut_compte`, `date_embauche`, `disponibilite_livreur`, `id_role`, `id_agence`) VALUES
(1, 'Nama', 'luciano', '657867965', 'lucianonama1234@gmail.com', '$2y$10$QOk7AtEURRUqCm2fo.zGjOgJL5Y/XPXv8/mOR0EiTVWbwAE4jA5Tu', 'Actif', '2026-11-19', NULL, 1, NULL),
(2, 'Ngo Bassa', 'Carine', '677000000', 'gerant.bastos@demo.pressing', '$2y$10$QOk7AtEURRUqCm2fo.zGjOgJL5Y/XPXv8/mOR0EiTVWbwAE4jA5Tu', 'Actif', '2026-08-21', NULL, 2, 1),
(3, 'Essomba', 'Paul', '678234567', 'livreur1.bastos@demo.pressing', '$2y$10$QOk7AtEURRUqCm2fo.zGjOgJL5Y/XPXv8/mOR0EiTVWbwAE4jA5Tu', 'Actif', '2026-07-22', 'Libre', 3, 1),
(4, 'Mbarga', 'Hervé', '679469134', 'livreur2.bastos@demo.pressing', '$2y$10$SxswKVJGDSroF/HngY0On.43MoK3MAxa3ZpBaRntxg8g6oGLPvhxG', 'Actif', '2026-06-22', 'Libre', 3, 1),
(5, 'Ekwalla', 'Sandrine', '680703701', 'gerant.akwa@demo.pressing', '$2y$10$SxswKVJGDSroF/HngY0On.43MoK3MAxa3ZpBaRntxg8g6oGLPvhxG', 'Actif', '2026-05-23', NULL, 2, 2),
(6, 'Douala Manga', 'Joël', '681938268', 'livreur1.akwa@demo.pressing', '$2y$10$QOk7AtEURRUqCm2fo.zGjOgJL5Y/XPXv8/mOR0EiTVWbwAE4jA5Tu', 'Actif', '2026-04-23', 'Occupé', 3, 2),
(7, 'Admin', 'Démo', '600000000', 'admin@demo.pressing', '$2y$10$SxswKVJGDSroF/HngY0On.43MoK3MAxa3ZpBaRntxg8g6oGLPvhxG', 'Actif', NULL, NULL, 1, NULL);

--
-- Déclencheurs `employe`
--
DROP TRIGGER IF EXISTS `trg_employe_bi`;
DELIMITER $$
CREATE TRIGGER `trg_employe_bi` BEFORE INSERT ON `employe` FOR EACH ROW BEGIN
    DECLARE v_role VARCHAR(20);
    SET v_role = (SELECT libelle_role FROM role WHERE id_role = NEW.id_role);
    IF v_role = 'Administrateur' AND NEW.id_agence IS NOT NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG09 : l'administrateur n'est rattaché à aucune agence.';
    END IF;
    IF v_role <> 'Administrateur' AND NEW.id_agence IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG09 : un gérant ou un livreur est rattaché à une agence.';
    END IF;
    IF v_role = 'Livreur' THEN
        SET NEW.disponibilite_livreur = COALESCE(NEW.disponibilite_livreur, 'Libre');
    ELSE
        SET NEW.disponibilite_livreur = NULL;               -- RG14 : livreurs uniquement
    END IF;
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `trg_employe_bu`;
DELIMITER $$
CREATE TRIGGER `trg_employe_bu` BEFORE UPDATE ON `employe` FOR EACH ROW BEGIN
    DECLARE v_role VARCHAR(20);
    SET v_role = (SELECT libelle_role FROM role WHERE id_role = NEW.id_role);
    IF (v_role = 'Administrateur') <> (NEW.id_agence IS NULL) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG09 : seul l'administrateur n'a pas d'agence.';
    END IF;
    IF v_role <> 'Livreur' THEN
        SET NEW.disponibilite_livreur = NULL;
    ELSEIF NEW.disponibilite_livreur IS NULL THEN
        SET NEW.disponibilite_livreur = 'Libre';
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `facture`
--

DROP TABLE IF EXISTS `facture`;
CREATE TABLE IF NOT EXISTS `facture` (
  `id_facture` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `numero_facture` varchar(40) NOT NULL,
  `type_facture` varchar(15) NOT NULL,
  `date_facture` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `montant_facture` decimal(12,2) NOT NULL COMMENT 'Figé à l''émission, non modifiable',
  `id_commande` int UNSIGNED NOT NULL,
  PRIMARY KEY (`id_facture`),
  UNIQUE KEY `uq_facture_numero` (`numero_facture`),
  UNIQUE KEY `uq_facture_commande_type` (`id_commande`,`type_facture`)
) ;

--
-- Déchargement des données de la table `facture`
--

INSERT INTO `facture` (`id_facture`, `numero_facture`, `type_facture`, `date_facture`, `montant_facture`, `id_commande`) VALUES
(1, 'FP-A01-261119-001', 'Principale', '2026-11-19 13:28:38', 4800.00, 1),
(2, 'FP-A01-261119-002', 'Principale', '2026-11-19 13:28:38', 5850.00, 2),
(3, 'FP-A01-261119-003', 'Principale', '2026-11-19 13:28:38', 6200.00, 3),
(4, 'FP-A01-261119-004', 'Principale', '2026-11-19 13:28:38', 1700.00, 4),
(5, 'FP-A01-261119-005', 'Principale', '2026-11-19 13:28:38', 4850.00, 5),
(6, 'FP-A02-261119-001', 'Principale', '2026-11-19 13:28:38', 5850.00, 7),
(7, 'FP-A02-261119-002', 'Principale', '2026-11-19 13:28:38', 4375.00, 8),
(8, 'FP-A02-261120-001', 'Principale', '2026-11-20 20:38:30', 4000.00, 10);

--
-- Déclencheurs `facture`
--
DROP TRIGGER IF EXISTS `trg_facture_bd`;
DELIMITER $$
CREATE TRIGGER `trg_facture_bd` BEFORE DELETE ON `facture` FOR EACH ROW BEGIN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG56 : une facture émise ne peut pas être supprimée.';
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `trg_facture_bu`;
DELIMITER $$
CREATE TRIGGER `trg_facture_bu` BEFORE UPDATE ON `facture` FOR EACH ROW BEGIN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG56 : une facture émise ne peut pas être modifiée.';
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `impliquer`
--

DROP TABLE IF EXISTS `impliquer`;
CREATE TABLE IF NOT EXISTS `impliquer` (
  `id_incident` int UNSIGNED NOT NULL,
  `id_vetement` int UNSIGNED NOT NULL,
  PRIMARY KEY (`id_incident`,`id_vetement`),
  KEY `fk_impliquer_vetement` (`id_vetement`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Vêtements concernés par un incident (association n,n)';

--
-- Déclencheurs `impliquer`
--
DROP TRIGGER IF EXISTS `trg_impliquer_bi`;
DELIMITER $$
CREATE TRIGGER `trg_impliquer_bi` BEFORE INSERT ON `impliquer` FOR EACH ROW BEGIN
    IF (SELECT id_commande FROM incident WHERE id_incident = NEW.id_incident)
       <> (SELECT id_commande FROM vetement WHERE id_vetement = NEW.id_vetement) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG81 : le vêtement doit appartenir à la commande de l'incident.';
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `incident`
--

DROP TABLE IF EXISTS `incident`;
CREATE TABLE IF NOT EXISTS `incident` (
  `id_incident` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `date_incident` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `type_incident` varchar(25) NOT NULL,
  `motif_incident` varchar(255) NOT NULL,
  `description_incident` text,
  `statut_incident` varchar(10) NOT NULL DEFAULT 'En attente',
  `observation` text,
  `solution_apportee` varchar(255) DEFAULT NULL,
  `montant_compensation` decimal(10,2) NOT NULL DEFAULT '0.00',
  `date_cloture` datetime DEFAULT NULL,
  `id_commande` int UNSIGNED NOT NULL,
  `id_employe` int UNSIGNED NOT NULL COMMENT 'Employé qui a déclaré l''incident',
  PRIMARY KEY (`id_incident`),
  KEY `fk_incident_commande` (`id_commande`),
  KEY `fk_incident_employe` (`id_employe`)
) ;

--
-- Déclencheurs `incident`
--
DROP TRIGGER IF EXISTS `trg_incident_bu`;
DELIMITER $$
CREATE TRIGGER `trg_incident_bu` BEFORE UPDATE ON `incident` FOR EACH ROW BEGIN
    IF NEW.statut_incident = 'Clôturé' AND OLD.statut_incident <> 'Clôturé' THEN
        SET NEW.date_cloture = COALESCE(NEW.date_cloture, NOW());
        INSERT INTO journal_action (type_action, entite_concernee, id_entite, detail_action, id_employe)
        VALUES ('Modification', 'incident', NEW.id_incident, CONCAT('Clôture : ', NEW.solution_apportee),
                COALESCE(@id_employe_session, NEW.id_employe));               -- RG90
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `journal_action`
--

DROP TABLE IF EXISTS `journal_action`;
CREATE TABLE IF NOT EXISTS `journal_action` (
  `id_action` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `date_action` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `type_action` varchar(15) NOT NULL,
  `entite_concernee` varchar(40) NOT NULL,
  `id_entite` bigint UNSIGNED NOT NULL,
  `detail_action` text NOT NULL,
  `id_employe` int UNSIGNED NOT NULL,
  PRIMARY KEY (`id_action`),
  KEY `fk_journal_employe` (`id_employe`),
  KEY `idx_journal_date` (`date_action`)
) ;

--
-- Déchargement des données de la table `journal_action`
--

INSERT INTO `journal_action` (`id_action`, `date_action`, `type_action`, `entite_concernee`, `id_entite`, `detail_action`, `id_employe`) VALUES
(1, '2026-11-19 13:28:38', 'Création', 'paiement', 1, 'Commande : 4800.00 FCFA (Espèces)', 2),
(2, '2026-11-19 13:28:38', 'Création', 'paiement', 2, 'Commande : 5850.00 FCFA (Espèces)', 2),
(3, '2026-11-19 13:28:38', 'Création', 'paiement', 3, 'Commande : 3100.00 FCFA (MTN Mobile Money)', 2),
(4, '2026-11-19 13:28:38', 'Création', 'paiement', 4, 'Commande : 3100.00 FCFA (Espèces)', 2),
(5, '2026-11-19 13:28:38', 'Création', 'paiement', 5, 'Commande : 1700.00 FCFA (Espèces)', 2),
(6, '2026-11-19 13:28:38', 'Création', 'paiement', 6, 'Commande : 4850.00 FCFA (Espèces)', 2),
(7, '2026-11-19 13:28:38', 'Création', 'paiement', 7, 'Commande : 2925.00 FCFA (MTN Mobile Money)', 5),
(8, '2026-11-19 13:28:38', 'Création', 'paiement', 8, 'Commande : 2925.00 FCFA (Espèces)', 5),
(9, '2026-11-19 13:28:38', 'Création', 'paiement', 9, 'Commande : 4375.00 FCFA (Espèces)', 5),
(10, '2026-11-19 13:29:00', 'Connexion', 'employe', 1, 'Connexion à l\'application', 1),
(11, '2026-11-19 13:29:46', 'Connexion', 'employe', 1, 'Connexion à l\'application', 1),
(12, '2026-11-19 21:43:11', 'Connexion', 'employe', 1, 'Connexion à l\'application', 1),
(13, '2026-11-19 21:45:26', 'Connexion', 'employe', 1, 'Connexion à l\'application', 1),
(14, '2026-11-19 21:45:57', 'Connexion', 'employe', 1, 'Connexion à l\'application', 1),
(15, '2026-11-19 21:48:19', 'Connexion', 'employe', 2, 'Connexion à l\'application', 2),
(16, '2026-11-19 21:50:56', 'Connexion', 'employe', 2, 'Connexion à l\'application', 2),
(17, '2026-11-19 21:51:20', 'Connexion', 'employe', 3, 'Connexion à l\'application', 3),
(18, '2026-11-19 21:53:25', 'Connexion', 'employe', 2, 'Connexion à l\'application', 2),
(19, '2026-11-19 21:56:52', 'Connexion', 'employe', 1, 'Connexion à l\'application', 1),
(20, '2026-11-20 07:57:39', 'Connexion', 'employe', 3, 'Connexion à l\'application', 3),
(21, '2026-11-20 08:15:05', 'Connexion', 'employe', 3, 'Connexion à l\'application', 3),
(22, '2026-11-20 12:12:05', 'Connexion', 'employe', 7, 'Connexion à l\'application', 7),
(23, '2026-11-20 20:31:42', 'Connexion', 'employe', 7, 'Connexion à l\'application', 7),
(24, '2026-11-20 20:33:30', 'Connexion', 'employe', 5, 'Connexion à l\'application', 5),
(25, '2026-11-20 20:38:30', 'Création', 'paiement', 10, 'Commande : 4000.00 FCFA (Espèces)', 5),
(26, '2026-11-20 20:40:27', 'Connexion', 'employe', 4, 'Connexion à l\'application', 4),
(27, '2026-11-20 20:42:49', 'Connexion', 'employe', 3, 'Connexion à l\'application', 3),
(28, '2026-11-20 20:45:38', 'Modification', 'employe', 3, 'Modification du compte livreur1.bastos@demo.pressing', 7),
(29, '2026-11-21 13:36:51', 'Connexion', 'employe', 6, 'Connexion à l\'application', 6),
(30, '2026-11-21 13:41:46', 'Annulation', 'commande', 11, 'Annulation de la commande A02-261121-001', 5),
(31, '2026-11-21 19:39:30', 'Connexion', 'employe', 7, 'Connexion à l\'application', 7),
(32, '2026-11-21 19:40:10', 'Connexion', 'employe', 1, 'Connexion à l\'application', 1),
(33, '2026-11-22 18:09:28', 'Connexion', 'employe', 7, 'Connexion à l\'application', 7),
(34, '2026-11-22 18:10:00', 'Connexion', 'employe', 4, 'Connexion à l\'application', 4),
(35, '2026-11-22 18:10:17', 'Connexion', 'employe', 3, 'Connexion à l\'application', 3);

--
-- Déclencheurs `journal_action`
--
DROP TRIGGER IF EXISTS `trg_journal_bd`;
DELIMITER $$
CREATE TRIGGER `trg_journal_bd` BEFORE DELETE ON `journal_action` FOR EACH ROW BEGIN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG91 : le journal ne peut pas être supprimé.';
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `trg_journal_bu`;
DELIMITER $$
CREATE TRIGGER `trg_journal_bu` BEFORE UPDATE ON `journal_action` FOR EACH ROW BEGIN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG91 : le journal ne peut pas être modifié.';
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `livraison`
--

DROP TABLE IF EXISTS `livraison`;
CREATE TABLE IF NOT EXISTS `livraison` (
  `id_livraison` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `adresse_livraison` varchar(255) NOT NULL,
  `statut_livraison` varchar(25) NOT NULL DEFAULT 'En attente de livreur',
  `date_creation_livraison` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_assignation` datetime DEFAULT NULL,
  `date_recuperation_agence` datetime DEFAULT NULL,
  `date_livraison` datetime DEFAULT NULL,
  `mode_validation` varchar(15) DEFAULT NULL,
  `nb_tentatives` tinyint UNSIGNED NOT NULL DEFAULT '0',
  `motif_echec` varchar(255) DEFAULT NULL,
  `id_commande` int UNSIGNED NOT NULL,
  `id_employe` int UNSIGNED DEFAULT NULL COMMENT 'Livreur affecté',
  PRIMARY KEY (`id_livraison`),
  UNIQUE KEY `uq_livraison_commande` (`id_commande`),
  KEY `fk_livraison_employe` (`id_employe`),
  KEY `idx_livraison_attente` (`statut_livraison`,`date_creation_livraison`)
) ;

--
-- Déchargement des données de la table `livraison`
--

INSERT INTO `livraison` (`id_livraison`, `adresse_livraison`, `statut_livraison`, `date_creation_livraison`, `date_assignation`, `date_recuperation_agence`, `date_livraison`, `mode_validation`, `nb_tentatives`, `motif_echec`, `id_commande`, `id_employe`) VALUES
(1, 'Odza, carrefour Bel-Air', 'Livrée', '2026-11-19 13:28:38', '2026-11-19 13:28:38', '2026-11-19 21:51:41', '2026-11-20 08:15:56', 'Code numérique', 0, NULL, 3, 3),
(2, 'Bonapriso, rue Njo-Njo', 'Livrée', '2026-11-19 13:28:38', '2026-11-19 13:28:38', '2026-11-21 13:37:01', '2026-11-21 13:39:11', 'Code numérique', 0, NULL, 7, 6),
(3, 'Bonapriso, rue Njo-Njo', 'En cours', '2026-11-20 20:39:44', '2026-11-21 13:39:11', '2026-11-21 13:39:32', NULL, NULL, 0, NULL, 10, 6);

--
-- Déclencheurs `livraison`
--
DROP TRIGGER IF EXISTS `trg_livraison_au`;
DELIMITER $$
CREATE TRIGGER `trg_livraison_au` AFTER UPDATE ON `livraison` FOR EACH ROW BEGIN
    DECLARE v_client INT UNSIGNED;
    DECLARE v_numero VARCHAR(30);
    IF NEW.statut_livraison <> OLD.statut_livraison THEN
        SELECT id_client, numero_commande INTO v_client, v_numero FROM commande WHERE id_commande = NEW.id_commande;
        IF NEW.statut_livraison = 'Assignée' THEN
            UPDATE employe SET disponibilite_livreur = 'Occupé' WHERE id_employe = NEW.id_employe;
            INSERT INTO notification (type_notification, contenu, id_client, id_commande)
            VALUES ('Affectation livreur', CONCAT('Un livreur a été affecté à votre commande n° ', v_numero, '.'),
                    v_client, NEW.id_commande);
        ELSEIF NEW.statut_livraison = 'En cours' THEN
            UPDATE commande SET statut_commande = 'En livraison' WHERE id_commande = NEW.id_commande;
        ELSEIF NEW.statut_livraison = 'Livrée' THEN
            UPDATE commande SET statut_commande = 'Livrée', date_retrait_effective = NEW.date_livraison
             WHERE id_commande = NEW.id_commande;
            UPDATE vetement SET statut_vetement = 'Livré' WHERE id_commande = NEW.id_commande AND statut_vetement = 'Prêt';
            UPDATE code_validation SET statut_code = 'Utilisé', date_utilisation = NEW.date_livraison
             WHERE id_commande = NEW.id_commande AND statut_code = 'Actif';
            UPDATE employe SET disponibilite_livreur = 'Libre' WHERE id_employe = NEW.id_employe;     -- RG70
            INSERT INTO notification (type_notification, contenu, id_client, id_commande)
            VALUES ('Livraison', CONCAT('Votre commande n° ', v_numero, ' a été livrée.'), v_client, NEW.id_commande);
        ELSEIF NEW.statut_livraison = 'Échouée' THEN
            UPDATE employe SET disponibilite_livreur = 'Libre' WHERE id_employe = NEW.id_employe;     -- RG70
            UPDATE commande SET statut_commande = 'En attente de livreur'
             WHERE id_commande = NEW.id_commande AND statut_commande IN ('Terminée', 'En livraison');
        END IF;
    END IF;
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `trg_livraison_bu`;
DELIMITER $$
CREATE TRIGGER `trg_livraison_bu` BEFORE UPDATE ON `livraison` FOR EACH ROW BEGIN
    DECLARE v_agence INT UNSIGNED;
    IF NEW.statut_livraison <> OLD.statut_livraison THEN
        IF (OLD.statut_livraison, NEW.statut_livraison) NOT IN (
               ('En attente de livreur', 'Assignée'), ('Assignée', 'En cours'), ('En cours', 'Livrée'),
               ('Assignée', 'Échouée'), ('En cours', 'Échouée'), ('Échouée', 'En attente de livreur')) THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Ce changement de statut de livraison n'est pas autorisé.';
        END IF;
        IF NEW.statut_livraison = 'Assignée' THEN          -- RG63, RG65
            SET v_agence = (SELECT id_agence FROM commande WHERE id_commande = NEW.id_commande);
            IF NOT EXISTS (SELECT 1 FROM employe e JOIN role r ON r.id_role = e.id_role
                            WHERE e.id_employe = NEW.id_employe AND r.libelle_role = 'Livreur'
                              AND e.id_agence = v_agence AND e.statut_compte = 'Actif'
                              AND e.disponibilite_livreur = 'Libre') THEN
                SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG65 : la livraison va à un livreur libre de l'agence de la commande.';
            END IF;
            SET NEW.date_assignation = NOW();
        END IF;
        IF NEW.statut_livraison = 'En cours' THEN          -- RG66
            SET NEW.date_recuperation_agence = NOW();
        END IF;
        IF NEW.statut_livraison = 'Livrée' THEN            -- RG67, RG68
            IF NOT EXISTS (SELECT 1 FROM preuve_livraison WHERE id_livraison = NEW.id_livraison) THEN
                SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG68 : une livraison ne se clôture pas sans photo justificative.';
            END IF;
            SET NEW.date_livraison = COALESCE(NEW.date_livraison, NOW());
        END IF;
        IF NEW.statut_livraison = 'Échouée' THEN           -- RG69
            SET NEW.nb_tentatives = OLD.nb_tentatives + 1;
        END IF;
        IF NEW.statut_livraison = 'En attente de livreur' THEN   -- reprogrammation
            SET NEW.id_employe = NULL, NEW.date_assignation = NULL, NEW.date_recuperation_agence = NULL;
        END IF;
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `notification`
--

DROP TABLE IF EXISTS `notification`;
CREATE TABLE IF NOT EXISTS `notification` (
  `id_notification` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `type_notification` varchar(20) NOT NULL,
  `canal` varchar(10) NOT NULL DEFAULT 'WhatsApp',
  `contenu` text NOT NULL,
  `date_notification` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `statut_envoi` varchar(10) NOT NULL DEFAULT 'En attente',
  `resultat` varchar(255) DEFAULT NULL,
  `id_client` int UNSIGNED NOT NULL,
  `id_commande` int UNSIGNED DEFAULT NULL,
  PRIMARY KEY (`id_notification`),
  KEY `fk_notification_client` (`id_client`),
  KEY `fk_notification_commande` (`id_commande`)
) ;

--
-- Déchargement des données de la table `notification`
--

INSERT INTO `notification` (`id_notification`, `type_notification`, `canal`, `contenu`, `date_notification`, `statut_envoi`, `resultat`, `id_client`, `id_commande`) VALUES
(1, 'Dépôt', 'WhatsApp', 'Votre dépôt n° A01-261119-001 est enregistré.', '2026-11-19 13:28:38', 'En attente', NULL, 1, 1),
(2, 'Code de validation', 'WhatsApp', 'Paiement reçu pour la commande n° A01-261119-001. Votre code de validation : 612889 (QR code joint).', '2026-11-19 13:28:38', 'En attente', NULL, 1, 1),
(3, 'Disponibilité', 'WhatsApp', 'Vos vêtements (commande n° A01-261119-001) sont prêts à être retirés.', '2026-11-19 13:28:38', 'En attente', NULL, 1, 1),
(4, 'Dépôt', 'WhatsApp', 'Votre dépôt n° A01-261119-002 est enregistré.', '2026-11-19 13:28:38', 'En attente', NULL, 2, 2),
(5, 'Code de validation', 'WhatsApp', 'Paiement reçu pour la commande n° A01-261119-002. Votre code de validation : 803862 (QR code joint).', '2026-11-19 13:28:38', 'En attente', NULL, 2, 2),
(6, 'Disponibilité', 'WhatsApp', 'Vos vêtements (commande n° A01-261119-002) sont prêts à être retirés.', '2026-11-19 13:28:38', 'En attente', NULL, 2, 2),
(7, 'Dépôt', 'WhatsApp', 'Votre dépôt n° A01-261119-003 est enregistré.', '2026-11-19 13:28:38', 'En attente', NULL, 4, 3),
(8, 'Code de validation', 'WhatsApp', 'Paiement reçu pour la commande n° A01-261119-003. Votre code de validation : 757382 (QR code joint).', '2026-11-19 13:28:38', 'En attente', NULL, 4, 3),
(9, 'Affectation livreur', 'WhatsApp', 'Un livreur a été affecté à votre commande n° A01-261119-003.', '2026-11-19 13:28:38', 'En attente', NULL, 4, 3),
(10, 'Dépôt', 'WhatsApp', 'Votre dépôt n° A01-261119-004 est enregistré.', '2026-11-19 13:28:38', 'En attente', NULL, 3, 4),
(11, 'Code de validation', 'WhatsApp', 'Paiement reçu pour la commande n° A01-261119-004. Votre code de validation : 155504 (QR code joint).', '2026-11-19 13:28:38', 'En attente', NULL, 3, 4),
(12, 'Dépôt', 'WhatsApp', 'Votre dépôt n° A01-261119-005 est enregistré.', '2026-11-19 13:28:38', 'En attente', NULL, 1, 5),
(13, 'Code de validation', 'WhatsApp', 'Paiement reçu pour la commande n° A01-261119-005. Votre code de validation : 138142 (QR code joint).', '2026-11-19 13:28:38', 'En attente', NULL, 1, 5),
(14, 'Dépôt', 'WhatsApp', 'Votre dépôt n° A01-261119-006 est enregistré.', '2026-11-19 13:28:38', 'En attente', NULL, 2, 6),
(15, 'Dépôt', 'WhatsApp', 'Votre dépôt n° A02-261119-001 est enregistré.', '2026-11-21 13:42:10', 'Envoyée', 'Envoi simulé depuis l\'application', 5, 7),
(16, 'Code de validation', 'WhatsApp', 'Paiement reçu pour la commande n° A02-261119-001. Votre code de validation : 225159 (QR code joint).', '2026-11-21 13:42:10', 'Envoyée', 'Envoi simulé depuis l\'application', 5, 7),
(17, 'Affectation livreur', 'WhatsApp', 'Un livreur a été affecté à votre commande n° A02-261119-001.', '2026-11-21 13:42:10', 'Envoyée', 'Envoi simulé depuis l\'application', 5, 7),
(18, 'Dépôt', 'WhatsApp', 'Votre dépôt n° A02-261119-002 est enregistré.', '2026-11-21 13:42:10', 'Envoyée', 'Envoi simulé depuis l\'application', 6, 8),
(19, 'Code de validation', 'WhatsApp', 'Paiement reçu pour la commande n° A02-261119-002. Votre code de validation : 034747 (QR code joint).', '2026-11-21 13:42:10', 'Envoyée', 'Envoi simulé depuis l\'application', 6, 8),
(20, 'Dépôt', 'WhatsApp', 'Votre dépôt n° A01-261119-007 est enregistré.', '2026-11-19 21:58:12', 'En attente', NULL, 2, 9),
(21, 'Livraison', 'WhatsApp', 'Votre commande n° A01-261119-003 a été livrée.', '2026-11-20 08:15:56', 'En attente', NULL, 4, 3),
(22, 'Disponibilité', 'WhatsApp', 'Vos vêtements (commande n° A02-261119-002) sont prêts à être retirés.', '2026-11-21 13:42:10', 'Envoyée', 'Envoi simulé depuis l\'application', 6, 8),
(23, 'Dépôt', 'WhatsApp', 'Votre dépôt n° A02-261120-001 est enregistré.', '2026-11-21 13:42:10', 'Envoyée', 'Envoi simulé depuis l\'application', 5, 10),
(24, 'Code de validation', 'WhatsApp', 'Paiement reçu pour la commande n° A02-261120-001. Votre code de validation : 376826 (QR code joint).', '2026-11-21 13:42:10', 'Envoyée', 'Envoi simulé depuis l\'application', 5, 10),
(25, 'Livraison', 'WhatsApp', 'Votre commande n° A02-261119-001 a été livrée.', '2026-11-21 13:42:10', 'Envoyée', 'Envoi simulé depuis l\'application', 5, 7),
(26, 'Affectation livreur', 'WhatsApp', 'Un livreur a été affecté à votre commande n° A02-261120-001.', '2026-11-21 13:42:10', 'Envoyée', 'Envoi simulé depuis l\'application', 5, 10),
(27, 'Dépôt', 'WhatsApp', 'Votre dépôt n° A02-261121-001 est enregistré.', '2026-11-21 13:42:10', 'Envoyée', 'Envoi simulé depuis l\'application', 6, 11);

--
-- Déclencheurs `notification`
--
DROP TRIGGER IF EXISTS `trg_notification_bi`;
DELIMITER $$
CREATE TRIGGER `trg_notification_bi` BEFORE INSERT ON `notification` FOR EACH ROW BEGIN
    IF NEW.id_commande IS NOT NULL
       AND (SELECT id_client FROM commande WHERE id_commande = NEW.id_commande) <> NEW.id_client THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG84 : la notification porte sur une commande du client.';
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `paiement`
--

DROP TABLE IF EXISTS `paiement`;
CREATE TABLE IF NOT EXISTS `paiement` (
  `id_paiement` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `montant_paiement` decimal(10,2) NOT NULL,
  `date_paiement` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `mode_paiement` varchar(20) NOT NULL,
  `reference_paiement` varchar(60) DEFAULT NULL,
  `objet_paiement` varchar(15) NOT NULL DEFAULT 'Commande',
  `id_commande` int UNSIGNED NOT NULL,
  `id_employe` int UNSIGNED NOT NULL COMMENT 'Gérant qui a encaissé (RG53)',
  PRIMARY KEY (`id_paiement`),
  UNIQUE KEY `uq_paiement_reference` (`reference_paiement`),
  KEY `fk_paiement_commande` (`id_commande`),
  KEY `fk_paiement_employe` (`id_employe`),
  KEY `idx_paiement_date` (`date_paiement`)
) ;

--
-- Déchargement des données de la table `paiement`
--

INSERT INTO `paiement` (`id_paiement`, `montant_paiement`, `date_paiement`, `mode_paiement`, `reference_paiement`, `objet_paiement`, `id_commande`, `id_employe`) VALUES
(1, 4800.00, '2026-11-13 09:38:38', 'Espèces', NULL, 'Commande', 1, 2),
(2, 5850.00, '2026-11-14 10:38:38', 'Espèces', NULL, 'Commande', 2, 2),
(3, 3100.00, '2026-11-15 11:38:38', 'MTN Mobile Money', 'MP261119527048', 'Commande', 3, 2),
(4, 3100.00, '2026-11-15 11:38:38', 'Espèces', NULL, 'Commande', 3, 2),
(5, 1700.00, '2026-11-16 11:38:38', 'Espèces', NULL, 'Commande', 4, 2),
(6, 4850.00, '2026-11-18 10:38:38', 'Espèces', NULL, 'Commande', 5, 2),
(7, 2925.00, '2026-11-17 10:38:38', 'MTN Mobile Money', 'MP261119495066', 'Commande', 7, 5),
(8, 2925.00, '2026-11-17 10:38:38', 'Espèces', NULL, 'Commande', 7, 5),
(9, 4375.00, '2026-11-18 11:38:38', 'Espèces', NULL, 'Commande', 8, 5),
(10, 4000.00, '2026-11-20 20:38:30', 'Espèces', NULL, 'Commande', 10, 5);

--
-- Déclencheurs `paiement`
--
DROP TRIGGER IF EXISTS `trg_paiement_ai`;
DELIMITER $$
CREATE TRIGGER `trg_paiement_ai` AFTER INSERT ON `paiement` FOR EACH ROW BEGIN
    DECLARE v_total DECIMAL(12,2);
    DECLARE v_numero VARCHAR(30);
    DECLARE v_client INT UNSIGNED;
    DECLARE v_code CHAR(6);
    INSERT INTO journal_action (type_action, entite_concernee, id_entite, detail_action, id_employe)
    VALUES ('Création', 'paiement', NEW.id_paiement,
            CONCAT(NEW.objet_paiement, ' : ', NEW.montant_paiement, ' FCFA (', NEW.mode_paiement, ')'), NEW.id_employe);
    IF NEW.objet_paiement = 'Commande' THEN
        SET v_total = fn_montant_total(NEW.id_commande);
        IF fn_total_paye(NEW.id_commande, 'Commande') >= v_total THEN
            SELECT numero_commande, id_client INTO v_numero, v_client FROM commande WHERE id_commande = NEW.id_commande;
            UPDATE commande SET statut_commande = 'Payée', date_paiement_integral = NOW() WHERE id_commande = NEW.id_commande;
            INSERT INTO facture (numero_facture, type_facture, montant_facture, id_commande)
            VALUES (CONCAT('FP-', v_numero), 'Principale', v_total, NEW.id_commande);
            SET v_code = LPAD(FLOOR(RAND() * 1000000), 6, '0');
            INSERT INTO code_validation (valeur_qr, code_numerique, id_commande)
            VALUES (SHA2(CONCAT(UUID(), RAND()), 256), v_code, NEW.id_commande);
            INSERT INTO notification (type_notification, contenu, id_client, id_commande)
            VALUES ('Code de validation', CONCAT('Paiement reçu pour la commande n° ', v_numero,
                    '. Votre code de validation : ', v_code, ' (QR code joint).'), v_client, NEW.id_commande);
        END IF;
    END IF;
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `trg_paiement_bd`;
DELIMITER $$
CREATE TRIGGER `trg_paiement_bd` BEFORE DELETE ON `paiement` FOR EACH ROW BEGIN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Un paiement enregistré ne se supprime pas.';
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `trg_paiement_bi`;
DELIMITER $$
CREATE TRIGGER `trg_paiement_bi` BEFORE INSERT ON `paiement` FOR EACH ROW BEGIN
    DECLARE v_statut VARCHAR(25);
    DECLARE v_agence INT UNSIGNED;
    DECLARE v_mode VARCHAR(10);
    SELECT statut_commande, id_agence, mode_recuperation INTO v_statut, v_agence, v_mode
      FROM commande WHERE id_commande = NEW.id_commande;
    IF v_statut = 'Annulée' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Paiement impossible : la commande est annulée.';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM employe e JOIN role r ON r.id_role = e.id_role
                    WHERE e.id_employe = NEW.id_employe AND r.libelle_role = 'Gérant'
                      AND e.id_agence = v_agence AND e.statut_compte = 'Actif') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG53 : un paiement est enregistré par un gérant de l'agence (le livreur n'encaisse pas).';
    END IF;
    IF NEW.objet_paiement = 'Commande' THEN
        IF v_statut <> 'Enregistrée' THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG50 : la commande est déjà entièrement payée.';
        END IF;
        IF fn_total_paye(NEW.id_commande, 'Commande') + NEW.montant_paiement > fn_montant_total(NEW.id_commande) THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG51 : la somme des paiements dépasserait le montant dû.';
        END IF;
    ELSE
        IF v_mode <> 'Retrait' THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG78 : pas de frais de retard pour une commande livrée.';
        END IF;
        IF fn_total_paye(NEW.id_commande, 'Frais de retard') + NEW.montant_paiement > fn_frais_retard(NEW.id_commande, FALSE) THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG51 : le montant dépasse les frais de retard dus.';
        END IF;
    END IF;
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `trg_paiement_bu`;
DELIMITER $$
CREATE TRIGGER `trg_paiement_bu` BEFORE UPDATE ON `paiement` FOR EACH ROW BEGIN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Un paiement enregistré ne se modifie pas.';
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `preuve_livraison`
--

DROP TABLE IF EXISTS `preuve_livraison`;
CREATE TABLE IF NOT EXISTS `preuve_livraison` (
  `id_preuve` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `url_photo` varchar(255) NOT NULL,
  `date_prise` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_livraison` int UNSIGNED NOT NULL,
  PRIMARY KEY (`id_preuve`),
  KEY `fk_preuve_livraison` (`id_livraison`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Photos justificatives des livraisons (JUSTIFIER)';

--
-- Déchargement des données de la table `preuve_livraison`
--

INSERT INTO `preuve_livraison` (`id_preuve`, `url_photo`, `date_prise`, `id_livraison`) VALUES
(1, 'uploads/preuves/2026-11/L1-49212709295d.jpg', '2026-11-20 08:15:56', 1),
(2, 'uploads/preuves/2026-11/L2-3fca2eda4ce2.jpg', '2026-11-21 13:39:11', 2);

-- --------------------------------------------------------

--
-- Structure de la table `retrait`
--

DROP TABLE IF EXISTS `retrait`;
CREATE TABLE IF NOT EXISTS `retrait` (
  `id_retrait` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `date_retrait` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `nom_retirant` varchar(100) NOT NULL,
  `est_client` tinyint(1) NOT NULL,
  `mode_verification` varchar(15) NOT NULL,
  `type_piece_identite` varchar(20) DEFAULT NULL,
  `num_piece_identite` varchar(30) DEFAULT NULL,
  `id_commande` int UNSIGNED NOT NULL,
  `id_employe` int UNSIGNED NOT NULL COMMENT 'Gérant qui a validé le retrait',
  PRIMARY KEY (`id_retrait`),
  KEY `fk_retrait_commande` (`id_commande`),
  KEY `fk_retrait_employe` (`id_employe`)
) ;

--
-- Déchargement des données de la table `retrait`
--

INSERT INTO `retrait` (`id_retrait`, `date_retrait`, `nom_retirant`, `est_client`, `mode_verification`, `type_piece_identite`, `num_piece_identite`, `id_commande`, `id_employe`) VALUES
(1, '2026-11-19 13:28:38', 'Brice Atangana', 1, 'Code numérique', NULL, NULL, 1, 2),
(2, '2026-11-20 20:35:14', 'Grâce Eyenga', 1, 'Code numérique', NULL, NULL, 8, 5);

--
-- Déclencheurs `retrait`
--
DROP TRIGGER IF EXISTS `trg_retrait_bi`;
DELIMITER $$
CREATE TRIGGER `trg_retrait_bi` BEFORE INSERT ON `retrait` FOR EACH ROW BEGIN
    DECLARE v_statut VARCHAR(25);
    DECLARE v_agence INT UNSIGNED;
    DECLARE v_mode VARCHAR(10);
    SELECT statut_commande, id_agence, mode_recuperation INTO v_statut, v_agence, v_mode
      FROM commande WHERE id_commande = NEW.id_commande;
    IF v_mode <> 'Retrait' OR v_statut NOT IN ('Terminée', 'Partiellement retirée') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Retrait impossible : la commande n'est pas prête au retrait en agence.';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM employe e JOIN role r ON r.id_role = e.id_role
                    WHERE e.id_employe = NEW.id_employe AND r.libelle_role = 'Gérant' AND e.id_agence = v_agence) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG71 : le retrait est enregistré par un gérant de l'agence.';
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `role`
--

DROP TABLE IF EXISTS `role`;
CREATE TABLE IF NOT EXISTS `role` (
  `id_role` tinyint UNSIGNED NOT NULL AUTO_INCREMENT,
  `libelle_role` varchar(20) NOT NULL,
  PRIMARY KEY (`id_role`),
  UNIQUE KEY `uq_role_libelle` (`libelle_role`)
) ;

--
-- Déchargement des données de la table `role`
--

INSERT INTO `role` (`id_role`, `libelle_role`) VALUES
(1, 'Administrateur'),
(2, 'Gérant'),
(3, 'Livreur');

-- --------------------------------------------------------

--
-- Structure de la table `supplement`
--

DROP TABLE IF EXISTS `supplement`;
CREATE TABLE IF NOT EXISTS `supplement` (
  `id_supplement` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `libelle_supplement` varchar(60) NOT NULL,
  `description_supplement` varchar(255) DEFAULT NULL,
  `portee_supplement` varchar(10) NOT NULL,
  PRIMARY KEY (`id_supplement`),
  UNIQUE KEY `uq_supplement_libelle` (`libelle_supplement`)
) ;

--
-- Déchargement des données de la table `supplement`
--

INSERT INTO `supplement` (`id_supplement`, `libelle_supplement`, `description_supplement`, `portee_supplement`) VALUES
(1, 'Repassage', 'Repassage du vêtement', 'Vêtement'),
(2, 'Blanchissage', 'Blanchiment du linge blanc', 'Vêtement'),
(3, 'Détachage', 'Traitement des taches', 'Vêtement'),
(4, 'Livraison à domicile', 'Livraison de la commande à l\'adresse du client', 'Commande');

-- --------------------------------------------------------

--
-- Structure de la table `supplement_applique`
--

DROP TABLE IF EXISTS `supplement_applique`;
CREATE TABLE IF NOT EXISTS `supplement_applique` (
  `id_supp_applique` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `prix_supp_applique` decimal(10,2) NOT NULL COMMENT 'Prix copié depuis l''agence (RG38)',
  `quantite_supp` smallint UNSIGNED NOT NULL DEFAULT '1',
  `id_commande` int UNSIGNED NOT NULL,
  `id_supplement` int UNSIGNED NOT NULL,
  `id_vetement` int UNSIGNED DEFAULT NULL,
  PRIMARY KEY (`id_supp_applique`),
  KEY `fk_supp_applique_commande` (`id_commande`),
  KEY `fk_supp_applique_supplement` (`id_supplement`),
  KEY `fk_supp_applique_vetement` (`id_vetement`)
) ;

--
-- Déchargement des données de la table `supplement_applique`
--

INSERT INTO `supplement_applique` (`id_supp_applique`, `prix_supp_applique`, `quantite_supp`, `id_commande`, `id_supplement`, `id_vetement`) VALUES
(1, 300.00, 1, 1, 1, 1),
(2, 1500.00, 1, 3, 4, NULL),
(3, 700.00, 1, 3, 3, 7),
(4, 300.00, 1, 5, 1, 15),
(5, 1600.00, 1, 7, 4, NULL),
(6, 800.00, 1, 8, 3, 20),
(7, 1500.00, 1, 9, 4, NULL),
(8, 1600.00, 1, 10, 4, NULL),
(9, 400.00, 1, 10, 1, 21);

--
-- Déclencheurs `supplement_applique`
--
DROP TRIGGER IF EXISTS `trg_supp_applique_bi`;
DELIMITER $$
CREATE TRIGGER `trg_supp_applique_bi` BEFORE INSERT ON `supplement_applique` FOR EACH ROW BEGIN
    DECLARE v_statut VARCHAR(25);
    DECLARE v_agence INT UNSIGNED;
    DECLARE v_portee VARCHAR(10);
    DECLARE v_prix DECIMAL(10,2);
    SELECT statut_commande, id_agence INTO v_statut, v_agence FROM commande WHERE id_commande = NEW.id_commande;
    IF v_statut <> 'Enregistrée' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Un supplément ne s'ajoute qu'à une commande « Enregistrée ».';
    END IF;
    SET v_portee = (SELECT portee_supplement FROM supplement WHERE id_supplement = NEW.id_supplement);
    SET v_prix = (SELECT prix_supplement FROM tarif_supplement
                   WHERE id_agence = v_agence AND id_supplement = NEW.id_supplement AND actif_supplement = TRUE);
    IF v_prix IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG42 : ce supplément n'est pas proposé dans l'agence.';
    END IF;
    SET NEW.prix_supp_applique = v_prix;                  -- RG38 : prix copié
    IF v_portee = 'Commande' THEN
        IF NEW.id_vetement IS NOT NULL THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG44 : un supplément de portée « Commande » ne vise pas un vêtement.';
        END IF;
        IF EXISTS (SELECT 1 FROM supplement_applique
                    WHERE id_commande = NEW.id_commande AND id_supplement = NEW.id_supplement) THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG44 : un supplément de portée « Commande » s'applique une seule fois.';
        END IF;
        SET NEW.quantite_supp = 1;
    ELSE
        IF NEW.id_vetement IS NULL
           OR (SELECT id_commande FROM vetement WHERE id_vetement = NEW.id_vetement) <> NEW.id_commande THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG44 : un supplément de portée « Vêtement » vise un vêtement de la commande.';
        END IF;
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `tarif_categorie`
--

DROP TABLE IF EXISTS `tarif_categorie`;
CREATE TABLE IF NOT EXISTS `tarif_categorie` (
  `id_agence` int UNSIGNED NOT NULL,
  `id_categorie` int UNSIGNED NOT NULL,
  `prix_categorie` decimal(10,2) NOT NULL COMMENT 'Prix à la pièce, calculé pour l''état le plus sale (RG24)',
  `unite_facturation` varchar(6) NOT NULL,
  `actif_tarif` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_agence`,`id_categorie`),
  KEY `fk_tarif_categorie_categorie` (`id_categorie`)
) ;

--
-- Déchargement des données de la table `tarif_categorie`
--

INSERT INTO `tarif_categorie` (`id_agence`, `id_categorie`, `prix_categorie`, `unite_facturation`, `actif_tarif`) VALUES
(1, 1, 3500.00, 'Pièce', 1),
(1, 2, 2500.00, 'Pièce', 1),
(1, 3, 2000.00, 'Pièce', 1),
(1, 4, 600.00, 'Poids', 1),
(2, 1, 3750.00, 'Pièce', 1),
(2, 2, 2750.00, 'Pièce', 1),
(2, 3, 2250.00, 'Pièce', 1),
(2, 4, 850.00, 'Poids', 1);

--
-- Déclencheurs `tarif_categorie`
--
DROP TRIGGER IF EXISTS `trg_tarif_categorie_au`;
DELIMITER $$
CREATE TRIGGER `trg_tarif_categorie_au` AFTER UPDATE ON `tarif_categorie` FOR EACH ROW BEGIN
    IF @id_employe_session IS NOT NULL THEN
        INSERT INTO journal_action (type_action, entite_concernee, id_entite, detail_action, id_employe)
        VALUES ('Modification', 'tarif_categorie', NEW.id_categorie,
                CONCAT('Agence ', NEW.id_agence, ' : ', OLD.prix_categorie, ' -> ', NEW.prix_categorie, ' FCFA (',
                       NEW.unite_facturation, ')'), @id_employe_session);
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `tarif_supplement`
--

DROP TABLE IF EXISTS `tarif_supplement`;
CREATE TABLE IF NOT EXISTS `tarif_supplement` (
  `id_agence` int UNSIGNED NOT NULL,
  `id_supplement` int UNSIGNED NOT NULL,
  `prix_supplement` decimal(10,2) NOT NULL,
  `actif_supplement` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_agence`,`id_supplement`),
  KEY `fk_tarif_supplement_supplement` (`id_supplement`)
) ;

--
-- Déchargement des données de la table `tarif_supplement`
--

INSERT INTO `tarif_supplement` (`id_agence`, `id_supplement`, `prix_supplement`, `actif_supplement`) VALUES
(1, 1, 300.00, 1),
(1, 2, 500.00, 1),
(1, 3, 700.00, 1),
(1, 4, 1500.00, 1),
(2, 1, 400.00, 1),
(2, 2, 600.00, 1),
(2, 3, 800.00, 1),
(2, 4, 1600.00, 1);

--
-- Déclencheurs `tarif_supplement`
--
DROP TRIGGER IF EXISTS `trg_tarif_supplement_au`;
DELIMITER $$
CREATE TRIGGER `trg_tarif_supplement_au` AFTER UPDATE ON `tarif_supplement` FOR EACH ROW BEGIN
    IF @id_employe_session IS NOT NULL THEN
        INSERT INTO journal_action (type_action, entite_concernee, id_entite, detail_action, id_employe)
        VALUES ('Modification', 'tarif_supplement', NEW.id_supplement,
                CONCAT('Agence ', NEW.id_agence, ' : ', OLD.prix_supplement, ' -> ', NEW.prix_supplement, ' FCFA'),
                @id_employe_session);
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `vetement`
--

DROP TABLE IF EXISTS `vetement`;
CREATE TABLE IF NOT EXISTS `vetement` (
  `id_vetement` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `code_etiquette` varchar(40) NOT NULL,
  `poids_kg` decimal(6,3) NOT NULL,
  `etat_initial` varchar(255) NOT NULL,
  `anomalies` varchar(255) DEFAULT NULL,
  `prix_applique` decimal(10,2) DEFAULT NULL COMMENT 'Prix de la catégorie copié au dépôt ; NULL si lot au poids',
  `majoration_speciale` decimal(10,2) NOT NULL DEFAULT '0.00',
  `accord_client` tinyint(1) NOT NULL DEFAULT '0',
  `date_accord` datetime DEFAULT NULL,
  `statut_vetement` varchar(15) NOT NULL DEFAULT 'Accepté',
  `motif_refus` varchar(255) DEFAULT NULL,
  `id_commande` int UNSIGNED NOT NULL,
  `id_article` int UNSIGNED NOT NULL,
  `id_retrait` int UNSIGNED DEFAULT NULL COMMENT 'Retrait au cours duquel le vêtement a été remis (RG72)',
  PRIMARY KEY (`id_vetement`),
  UNIQUE KEY `uq_vetement_etiquette` (`code_etiquette`),
  KEY `fk_vetement_commande` (`id_commande`),
  KEY `fk_vetement_article` (`id_article`),
  KEY `fk_vetement_retrait` (`id_retrait`)
) ;

--
-- Déchargement des données de la table `vetement`
--

INSERT INTO `vetement` (`id_vetement`, `code_etiquette`, `poids_kg`, `etat_initial`, `anomalies`, `prix_applique`, `majoration_speciale`, `accord_client`, `date_accord`, `statut_vetement`, `motif_refus`, `id_commande`, `id_article`, `id_retrait`) VALUES
(1, 'A01-261119-001-01', 1.800, 'Bon état', NULL, 3500.00, 0.00, 0, NULL, 'Retiré', NULL, 1, 1, 1),
(2, 'A01-261119-001-02', 0.300, 'Col légèrement jauni', NULL, NULL, 0.00, 0, NULL, 'Retiré', NULL, 1, 11, 1),
(3, 'A01-261119-001-03', 0.600, 'Bon état', NULL, NULL, 0.00, 0, NULL, 'Retiré', NULL, 1, 12, 1),
(4, 'A01-261119-002-01', 0.900, 'Paillettes fragiles', NULL, 2500.00, 0.00, 0, NULL, 'Prêt', NULL, 2, 5, NULL),
(5, 'A01-261119-002-02', 1.200, 'Bon état', NULL, 2000.00, 0.00, 0, NULL, 'Prêt', NULL, 2, 7, NULL),
(6, 'A01-261119-003-01', 2.600, 'Bon état', NULL, 2000.00, 0.00, 0, NULL, 'Livré', NULL, 3, 8, NULL),
(7, 'A01-261119-003-02', 1.400, 'Poussiéreux', NULL, 2000.00, 0.00, 0, NULL, 'Livré', NULL, 3, 9, NULL),
(8, 'A01-261119-004-01', 0.300, 'Bon état', NULL, NULL, 0.00, 0, NULL, 'Prêt', NULL, 4, 11, NULL),
(9, 'A01-261119-004-02', 0.300, 'Tache d\'encre', NULL, NULL, 0.00, 0, NULL, 'En traitement', NULL, 4, 11, NULL),
(10, 'A01-261119-004-03', 0.200, 'Bon état', NULL, NULL, 0.00, 0, NULL, 'En traitement', NULL, 4, 13, NULL),
(11, 'A01-261119-004-04', 0.700, 'Bon état', NULL, NULL, 0.00, 0, NULL, 'En traitement', NULL, 4, 12, NULL),
(12, 'A01-261119-004-05', 0.400, 'Bon état', NULL, NULL, 0.00, 0, NULL, 'En traitement', NULL, 4, 14, NULL),
(13, 'A01-261119-004-06', 0.800, 'Bon état', NULL, NULL, 0.00, 0, NULL, 'En traitement', NULL, 4, 15, NULL),
(14, 'A01-261119-004-07', 0.700, 'Ourlet décousu', NULL, NULL, 0.00, 0, NULL, 'En traitement', NULL, 4, 12, NULL),
(15, 'A01-261119-005-01', 1.100, 'Bon état', NULL, 3500.00, 0.00, 0, NULL, 'Accepté', NULL, 5, 2, NULL),
(16, 'A01-261119-006-01', 0.700, 'Bon état', NULL, 2500.00, 0.00, 0, NULL, 'Accepté', NULL, 6, 4, NULL),
(17, 'A01-261119-006-02', 0.900, 'Taches de vin', NULL, 2000.00, 0.00, 0, NULL, 'Accepté', NULL, 6, 10, NULL),
(18, 'A02-261119-001-01', 1.900, 'Bon état', NULL, 3750.00, 0.00, 0, NULL, 'Livré', NULL, 7, 1, NULL),
(19, 'A02-261119-001-02', 0.300, 'Bon état', NULL, NULL, 0.00, 0, NULL, 'Livré', NULL, 7, 11, NULL),
(20, 'A02-261119-002-01', 3.200, 'Traîne tachée de terre', NULL, 2750.00, 0.00, 0, NULL, 'Retiré', NULL, 8, 6, 2),
(21, 'A02-261120-001-01', 0.059, 'Bon état', NULL, NULL, 0.00, 1, '2026-11-20 20:37:15', 'Prêt', NULL, 10, 13, NULL),
(22, 'A02-261120-001-02', 0.059, 'Bon état', NULL, NULL, 0.00, 1, '2026-11-20 20:37:15', 'Prêt', NULL, 10, 13, NULL),
(23, 'A02-261120-001-03', 0.059, 'Bon état', NULL, NULL, 0.00, 1, '2026-11-20 20:37:15', 'Prêt', NULL, 10, 13, NULL),
(24, 'A02-261120-001-04', 0.059, 'Bon état', NULL, NULL, 0.00, 1, '2026-11-20 20:37:15', 'Prêt', NULL, 10, 13, NULL);

--
-- Déclencheurs `vetement`
--
DROP TRIGGER IF EXISTS `trg_vetement_au`;
DELIMITER $$
CREATE TRIGGER `trg_vetement_au` AFTER UPDATE ON `vetement` FOR EACH ROW BEGIN
    DECLARE v_numero VARCHAR(30);
    DECLARE v_frais DECIMAL(12,2);
    IF NEW.id_retrait IS NOT NULL AND OLD.id_retrait IS NULL THEN
        IF NOT EXISTS (SELECT 1 FROM vetement WHERE id_commande = NEW.id_commande
                                               AND statut_vetement NOT IN ('Refusé', 'Retiré')) THEN
            UPDATE commande SET statut_commande = 'Retirée', date_retrait_effective = NOW()
             WHERE id_commande = NEW.id_commande;
            UPDATE code_validation SET statut_code = 'Utilisé', date_utilisation = NOW()
             WHERE id_commande = NEW.id_commande AND statut_code = 'Actif';
            -- RG55 : facture complémentaire si des frais de retard ont été réglés
            SET v_frais = fn_total_paye(NEW.id_commande, 'Frais de retard');
            IF v_frais > 0 THEN
                SET v_numero = (SELECT numero_commande FROM commande WHERE id_commande = NEW.id_commande);
                INSERT INTO facture (numero_facture, type_facture, montant_facture, id_commande)
                VALUES (CONCAT('FR-', v_numero), 'Frais de retard', v_frais, NEW.id_commande);
            END IF;
        ELSE
            UPDATE commande SET statut_commande = 'Partiellement retirée'
             WHERE id_commande = NEW.id_commande AND statut_commande = 'Terminée';
        END IF;
    END IF;
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `trg_vetement_bi`;
DELIMITER $$
CREATE TRIGGER `trg_vetement_bi` BEFORE INSERT ON `vetement` FOR EACH ROW BEGIN
    DECLARE v_statut VARCHAR(25);
    DECLARE v_agence INT UNSIGNED;
    DECLARE v_numero VARCHAR(30);
    DECLARE v_prix DECIMAL(10,2);
    DECLARE v_unite VARCHAR(6);
    SELECT statut_commande, id_agence, numero_commande INTO v_statut, v_agence, v_numero
      FROM commande WHERE id_commande = NEW.id_commande;
    IF v_statut <> 'Enregistrée' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Un vêtement ne peut être ajouté qu'à une commande « Enregistrée ».';
    END IF;
    SELECT t.prix_categorie, t.unite_facturation INTO v_prix, v_unite
      FROM article a JOIN tarif_categorie t ON t.id_categorie = a.id_categorie AND t.id_agence = v_agence
     WHERE a.id_article = NEW.id_article AND t.actif_tarif = TRUE;
    IF v_unite IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'La catégorie de cet article n'est pas proposée dans l'agence.';
    END IF;
    IF NEW.statut_vetement = 'Refusé' THEN                -- RG30 : non facturé, hors lot
        SET NEW.prix_applique = NULL, NEW.majoration_speciale = 0;
    ELSE
        SET NEW.statut_vetement = 'Accepté';
        SET NEW.prix_applique = IF(v_unite = 'Pièce', v_prix, NULL);   -- RG27 : tri automatique
    END IF;
    SET NEW.id_retrait = NULL;
    IF NEW.code_etiquette IS NULL OR NEW.code_etiquette = '' THEN
        SET NEW.code_etiquette = CONCAT(v_numero, '-',
            LPAD((SELECT COUNT(*) + 1 FROM vetement WHERE id_commande = NEW.id_commande), 2, '0'));
    END IF;
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `trg_vetement_bu`;
DELIMITER $$
CREATE TRIGGER `trg_vetement_bu` BEFORE UPDATE ON `vetement` FOR EACH ROW BEGIN
    DECLARE v_statut VARCHAR(25);
    DECLARE v_frais_dus, v_frais_payes DECIMAL(12,2);
    DECLARE v_limite DATE;
    DECLARE v_frais_jour DECIMAL(10,2);
    SELECT statut_commande INTO v_statut FROM commande WHERE id_commande = OLD.id_commande;

    -- Données du dépôt figées après le paiement (RG38)
    IF v_statut <> 'Enregistrée'
       AND (NEW.poids_kg <> OLD.poids_kg OR NOT (NEW.prix_applique <=> OLD.prix_applique)
            OR NEW.majoration_speciale <> OLD.majoration_speciale OR NEW.id_article <> OLD.id_article
            OR NEW.id_commande <> OLD.id_commande OR (NEW.statut_vetement = 'Refusé' AND OLD.statut_vetement <> 'Refusé')) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG38 : un vêtement ne se modifie plus après le paiement.';
    END IF;
    IF NEW.statut_vetement = 'Refusé' AND OLD.statut_vetement <> 'Refusé' THEN
        SET NEW.prix_applique = NULL, NEW.majoration_speciale = 0;
    END IF;

    -- Remise du vêtement lors d'un retrait
    IF NEW.id_retrait IS NOT NULL AND OLD.id_retrait IS NULL THEN
        IF OLD.statut_vetement <> 'Prêt' THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG72 : seul un vêtement prêt et non encore remis peut être retiré.';
        END IF;
        IF (SELECT id_commande FROM retrait WHERE id_retrait = NEW.id_retrait) <> OLD.id_commande THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Ce retrait concerne une autre commande.';
        END IF;
        -- RG77 : les frais de retard des vêtements remis doivent être réglés avant la remise
        SELECT DATE(date_paiement_integral + INTERVAL duree_appliquee_h HOUR) + INTERVAL delai_grace_applique DAY,
               frais_retard_applique INTO v_limite, v_frais_jour FROM commande WHERE id_commande = OLD.id_commande;
        SET v_frais_dus = fn_frais_retard(OLD.id_commande, TRUE) + GREATEST(0, DATEDIFF(NOW(), v_limite)) * v_frais_jour;
        SET v_frais_payes = fn_total_paye(OLD.id_commande, 'Frais de retard');
        IF v_frais_payes < v_frais_dus THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG77 : les frais de retard doivent être réglés avant la remise.';
        END IF;
        SET NEW.statut_vetement = 'Retiré';
    ELSEIF NEW.id_retrait IS NULL AND OLD.id_retrait IS NOT NULL OR NEW.id_retrait <> OLD.id_retrait THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'RG72 : un vêtement ne peut être retiré qu'une seule fois.';
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `v_agences_sans_gerant`
-- (Voir ci-dessous la vue réelle)
--
DROP VIEW IF EXISTS `v_agences_sans_gerant`;
CREATE TABLE IF NOT EXISTS `v_agences_sans_gerant` (
`id_agence` int unsigned
,`nom_agence` varchar(60)
);

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `v_fidelite_clients`
-- (Voir ci-dessous la vue réelle)
--
DROP VIEW IF EXISTS `v_fidelite_clients`;
CREATE TABLE IF NOT EXISTS `v_fidelite_clients` (
`id_client` int unsigned
,`nom_client` varchar(50)
,`prenom_client` varchar(50)
,`id_agence` int unsigned
,`nb_commandes_eligibles` int
,`seuil_fidelite` smallint unsigned
,`reduction_disponible` int
);

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `v_frais_retard`
-- (Voir ci-dessous la vue réelle)
--
DROP VIEW IF EXISTS `v_frais_retard`;
CREATE TABLE IF NOT EXISTS `v_frais_retard` (
`id_commande` int unsigned
,`numero_commande` varchar(30)
,`id_agence` int unsigned
,`telephone_client` varchar(20)
,`fin_delai_grace` datetime
,`vetements_restants` bigint
,`frais_retard_dus` decimal(12,2)
,`frais_retard_payes` decimal(12,2)
);

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `v_livraisons_en_attente`
-- (Voir ci-dessous la vue réelle)
--
DROP VIEW IF EXISTS `v_livraisons_en_attente`;
CREATE TABLE IF NOT EXISTS `v_livraisons_en_attente` (
`id_livraison` int unsigned
,`date_creation_livraison` datetime
,`nb_tentatives` tinyint unsigned
,`id_agence` int unsigned
,`numero_commande` varchar(30)
,`nom_client` varchar(50)
,`telephone_client` varchar(20)
,`adresse_livraison` varchar(255)
);

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `v_livraisons_livreur`
-- (Voir ci-dessous la vue réelle)
--
DROP VIEW IF EXISTS `v_livraisons_livreur`;
CREATE TABLE IF NOT EXISTS `v_livraisons_livreur` (
`id_employe` int unsigned
,`id_livraison` int unsigned
,`statut_livraison` varchar(25)
,`numero_commande` varchar(30)
,`client` varchar(101)
,`telephone_client` varchar(20)
,`adresse_livraison` varchar(255)
);

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `v_livreurs_libres`
-- (Voir ci-dessous la vue réelle)
--
DROP VIEW IF EXISTS `v_livreurs_libres`;
CREATE TABLE IF NOT EXISTS `v_livreurs_libres` (
`id_employe` int unsigned
,`nom_employe` varchar(50)
,`prenom_employe` varchar(50)
,`telephone_employe` varchar(20)
,`id_agence` int unsigned
);

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `v_lot_poids`
-- (Voir ci-dessous la vue réelle)
--
DROP VIEW IF EXISTS `v_lot_poids`;
CREATE TABLE IF NOT EXISTS `v_lot_poids` (
`id_commande` int unsigned
,`numero_commande` varchar(30)
,`poids_lot_kg` decimal(28,3)
,`nb_vetements_lot` bigint
,`mode_facturation_lot` varchar(5)
);

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `v_montants_commande`
-- (Voir ci-dessous la vue réelle)
--
DROP VIEW IF EXISTS `v_montants_commande`;
CREATE TABLE IF NOT EXISTS `v_montants_commande` (
`id_commande` int unsigned
,`numero_commande` varchar(30)
,`id_agence` int unsigned
,`statut_commande` varchar(25)
,`type_service` varchar(10)
,`mode_recuperation` varchar(10)
,`id_client` int unsigned
,`client` varchar(101)
,`montant_vetements` decimal(12,2)
,`montant_majoration` decimal(14,0)
,`montant_supplements` decimal(12,2)
,`taux_remise` decimal(5,2)
,`montant_total` decimal(12,2)
,`montant_paye` decimal(12,2)
,`reste_a_payer` decimal(13,2)
,`date_retrait_prevue` datetime
);

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `v_rappels_a_envoyer`
-- (Voir ci-dessous la vue réelle)
--
DROP VIEW IF EXISTS `v_rappels_a_envoyer`;
CREATE TABLE IF NOT EXISTS `v_rappels_a_envoyer` (
`id_commande` int unsigned
,`numero_commande` varchar(30)
,`id_client` int unsigned
,`telephone_client` varchar(20)
,`date_retrait_prevue` datetime
,`fin_delai_grace` datetime
);

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `v_tableau_bord_agence`
-- (Voir ci-dessous la vue réelle)
--
DROP VIEW IF EXISTS `v_tableau_bord_agence`;
CREATE TABLE IF NOT EXISTS `v_tableau_bord_agence` (
`id_agence` int unsigned
,`nom_agence` varchar(60)
,`chiffre_affaires` decimal(32,2)
,`commandes_en_cours` bigint
,`vetements_traites` bigint
,`livraisons_effectuees` bigint
,`livraisons_en_attente` bigint
,`incidents_ouverts` bigint
);

-- --------------------------------------------------------

--
-- Structure de la vue `v_agences_sans_gerant`
--
DROP TABLE IF EXISTS `v_agences_sans_gerant`;

DROP VIEW IF EXISTS `v_agences_sans_gerant`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_agences_sans_gerant`  AS SELECT `a`.`id_agence` AS `id_agence`, `a`.`nom_agence` AS `nom_agence` FROM `agence` AS `a` WHERE ((`a`.`statut_agence` = 'Active') AND exists(select 1 from (`employe` `e` join `role` `r` on((`r`.`id_role` = `e`.`id_role`))) where ((`e`.`id_agence` = `a`.`id_agence`) AND (`r`.`libelle_role` = 'Gérant') AND (`e`.`statut_compte` = 'Actif'))) is false) ;

-- --------------------------------------------------------

--
-- Structure de la vue `v_fidelite_clients`
--
DROP TABLE IF EXISTS `v_fidelite_clients`;

DROP VIEW IF EXISTS `v_fidelite_clients`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_fidelite_clients`  AS SELECT `cl`.`id_client` AS `id_client`, `cl`.`nom_client` AS `nom_client`, `cl`.`prenom_client` AS `prenom_client`, `cl`.`id_agence` AS `id_agence`, `fn_nb_commandes_eligibles`(`cl`.`id_client`) AS `nb_commandes_eligibles`, `a`.`seuil_fidelite` AS `seuil_fidelite`, (`fn_nb_commandes_eligibles`(`cl`.`id_client`) >= `a`.`seuil_fidelite`) AS `reduction_disponible` FROM (`client` `cl` join `agence` `a` on((`a`.`id_agence` = `cl`.`id_agence`))) ;

-- --------------------------------------------------------

--
-- Structure de la vue `v_frais_retard`
--
DROP TABLE IF EXISTS `v_frais_retard`;

DROP VIEW IF EXISTS `v_frais_retard`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_frais_retard`  AS SELECT `c`.`id_commande` AS `id_commande`, `c`.`numero_commande` AS `numero_commande`, `c`.`id_agence` AS `id_agence`, `cl`.`telephone_client` AS `telephone_client`, (`fn_date_retrait_prevue`(`c`.`id_commande`) + interval `c`.`delai_grace_applique` day) AS `fin_delai_grace`, (select count(0) from `vetement` `v` where ((`v`.`id_commande` = `c`.`id_commande`) and (`v`.`statut_vetement` = 'Prêt'))) AS `vetements_restants`, `fn_frais_retard`(`c`.`id_commande`,false) AS `frais_retard_dus`, `fn_total_paye`(`c`.`id_commande`,'Frais de retard') AS `frais_retard_payes` FROM (`commande` `c` join `client` `cl` on((`cl`.`id_client` = `c`.`id_client`))) WHERE ((`c`.`mode_recuperation` = 'Retrait') AND (`c`.`statut_commande` in ('Terminée','Partiellement retirée')) AND (`fn_frais_retard`(`c`.`id_commande`,false) > 0)) ;

-- --------------------------------------------------------

--
-- Structure de la vue `v_livraisons_en_attente`
--
DROP TABLE IF EXISTS `v_livraisons_en_attente`;

DROP VIEW IF EXISTS `v_livraisons_en_attente`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_livraisons_en_attente`  AS SELECT `l`.`id_livraison` AS `id_livraison`, `l`.`date_creation_livraison` AS `date_creation_livraison`, `l`.`nb_tentatives` AS `nb_tentatives`, `c`.`id_agence` AS `id_agence`, `c`.`numero_commande` AS `numero_commande`, `cl`.`nom_client` AS `nom_client`, `cl`.`telephone_client` AS `telephone_client`, `l`.`adresse_livraison` AS `adresse_livraison` FROM ((`livraison` `l` join `commande` `c` on((`c`.`id_commande` = `l`.`id_commande`))) join `client` `cl` on((`cl`.`id_client` = `c`.`id_client`))) WHERE (`l`.`statut_livraison` = 'En attente de livreur') ORDER BY `c`.`id_agence` ASC, `l`.`date_creation_livraison` ASC ;

-- --------------------------------------------------------

--
-- Structure de la vue `v_livraisons_livreur`
--
DROP TABLE IF EXISTS `v_livraisons_livreur`;

DROP VIEW IF EXISTS `v_livraisons_livreur`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_livraisons_livreur`  AS SELECT `l`.`id_employe` AS `id_employe`, `l`.`id_livraison` AS `id_livraison`, `l`.`statut_livraison` AS `statut_livraison`, `c`.`numero_commande` AS `numero_commande`, concat(`cl`.`nom_client`,' ',coalesce(`cl`.`prenom_client`,'')) AS `client`, `cl`.`telephone_client` AS `telephone_client`, `l`.`adresse_livraison` AS `adresse_livraison` FROM ((`livraison` `l` join `commande` `c` on((`c`.`id_commande` = `l`.`id_commande`))) join `client` `cl` on((`cl`.`id_client` = `c`.`id_client`))) WHERE (`l`.`statut_livraison` in ('Assignée','En cours')) ;

-- --------------------------------------------------------

--
-- Structure de la vue `v_livreurs_libres`
--
DROP TABLE IF EXISTS `v_livreurs_libres`;

DROP VIEW IF EXISTS `v_livreurs_libres`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_livreurs_libres`  AS SELECT `e`.`id_employe` AS `id_employe`, `e`.`nom_employe` AS `nom_employe`, `e`.`prenom_employe` AS `prenom_employe`, `e`.`telephone_employe` AS `telephone_employe`, `e`.`id_agence` AS `id_agence` FROM (`employe` `e` join `role` `r` on((`r`.`id_role` = `e`.`id_role`))) WHERE ((`r`.`libelle_role` = 'Livreur') AND (`e`.`statut_compte` = 'Actif') AND (`e`.`disponibilite_livreur` = 'Libre')) ;

-- --------------------------------------------------------

--
-- Structure de la vue `v_lot_poids`
--
DROP TABLE IF EXISTS `v_lot_poids`;

DROP VIEW IF EXISTS `v_lot_poids`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_lot_poids`  AS SELECT `c`.`id_commande` AS `id_commande`, `c`.`numero_commande` AS `numero_commande`, coalesce(sum(`v`.`poids_kg`),0) AS `poids_lot_kg`, count(`v`.`id_vetement`) AS `nb_vetements_lot`, (case when (count(`v`.`id_vetement`) = 0) then NULL when (sum(`v`.`poids_kg`) >= `c`.`seuil_poids_applique`) then 'Poids' else 'Pièce' end) AS `mode_facturation_lot` FROM (`commande` `c` left join `vetement` `v` on(((`v`.`id_commande` = `c`.`id_commande`) and (`v`.`prix_applique` is null) and (`v`.`statut_vetement` <> 'Refusé')))) GROUP BY `c`.`id_commande`, `c`.`numero_commande`, `c`.`seuil_poids_applique` ;

-- --------------------------------------------------------

--
-- Structure de la vue `v_montants_commande`
--
DROP TABLE IF EXISTS `v_montants_commande`;

DROP VIEW IF EXISTS `v_montants_commande`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_montants_commande`  AS SELECT `c`.`id_commande` AS `id_commande`, `c`.`numero_commande` AS `numero_commande`, `c`.`id_agence` AS `id_agence`, `c`.`statut_commande` AS `statut_commande`, `c`.`type_service` AS `type_service`, `c`.`mode_recuperation` AS `mode_recuperation`, `cl`.`id_client` AS `id_client`, concat(`cl`.`nom_client`,' ',coalesce(`cl`.`prenom_client`,'')) AS `client`, `fn_montant_vetements`(`c`.`id_commande`) AS `montant_vetements`, round(((`fn_montant_vetements`(`c`.`id_commande`) * `c`.`taux_majoration_applique`) / 100),0) AS `montant_majoration`, `fn_montant_supplements`(`c`.`id_commande`) AS `montant_supplements`, `c`.`taux_remise` AS `taux_remise`, `fn_montant_total`(`c`.`id_commande`) AS `montant_total`, `fn_total_paye`(`c`.`id_commande`,'Commande') AS `montant_paye`, (`fn_montant_total`(`c`.`id_commande`) - `fn_total_paye`(`c`.`id_commande`,'Commande')) AS `reste_a_payer`, `fn_date_retrait_prevue`(`c`.`id_commande`) AS `date_retrait_prevue` FROM (`commande` `c` join `client` `cl` on((`cl`.`id_client` = `c`.`id_client`))) ;

-- --------------------------------------------------------

--
-- Structure de la vue `v_rappels_a_envoyer`
--
DROP TABLE IF EXISTS `v_rappels_a_envoyer`;

DROP VIEW IF EXISTS `v_rappels_a_envoyer`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_rappels_a_envoyer`  AS SELECT `c`.`id_commande` AS `id_commande`, `c`.`numero_commande` AS `numero_commande`, `cl`.`id_client` AS `id_client`, `cl`.`telephone_client` AS `telephone_client`, `fn_date_retrait_prevue`(`c`.`id_commande`) AS `date_retrait_prevue`, (`fn_date_retrait_prevue`(`c`.`id_commande`) + interval `c`.`delai_grace_applique` day) AS `fin_delai_grace` FROM (`commande` `c` join `client` `cl` on((`cl`.`id_client` = `c`.`id_client`))) WHERE ((`c`.`mode_recuperation` = 'Retrait') AND (`c`.`statut_commande` in ('Terminée','Partiellement retirée')) AND (now() between `fn_date_retrait_prevue`(`c`.`id_commande`) and (`fn_date_retrait_prevue`(`c`.`id_commande`) + interval `c`.`delai_grace_applique` day))) ;

-- --------------------------------------------------------

--
-- Structure de la vue `v_tableau_bord_agence`
--
DROP TABLE IF EXISTS `v_tableau_bord_agence`;

DROP VIEW IF EXISTS `v_tableau_bord_agence`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_tableau_bord_agence`  AS SELECT `a`.`id_agence` AS `id_agence`, `a`.`nom_agence` AS `nom_agence`, (select coalesce(sum(`p`.`montant_paiement`),0) from (`paiement` `p` join `commande` `c` on((`c`.`id_commande` = `p`.`id_commande`))) where (`c`.`id_agence` = `a`.`id_agence`)) AS `chiffre_affaires`, (select count(0) from `commande` `c` where ((`c`.`id_agence` = `a`.`id_agence`) and (`c`.`statut_commande` not in ('Retirée','Livrée','Annulée')))) AS `commandes_en_cours`, (select count(0) from (`vetement` `v` join `commande` `c` on((`c`.`id_commande` = `v`.`id_commande`))) where ((`c`.`id_agence` = `a`.`id_agence`) and (`v`.`statut_vetement` in ('Retiré','Livré')))) AS `vetements_traites`, (select count(0) from (`livraison` `l` join `commande` `c` on((`c`.`id_commande` = `l`.`id_commande`))) where ((`c`.`id_agence` = `a`.`id_agence`) and (`l`.`statut_livraison` = 'Livrée'))) AS `livraisons_effectuees`, (select count(0) from (`livraison` `l` join `commande` `c` on((`c`.`id_commande` = `l`.`id_commande`))) where ((`c`.`id_agence` = `a`.`id_agence`) and (`l`.`statut_livraison` = 'En attente de livreur'))) AS `livraisons_en_attente`, (select count(0) from (`incident` `i` join `commande` `c` on((`c`.`id_commande` = `i`.`id_commande`))) where ((`c`.`id_agence` = `a`.`id_agence`) and (`i`.`statut_incident` <> 'Clôturé'))) AS `incidents_ouverts` FROM `agence` AS `a` ;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `article`
--
ALTER TABLE `article`
  ADD CONSTRAINT `fk_article_categorie` FOREIGN KEY (`id_categorie`) REFERENCES `categorie_article` (`id_categorie`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Contraintes pour la table `client`
--
ALTER TABLE `client`
  ADD CONSTRAINT `fk_client_agence` FOREIGN KEY (`id_agence`) REFERENCES `agence` (`id_agence`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Contraintes pour la table `code_validation`
--
ALTER TABLE `code_validation`
  ADD CONSTRAINT `fk_code_commande` FOREIGN KEY (`id_commande`) REFERENCES `commande` (`id_commande`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Contraintes pour la table `commande`
--
ALTER TABLE `commande`
  ADD CONSTRAINT `fk_commande_agence` FOREIGN KEY (`id_agence`) REFERENCES `agence` (`id_agence`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_commande_client` FOREIGN KEY (`id_client`) REFERENCES `client` (`id_client`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_commande_employe` FOREIGN KEY (`id_employe`) REFERENCES `employe` (`id_employe`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Contraintes pour la table `employe`
--
ALTER TABLE `employe`
  ADD CONSTRAINT `fk_employe_agence` FOREIGN KEY (`id_agence`) REFERENCES `agence` (`id_agence`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_employe_role` FOREIGN KEY (`id_role`) REFERENCES `role` (`id_role`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Contraintes pour la table `facture`
--
ALTER TABLE `facture`
  ADD CONSTRAINT `fk_facture_commande` FOREIGN KEY (`id_commande`) REFERENCES `commande` (`id_commande`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Contraintes pour la table `impliquer`
--
ALTER TABLE `impliquer`
  ADD CONSTRAINT `fk_impliquer_incident` FOREIGN KEY (`id_incident`) REFERENCES `incident` (`id_incident`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_impliquer_vetement` FOREIGN KEY (`id_vetement`) REFERENCES `vetement` (`id_vetement`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Contraintes pour la table `incident`
--
ALTER TABLE `incident`
  ADD CONSTRAINT `fk_incident_commande` FOREIGN KEY (`id_commande`) REFERENCES `commande` (`id_commande`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_incident_employe` FOREIGN KEY (`id_employe`) REFERENCES `employe` (`id_employe`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Contraintes pour la table `journal_action`
--
ALTER TABLE `journal_action`
  ADD CONSTRAINT `fk_journal_employe` FOREIGN KEY (`id_employe`) REFERENCES `employe` (`id_employe`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Contraintes pour la table `livraison`
--
ALTER TABLE `livraison`
  ADD CONSTRAINT `fk_livraison_commande` FOREIGN KEY (`id_commande`) REFERENCES `commande` (`id_commande`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_livraison_employe` FOREIGN KEY (`id_employe`) REFERENCES `employe` (`id_employe`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Contraintes pour la table `notification`
--
ALTER TABLE `notification`
  ADD CONSTRAINT `fk_notification_client` FOREIGN KEY (`id_client`) REFERENCES `client` (`id_client`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_notification_commande` FOREIGN KEY (`id_commande`) REFERENCES `commande` (`id_commande`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Contraintes pour la table `paiement`
--
ALTER TABLE `paiement`
  ADD CONSTRAINT `fk_paiement_commande` FOREIGN KEY (`id_commande`) REFERENCES `commande` (`id_commande`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_paiement_employe` FOREIGN KEY (`id_employe`) REFERENCES `employe` (`id_employe`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Contraintes pour la table `preuve_livraison`
--
ALTER TABLE `preuve_livraison`
  ADD CONSTRAINT `fk_preuve_livraison` FOREIGN KEY (`id_livraison`) REFERENCES `livraison` (`id_livraison`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Contraintes pour la table `retrait`
--
ALTER TABLE `retrait`
  ADD CONSTRAINT `fk_retrait_commande` FOREIGN KEY (`id_commande`) REFERENCES `commande` (`id_commande`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_retrait_employe` FOREIGN KEY (`id_employe`) REFERENCES `employe` (`id_employe`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Contraintes pour la table `supplement_applique`
--
ALTER TABLE `supplement_applique`
  ADD CONSTRAINT `fk_supp_applique_commande` FOREIGN KEY (`id_commande`) REFERENCES `commande` (`id_commande`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_supp_applique_supplement` FOREIGN KEY (`id_supplement`) REFERENCES `supplement` (`id_supplement`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_supp_applique_vetement` FOREIGN KEY (`id_vetement`) REFERENCES `vetement` (`id_vetement`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Contraintes pour la table `tarif_categorie`
--
ALTER TABLE `tarif_categorie`
  ADD CONSTRAINT `fk_tarif_categorie_agence` FOREIGN KEY (`id_agence`) REFERENCES `agence` (`id_agence`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_tarif_categorie_categorie` FOREIGN KEY (`id_categorie`) REFERENCES `categorie_article` (`id_categorie`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Contraintes pour la table `tarif_supplement`
--
ALTER TABLE `tarif_supplement`
  ADD CONSTRAINT `fk_tarif_supplement_agence` FOREIGN KEY (`id_agence`) REFERENCES `agence` (`id_agence`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_tarif_supplement_supplement` FOREIGN KEY (`id_supplement`) REFERENCES `supplement` (`id_supplement`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Contraintes pour la table `vetement`
--
ALTER TABLE `vetement`
  ADD CONSTRAINT `fk_vetement_article` FOREIGN KEY (`id_article`) REFERENCES `article` (`id_article`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_vetement_commande` FOREIGN KEY (`id_commande`) REFERENCES `commande` (`id_commande`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_vetement_retrait` FOREIGN KEY (`id_retrait`) REFERENCES `retrait` (`id_retrait`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
