<?php
// Si le dossier entier est déposé dans le « www » de WAMP, on redirige vers le dossier public.
header('Location: public/');
