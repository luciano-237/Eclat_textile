# Éclat Textile — application web de gestion de pressing multi-agences

Application PHP (sans framework) qui manipule la base `pressing` décrite dans le
cahier de conception (MERISE, MySQL 8.4). Les règles de gestion restent appliquées
par la base (déclencheurs, fonctions, procédures, vues) : l'application les utilise
et affiche leurs messages d'erreur tels quels (« RG50 : … »).

## Prérequis

- PHP 8.1 ou plus, extensions `pdo_mysql`, `fileinfo`, `mbstring`
- MySQL 8.4 avec la base créée par `base_de_donnees_pressing.sql`

## Installation

1. Créer la base :
   ```
   mysql -u root -p -P 3307 < base_de_donnees_pressing.sql
   ```
2. Renseigner l'accès MySQL dans `config/config.local.php` (prioritaire sur `config/config.php`) :
   ```php
   <?php
   return ['db' => ['port' => 3307, 'user' => 'root', 'password' => 'votre_mot_de_passe']];
   ```
3. Lancer le serveur :
   - **Serveur intégré de PHP** : `php -S localhost:8000 -t public` puis ouvrir http://localhost:8000
   - **WAMP** : copier le dossier dans `C:\wamp64\www\` puis ouvrir http://localhost/pressing-app/
4. Au premier lancement, la page **Installation** crée le compte administrateur et peut
   charger un jeu de démonstration (2 agences, tarifs, gérants, livreurs, clients, commandes).
   Tous les comptes de démonstration utilisent le mot de passe `demo1234`.

## Organisation

```
public/            racine web : index.php (routeur), CSS, JS, photos de livraison
app/               connexion PDO, authentification, outils, gabarits, données de démo
pages/             une page par écran (admin/, clients/, commandes/, livraisons/, incidents/, livreur/)
config/            paramètres (config.php, surcharge config.local.php)
```

## Fonctionnalités par rôle (matrice des droits, chap. 10)

| Rôle | Écrans |
|---|---|
| Administrateur | Tableau de bord consolidé, agences et configuration, tarifs par agence, employés, catalogue, suivi des commandes / clients / livraisons / incidents, notifications, journal |
| Gérant | Nouveau dépôt (client, service, vêtements pesés et étiquetés, suppléments), encaissement en une ou plusieurs fois, cycle de traitement, retrait total ou partiel avec code ou pièce d'identité et frais de retard, ticket avec QR code, livraisons (affectation, reprogrammation), retards et rappels, incidents |
| Livreur | Tournée, prise en charge du colis, validation par code + photo, signalement d'échec |

## Sécurité

- Mots de passe stockés avec `password_hash` (bcrypt), jamais en clair
- Requêtes préparées partout, jeton CSRF sur tous les formulaires, échappement HTML systématique
- `@id_employe_session` est défini à chaque connexion à la base : les actions journalisées par
  les déclencheurs sont attribuées à l'employé connecté (RG90)
- Aucune suppression : l'application n'utilise jamais `DELETE` (historique conservé)

## Notifications

Les notifications (WhatsApp / SMS) sont créées par la base. L'envoi réel dépend d'une plateforme
de messagerie à brancher plus tard ; l'écran **Notifications** permet en attendant de simuler l'envoi.
