/* Pressing — interactions de l'interface (aucune dépendance). */
(function () {
    'use strict';
    const $ = (s, r = document) => r.querySelector(s);
    const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
    const root = document.documentElement;

    /* Thème clair / sombre */
    const toggle = $('#themeToggle');
    if (toggle) {
        toggle.addEventListener('click', () => {
            const dark = root.dataset.theme
                ? root.dataset.theme === 'dark'
                : window.matchMedia('(prefers-color-scheme: dark)').matches;
            root.dataset.theme = dark ? 'light' : 'dark';
            try { localStorage.setItem('theme', root.dataset.theme); } catch (e) {}
        });
    }

    /* Barre latérale mobile */
    $$('[data-toggle-sidebar]').forEach(el => el.addEventListener('click', () => document.body.classList.toggle('sidebar-open')));

    /* Messages : fermeture et disparition automatique */
    function closeToast(t) { t.classList.add('leaving'); setTimeout(() => t.remove(), 260); }
    $$('.toast').forEach(t => {
        $('.toast-close', t)?.addEventListener('click', () => closeToast(t));
        if (!t.classList.contains('toast-critical')) setTimeout(() => closeToast(t), 6000);
    });

    /* Raccourci « / » : recherche */
    document.addEventListener('keydown', e => {
        if (e.key === '/' && !/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)) {
            const s = $('.topbar-search input[type=search]');
            if (s) { e.preventDefault(); s.focus(); }
        }
    });

    /* Dialogues */
    $$('[data-open]').forEach(b => b.addEventListener('click', e => {
        e.preventDefault();
        const d = document.getElementById(b.dataset.open);
        if (!d) return;
        // pré-remplissage éventuel : data-fill='{"name":"value"}'
        if (b.dataset.fill) {
            try {
                const data = JSON.parse(b.dataset.fill);
                Object.entries(data).forEach(([k, v]) => {
                    const f = d.querySelector('[name="' + k + '"]');
                    if (!f) { const t = d.querySelector('[data-text="' + k + '"]'); if (t) t.textContent = v; return; }
                    if (f.type === 'checkbox') f.checked = !!v; else f.value = v;
                    f.dispatchEvent(new Event('change', { bubbles: true }));
                });
            } catch (err) {}
        }
        d.showModal();
        const first = d.querySelector('input:not([type=hidden]),select,textarea');
        if (first) setTimeout(() => first.focus(), 50);
    }));
    $$('dialog.modal').forEach(d => {
        d.addEventListener('click', e => { if (e.target === d) d.close(); });
        $$('[data-close]', d).forEach(b => b.addEventListener('click', e => { e.preventDefault(); d.close(); }));
    });

    /* Confirmation avant action */
    $$('form[data-confirm]').forEach(f => f.addEventListener('submit', e => {
        if (!confirm(f.dataset.confirm)) e.preventDefault();
    }));

    /* Anti double-envoi */
    $$('form[method=post]').forEach(f => f.addEventListener('submit', e => {
        if (e.defaultPrevented) return;
        setTimeout(() => $$('button[type=submit]', f).forEach(b => b.setAttribute('disabled', '')), 0);
    }));

    /* Champs conditionnels : data-show-when="nom=valeur1|valeur2" */
    function refreshConditional(scope) {
        $$('[data-show-when]', scope).forEach(el => {
            const [name, vals] = el.dataset.showWhen.split('=');
            const allowed = vals.split('|');
            const form = el.closest('form') || document;
            const inputs = $$('[name="' + name + '"]', form);
            let current = '';
            inputs.forEach(i => {
                if (i.type === 'radio') { if (i.checked) current = i.value; }
                else if (i.type === 'checkbox') { current = i.checked ? (i.value || '1') : '0'; }
                else current = i.value;
            });
            const show = allowed.includes(current);
            el.classList.toggle('hidden', !show);
            $$('input,select,textarea', el).forEach(i => { if (i.dataset.req !== undefined) i.required = show; });
        });
    }
    document.addEventListener('change', () => refreshConditional(document));
    refreshConditional(document);

    /* Lignes cliquables */
    $$('tr[data-href]').forEach(tr => tr.addEventListener('click', e => {
        if (e.target.closest('a,button,input,form,label')) return;
        window.location = tr.dataset.href;
    }));

    /* Filtre instantané d'une liste : <input data-filter="#cible"> */
    $$('[data-filter]').forEach(inp => inp.addEventListener('input', () => {
        const q = inp.value.trim().toLowerCase();
        $$(inp.dataset.filter + ' [data-search]').forEach(el => {
            el.style.display = el.dataset.search.toLowerCase().includes(q) ? '' : 'none';
        });
    }));

    /* Révéler un code masqué */
    $$('[data-reveal]').forEach(b => b.addEventListener('click', () => {
        const t = document.getElementById(b.dataset.reveal);
        if (t) t.classList.toggle('masked');
    }));

    /* Afficher / masquer le mot de passe */
    $$('[data-toggle-password]').forEach(b => b.addEventListener('click', () => {
        const i = document.getElementById(b.dataset.togglePassword);
        if (i) i.type = i.type === 'password' ? 'text' : 'password';
    }));

    /* Comptes de démonstration : remplissage du formulaire de connexion */
    $$('[data-demo-email]').forEach(b => b.addEventListener('click', () => {
        $('#email').value = b.dataset.demoEmail;
        $('#password').value = b.dataset.demoPassword;
        $('#email').closest('form').requestSubmit();
    }));

    /* Photo (preuve de livraison) : réduction avant envoi + aperçu.
       Une photo de téléphone pèse 3 à 8 Mo, au-delà des limites courantes de PHP (2 Mo par défaut
       sous WAMP). On la redimensionne à 1600 px maximum en JPEG : ~200 à 500 Ko, bien lisible. */
    async function compressImage(file, maxSide = 1600, quality = 0.82) {
        if (!/^image\/(jpeg|png|webp)$/.test(file.type) && !/\.(jpe?g|png|webp|heic)$/i.test(file.name)) return file;
        let src;
        try { src = await createImageBitmap(file, { imageOrientation: 'from-image' }); }
        catch (e) {
            src = await new Promise((ok, ko) => { const i = new Image(); i.onload = () => ok(i); i.onerror = ko; i.src = URL.createObjectURL(file); });
        }
        const w = src.width || src.naturalWidth, h = src.height || src.naturalHeight;
        const k = Math.min(1, maxSide / Math.max(w, h));
        if (k === 1 && file.size < 1024 * 1024 && file.type === 'image/jpeg') return file;
        const c = document.createElement('canvas');
        c.width = Math.round(w * k); c.height = Math.round(h * k);
        c.getContext('2d').drawImage(src, 0, 0, c.width, c.height);
        const blob = await new Promise(r => c.toBlob(r, 'image/jpeg', quality));
        if (!blob || blob.size >= file.size) return file;
        return new File([blob], file.name.replace(/\.[^.]+$/, '') + '.jpg', { type: 'image/jpeg', lastModified: Date.now() });
    }
    $$('.dropzone input[type=file]').forEach(inp => inp.addEventListener('change', async () => {
        const zone = inp.closest('.dropzone');
        const form = inp.closest('form');
        const submits = form ? $$('button[type=submit]', form) : [];
        let f = inp.files && inp.files[0];
        if (!f) return;
        const lbl = $('.dz-label', zone);
        if (lbl) lbl.textContent = 'Préparation de la photo…';
        submits.forEach(b => b.setAttribute('disabled', ''));
        try {
            const small = await compressImage(f);
            if (small !== f && window.DataTransfer) {
                const dt = new DataTransfer(); dt.items.add(small); inp.files = dt.files; f = small;
            }
        } catch (e) { /* on garde la photo d'origine */ }
        submits.forEach(b => b.removeAttribute('disabled'));
        let img = $('img', zone);
        if (!img) { img = document.createElement('img'); zone.appendChild(img); }
        img.src = URL.createObjectURL(f);
        if (lbl) lbl.textContent = 'Photo prête · ' + Math.max(1, Math.round(f.size / 1024)) + ' Ko — toucher pour reprendre';
    }));

    /* Info-bulles du graphique */
    $$('.chart').forEach(chart => {
        const tip = $('.chart-tip', chart);
        if (!tip) return;
        $$('.bar-group', chart).forEach(g => {
            const show = () => {
                const r = g.getBoundingClientRect(), c = chart.getBoundingClientRect();
                tip.innerHTML = g.dataset.value + '<small>' + g.dataset.label + '</small>';
                tip.style.left = (r.left - c.left + r.width / 2) + 'px';
                tip.style.top = (parseFloat(g.dataset.top) / 100 * $('svg', chart).getBoundingClientRect().height + 18) + 'px';
                tip.style.opacity = 1;
            };
            g.addEventListener('mouseenter', show);
            g.addEventListener('focus', show);
            g.addEventListener('mouseleave', () => tip.style.opacity = 0);
            g.addEventListener('blur', () => tip.style.opacity = 0);
        });
    });

    /* QR codes (ticket) */
    if (window.QRCode) {
        $$('[data-qr]').forEach(el => {
            el.innerHTML = '';
            new QRCode(el, { text: el.dataset.qr, width: 132, height: 132, correctLevel: QRCode.CorrectLevel.M });
        });
    }

    /* Impression automatique */
    $$('[data-print]').forEach(b => b.addEventListener('click', () => window.print()));

    /* ---------------------------------------------------------------- Lecture de QR code
       <button data-qr-scan="idDuChamp"> : ouvre la caméra arrière et remplit le champ.
       La bibliothèque n'est chargée qu'au premier clic. Sans caméra en direct (page non
       sécurisée, refus d'autorisation…), on peut photographier le QR code à la place. */
    const QR_LIB = 'https://cdn.jsdelivr.net/npm/html5-qrcode@2.3.8/html5-qrcode.min.js';
    let qrLibPromise = null;
    function loadQrLib() {
        if (window.Html5Qrcode) return Promise.resolve();
        if (!qrLibPromise) {
            qrLibPromise = new Promise((ok, ko) => {
                const s = document.createElement('script');
                s.src = QR_LIB; s.onload = ok;
                s.onerror = () => { qrLibPromise = null; ko(new Error('lib')); };
                document.head.appendChild(s);
            });
        }
        return qrLibPromise;
    }

    let scanDlg = null, scanner = null, scanTarget = null;
    function buildScanDialog() {
        scanDlg = document.createElement('dialog');
        scanDlg.className = 'modal scan-modal';
        scanDlg.innerHTML =
            '<div class="modal-header"><h3>Scanner le QR code</h3><button class="icon-btn" data-scan-close aria-label="Fermer">✕</button></div>' +
            '<div class="modal-body">' +
            '  <div class="scan-view"><div id="qrReader"></div><div class="scan-frame"><span></span></div></div>' +
            '  <p class="scan-status" id="scanStatus">Démarrage de la caméra…</p>' +
            '  <label class="btn btn-secondary btn-block scan-photo">Prendre une photo du QR code' +
            '    <input type="file" accept="image/*" capture="environment" hidden></label>' +
            '</div>';
        document.body.appendChild(scanDlg);
        scanDlg.querySelector('[data-scan-close]').addEventListener('click', closeScan);
        scanDlg.addEventListener('cancel', e => { e.preventDefault(); closeScan(); });
        scanDlg.addEventListener('click', e => { if (e.target === scanDlg) closeScan(); });
        scanDlg.querySelector('.scan-photo input').addEventListener('change', async e => {
            const f = e.target.files && e.target.files[0];
            e.target.value = '';
            if (!f) return;
            setScanStatus('Analyse de la photo…');
            try {
                await stopCamera();
                const txt = await new Html5Qrcode('qrReader', { verbose: false }).scanFile(f, false);
                onScanned(txt);
            } catch (err) {
                setScanStatus('Aucun QR code lisible sur cette photo. Cadrez-le de plus près, bien éclairé.', true);
            }
        });
    }
    function setScanStatus(t, bad) {
        const el = document.getElementById('scanStatus');
        if (el) { el.textContent = t; el.classList.toggle('is-error', !!bad); }
    }
    async function stopCamera() {
        if (scanner) {
            try { if (scanner.isScanning) await scanner.stop(); scanner.clear(); } catch (e) {}
            scanner = null;
        }
    }
    async function closeScan() {
        await stopCamera();
        if (scanDlg && scanDlg.open) scanDlg.close();
    }
    function onScanned(txt) {
        const input = document.getElementById(scanTarget);
        if (input) {
            input.value = txt.trim();
            input.classList.add('is-scanned');
            input.dispatchEvent(new Event('input', { bubbles: true }));
            const b = document.querySelector('[data-qr-scan="' + scanTarget + '"]');
            if (b) b.innerHTML = '✓ QR code lu — scanner à nouveau';
        }
        if (navigator.vibrate) navigator.vibrate(120);
        closeScan();
    }
    $$('[data-qr-scan]').forEach(btn => btn.addEventListener('click', async () => {
        scanTarget = btn.dataset.qrScan;
        if (!scanDlg) buildScanDialog();
        scanDlg.showModal();
        setScanStatus('Démarrage de la caméra…');
        try {
            await loadQrLib();
        } catch (e) {
            setScanStatus('Lecteur indisponible : une connexion Internet est nécessaire pour le charger. Saisissez le code à 6 chiffres.', true);
            return;
        }
        if (!window.isSecureContext || !navigator.mediaDevices) {
            setScanStatus('Caméra en direct indisponible sur une adresse non sécurisée (http). Utilisez « Prendre une photo du QR code ».', true);
            return;
        }
        try {
            scanner = new Html5Qrcode('qrReader', { formatsToSupport: [Html5QrcodeSupportedFormats.QR_CODE], verbose: false });
            await scanner.start({ facingMode: 'environment' },
                { fps: 12, qrbox: (w, h) => { const s = Math.floor(Math.min(w, h) * 0.7); return { width: s, height: s }; } },
                txt => onScanned(txt), () => {});
            setScanStatus('Placez le QR code du client dans le cadre.');
        } catch (e) {
            scanner = null;
            setScanStatus('Impossible d\'ouvrir la caméra (autorisation refusée ou aucune caméra). Utilisez « Prendre une photo du QR code ».', true);
        }
    }));
})();
