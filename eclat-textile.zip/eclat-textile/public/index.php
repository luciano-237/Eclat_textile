<?php
/**
 * Point d'entrée unique : index.php?p=<page>
 */
require __DIR__ . '/../app/bootstrap.php';

// page => [fichier, rôles autorisés (null = public, [] = tout utilisateur connecté)]
$routes = [
    'connexion'          => ['auth/connexion', null],
    'deconnexion'        => ['auth/deconnexion', []],
    'installation'       => ['auth/installation', null],
    'inscription'        => ['auth/inscription', null],
    'mon-compte'         => ['auth/mon-compte', []],
    'tableau-de-bord'    => ['tableau-de-bord', []],

    // Administration du réseau
    'agences'            => ['admin/agences', [ROLE_ADMIN]],
    'agence'             => ['admin/agence', [ROLE_ADMIN]],
    'tarifs'             => ['admin/tarifs', [ROLE_ADMIN]],
    'employes'           => ['admin/employes', [ROLE_ADMIN]],
    'employe'            => ['admin/employe', [ROLE_ADMIN]],
    'catalogue'          => ['admin/catalogue', [ROLE_ADMIN]],
    'journal'            => ['admin/journal', [ROLE_ADMIN, ROLE_GERANT]],

    // Exploitation en agence
    'clients'            => ['clients/liste', [ROLE_ADMIN, ROLE_GERANT]],
    'client'             => ['clients/fiche', [ROLE_ADMIN, ROLE_GERANT]],
    'client-form'        => ['clients/form', [ROLE_GERANT]],
    'commandes'          => ['commandes/liste', [ROLE_ADMIN, ROLE_GERANT]],
    'commande-nouvelle'  => ['commandes/nouvelle', [ROLE_GERANT]],
    'commande'           => ['commandes/voir', [ROLE_ADMIN, ROLE_GERANT]],
    'commande-action'    => ['commandes/actions', [ROLE_GERANT]],
    'ticket'             => ['commandes/ticket', [ROLE_ADMIN, ROLE_GERANT]],
    'retrait'            => ['commandes/retrait', [ROLE_GERANT]],
    'livraisons'         => ['livraisons/liste', [ROLE_ADMIN, ROLE_GERANT]],
    'retards'            => ['commandes/retards', [ROLE_GERANT]],
    'incidents'          => ['incidents/liste', [ROLE_ADMIN, ROLE_GERANT]],
    'incident'           => ['incidents/voir', [ROLE_ADMIN, ROLE_GERANT]],
    'incident-nouveau'   => ['incidents/nouveau', [ROLE_GERANT]],
    'notifications'      => ['notifications', [ROLE_ADMIN, ROLE_GERANT]],

    // Livreur
    'tournee'            => ['livreur/tournee', [ROLE_LIVREUR]],
    'livraison'          => ['livreur/livraison', [ROLE_LIVREUR]],
];

$page = (string) ($_GET['p'] ?? (user() ? 'tableau-de-bord' : 'connexion'));
if (!isset($routes[$page])) {
    http_response_code(404);
    $page = user() ? 'tableau-de-bord' : 'connexion';
    flash('error', 'Page introuvable.');
}
[$file, $roles] = $routes[$page];

// Envoi plus gros que post_max_size : PHP vide alors $_POST et $_FILES (jeton compris).
if (is_post() && !$_POST && !$_FILES && (int) ($_SERVER['CONTENT_LENGTH'] ?? 0) > 0) {
    flash('error', 'Envoi trop volumineux pour le serveur (limite : ' . ini_get('post_max_size') . '). Reprenez la photo ou choisissez un fichier plus léger.');
    header('Location: ' . ($_SERVER['REQUEST_URI'] ?? url($page)));
    exit;
}

// Base de données accessible et initialisée ?
try {
    db();
    $hasAdmin = (bool) val("SELECT 1 FROM employe e JOIN role r ON r.id_role = e.id_role WHERE r.libelle_role = 'Administrateur' LIMIT 1");
} catch (Throwable $e) {
    $dbError = $e;
    require APP_ROOT . '/pages/erreur-bdd.php';
    exit;
}
if (!$hasAdmin && $page !== 'installation') {
    redirect('installation');
}

if ($roles !== null) {
    require_login();
    if ($roles !== []) {
        require_role(...$roles);
    }
}

// Rendu : la page produit son contenu, le gabarit l'habille.
$title = cfg('app_name');
$layout = 'app';
$active = $page;
ob_start();
try {
    require APP_ROOT . '/pages/' . $file . '.php';
} catch (PDOException $ex) {
    ob_clean();
    echo '<div class="alert alert-critical">' . icon('alert') . '<div>' . e(db_error($ex)) . '</div></div>';
}
$content = ob_get_clean();

require APP_ROOT . '/app/layout/' . $layout . '.php';
